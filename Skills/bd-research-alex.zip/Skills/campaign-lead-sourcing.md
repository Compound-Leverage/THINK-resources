# Campaign Lead Sourcing

Keeps a Consortium Placement Campaign's lead buffer full against its real `Placement Target` field (Campaign Hub -- no separate "Leads Target" exists, the OKR-sufficiency judgment happens at Campaign creation, Scott's job). Two trigger conditions, same shape as Scott's Campaign Builder and Cassie's Reserve logic -- own polling schedule, no live push, defers to threshold state rather than acting on a fixed schedule alone.

## Trigger 1 -- New campaign, initial sourcing

A Campaign is an execution round against a Consortium, not the other way around -- a Consortium (Chet's durable named-entity group, e.g. AHRI's 15 members) can have more than one Campaign over its lifecycle (the initial one, plus later replacement cycles from Scott's Trigger 2). Fit is defined at the Consortium level and inherited, not re-derived here: an org is a placement lead **because it's a named member of the Consortium the Campaign executes against**. That membership only exists because of what already happened before Alex touches it, in order:

1. **Chet** confirms dependency (the named, bounded group actually carries the documented capacity gap), mines `named_entities`/`gap_volume`/`budget_confirmation`, writes the Consortium cluster to the Clusters DB.
2. **Cassie** computes CE Score (Proximity/Differentiation/Timing/Detection) and gates it through Received -> Qualified.
3. **Scott** fans out the Qualified card into this Campaign Hub record.

Alex starts only after all three have happened. He does not re-justify fit; he works the list.

### The GTM unit is the network, not the individual org -- a roll-up mindset

The capacity gap Chet identifies belongs to the network, not to each member independently -- `roster_capacity_map.json`'s own language for these consortiums is consortium-level ("no dedicated research development office," "no consortium coverage"), not N duplicate individual-org gaps. That reframes the goal: this is a roll-up, not a series of independent deals. The end state for a Consortium campaign is the *whole* network consolidated into one placement/relationship, not a scattered set of unrelated individual wins that happen to share a Consortium tag.

Two paths to that end state, not competing alternatives -- one is faster where it's available:
- **Direct roll-up:** where a real network-level coordinating body exists (AIHEC for TCU & MSI is a confirmed example -- a formal 501(c)(3) governed by the board of every accredited TCU president), that body can BE the customer for a single network-level placement serving the whole membership at once. This isn't a trust-broker who merely introduces 35 separate sales -- it's the fastest path to fully rolling up the network in one motion.
- **Tuck-in roll-up:** where no clean coordinating body exists (confirmed the case for the 89-member HBCU Research Capacity Act cohort), land individual members one at a time as tuck-ins, each one building the case/proof/network density toward an eventual full consolidation -- not isolated wins for their own sake. TSU (AHRI) is the live proof this works: an individual member win became the credibility asset for approaching the rest of the network.

Everything below -- the per-contact Assigned/Entered/Target flow, individual Warm/Partner/Cold entries -- is the tuck-in mechanism, one member at a time, in service of the roll-up. It's not the end goal by itself.

Three contact states -- **assigned** (Alex's job), **entered** (Sarah's job), **target** (see timing note below) -- plus a classification gate that runs before any of them.

### Step 0 -- Partner, warm, or cold path -- three categories, not two, before anything else

Builds on the existing `operator_lead` classification but splits it by who actually has the path and how the pursuit happens, not just attribution:
- **Partner** -- pursue jointly with/through a partner (Inncuvate/Mark Lawrence) because *they* have a warmer path to this org than CL does directly. Carries the Inncuvate revenue-share arrangement through to Deals Pipeline. **Not a single mode -- a further governance-structure call is required, matching real deal structures already observed**:
  - **Lead** -- CL is prime, partner plays a supporting role.
  - **Co-lead** -- CL and Inncuvate jointly lead, equal structure.
  - **Need a prime** -- neither CL nor Inncuvate primes; both are part of a larger team under a third-party prime. Real example: MBDA PJM -- neither Marvin/CL nor Inncuvate was prime, both were part of a team under a separate prime. (Morehouse is a different real case -- Inncuvate prime, CL sub -- which is its own two-party structure, not this one.)
  - This governance call is Marvin's to make, not Alex's -- prime/sub structure is a contractual/business decision, not something researchable from outside. Alex flags the entity as Partner-path and surfaces what he found; Marvin confirms Lead/Co-lead/Need-a-Prime before Scott/Sarah treat it as committed.
- **Warm** -- Marvin has a direct path himself, no partner needed. Marvin pursues (or authorizes Sarah to reference the connection) without involving Inncuvate.
- **Cold** -- no existing path either way. Two sub-branches, decided per entity: (a) attempt to *create* a warm path first (relationship-building before any pitch), or (b) skip straight to the standard cold nurture sequence (email-1/2/3) if warm-path creation isn't worth the time for this one.

**Who decides:** Alex proposes Warm/Cold autonomously based on research (network-overlap signals, existing relationship evidence -- same evidentiary bar as `operator_lead` elsewhere). Partner-path entities, including which governance mode, route to Marvin for confirmation before anything downstream treats them as committed -- Alex can surface evidence of an Inncuvate relationship, but only Marvin knows the real state of that partnership and can commit Inncuvate's resources to a specific structure.

For every named entity, before sourcing starts, tag which applies. AHRI's own real campaign record already shows this in practice -- Mark Lawrence/Inncuvate engaged as warm intro is the **Partner** case specifically, not a generic "warm" label. This determines priority, threshold, and who actually runs point on the approach -- Partner and Warm entities get worked first and at the lower 55+ bar (standing rule, same as elsewhere), Cold at the standard bar -- but all three still pass through the same Assigned -> Entered -> Target states below; this classification changes who leads and how fast, not which states they go through.

### Assigned -- Alex's job

**Org-level: multi-campaign is fine.** An org can legitimately belong to more than one campaign's `Target Organizations` relation -- e.g. an institution that's both an AHRI member and separately TCU/MSI-eligible. This is real overlap, not a duplicate. **Pass 1 -- add orgs:** for each named entity on the Campaign's linked Consortium, if the org already exists in Organizations, link it to this Campaign's `Target Organizations` relation too (no skip, no restriction). If it doesn't exist yet, add it to the Organizations table (`2cc68799`), enrich via Scrape Creators/Clay same as `klr-signal-radar.md`, then link. No contact work yet -- an added-but-uncontacted org sitting at assigned is a valid, expected state between runs, not an error.

**Every new org link also increments this Campaign's `Orgs Matched` field by 1.** Only on an actual new link -- re-running against an org already linked to this Campaign does not increment it again. Never decrement it, including if an org is later unlinked/corrected -- `Orgs Matched` is a running total of adds, not a live count of current links, so Cassie's Revenue KR1 can sum it across campaigns without the total going backward.

**Contact-level: exclusive, one campaign at a time.** A specific decision-maker never gets worked from two campaigns -- that's what actually causes duplicate/conflicting outreach, not the org-level relation. **Pass 2 -- find contacts:** for orgs already added but with no contact on file, first check whether this org already has a contact on an active Deals Pipeline record from a *different* campaign. If so, skip -- do not add a second contact for this org under this campaign; the org stays multi-tagged, but the human contact stays with whichever campaign claimed them first. If no existing contact: find the decision-maker (name, title, verified email), write to Contacts. Increment this Campaign's `Contacts Matched` field by 1 on each new contact added, same never-decrement rule as `Orgs Matched`. This is where Alex's job stops -- he does not create the Deals Pipeline record and does not decide entry.

### Entered -- the real path taxonomy, not just Sarah

Who moves a contact from assigned to entered, and where first contact actually starts, is one of these paths -- not a narrower Sarah/Marvin split:

1. **Partner** -- Inncuvate/Mark Lawrence has the relationship or brokers it, per Marvin's confirmed Lead/Co-lead/Need-a-Prime governance call. Their action moves the contact to entered, not Sarah's email sequence.
2. **We run it** -- CL initiates directly, either **warm** (Marvin makes first contact himself, or explicitly authorizes Sarah to reference the connection) or **cold** (Sarah runs the standard Email 1/scheduling sequence, no existing relationship). Both are "we run it," warm and cold are modes within it, not two separate top-level paths.
3. **Content -> inbound, Gail-ICP-relevant only, and likely a different surface than newsletter.** **Do not conflate this with the Audience Objective.** Audience is its own separate Q3 OKR Objective (Crystal ICP subscriber/newsletter growth) with its own funnel -- the newsletter/LinkedIn/blog output from Joe's 13-agent Sunday sequence feeds that, not Consortium campaigns, and mostly reaches Crystal ICP, not Gail. Consortium-campaign-relevant content more likely lives on the **website** -- a page or resource built/targeted for a specific Consortium's segment (SEO, direct link-sharing to decision-makers in that sector), not the general-audience newsletter. This path applies when the specific org/contact engaging is relevant to a Consortium's Gail ICP (a workforce board, HBCU, federal agency, etc. -- matching an entity already in that campaign's Consortium) via that kind of targeted surface. A Crystal-ICP solopreneur replying to the newsletter is a separate Audience-Objective event, routed to `think-school-crystal`, not this pipeline.

   **Check before creating new content:** if a campaign needs supporting content, first check whether existing newsletter content or one of Ben/Josh's Intelligence Briefs (`Agents/ben/`, `Agents/josh/`) already answers the need -- these already produce sector/CE-specific content on a standing cadence. Only trigger bespoke, campaign-specific content creation (a new website page or resource) if nothing existing already covers it. Same "reuse before build" principle as everywhere else in this pipeline.
4. **Speaking events or other** -- a conference/panel appearance or similar generates the contact, not outreach or content.
5. **Lead magnets** -- a downloadable resource or tool captures the contact directly.

**Placements content is one path across all activations, not separate content per channel.** The website page (3), speaking event materials (4), and lead magnet (5) should all draw from the same underlying proof-point library -- real placement evidence, case studies, outcomes -- rather than each channel inventing its own content from scratch. This is Marcus's existing role (`Extracts and packages proof points from active client engagements into case study narratives... maintains a minimum inventory of active proof points`), not a new capability -- Alex/Sarah pull from that shared inventory when a channel needs placement-credibility content, they don't generate it themselves.

**One-to-many playbook is a scaling mechanism, not its own path.** It applies *within* the Partner or We-run-it (warm) paths when a Consortium has more than a handful of contacts -- see the One-to-many section above. It doesn't replace this taxonomy, it's how Partner/Warm entry works at volume.

Alex hands off a completed contact regardless of which path applies; he never makes the entry decision himself. Whichever path applies, the action creates or advances the Deals Pipeline record -- real `Stage = Waiting` if this is the point the record first exists (see `Agents/sarah/Skills/campaign-manager.md`'s Campaign Stage Definitions -- there is no `campaign_stage` field or `added`/`email-1-sent` values, those were never real), advancing from there per Sarah's normal cadence.

A contact sitting on file with none of the five paths having happened yet stays at assigned -- and does not count toward the buffer for the `Placement Target` threshold.

### One-to-many -- how Marvin/Partner entry scales past a handful of contacts

Marvin or Inncuvate can personally warm-intro one org. They cannot do that individually for all 15 AHRI members, 89 HBCU cohort members, or 35 TCU & MSI members -- doing Warm/Partner entry one contact at a time doesn't scale, and this is already how it works in practice: AHRI's real campaign record shows Mark Lawrence/Inncuvate engaged **once**, for the whole consortium, not 15 separate individual intros.

**Trigger:** a Consortium has more than a handful of contacts tagged Warm or Partner at Step 0 (informal threshold -- more than 2-3 in the same Consortium). Below that, do individual 1:1 intros as described above; above it, default to one-to-many.

**Mechanism, and the research task behind it:** before any group-level action can happen, Alex has to find the actual entry point into the group -- four things to look for, in order of preference:
1. **A group-level contact** -- an executive director, cohort administrator, association coordinator, or shared funding-body contact who represents/coordinates the whole Consortium. If this exists, this is the single point of contact for the one-to-many move. Confirmed real example: **AIHEC** (American Indian Higher Education Consortium) for TCU & MSI -- a formal 501(c)(3), governed by the board of all accredited TCU presidents. A clean fit for this option.
2. **A place they gather** -- an annual conference, a shared listserv, a member portal, a recurring summit or meeting where the whole membership convenes. If no single coordinator exists, this is the venue for a group-level touch instead.
3. **Someone with access or influence over the group** -- not necessarily the formal administrator, but a board member, funder, or respected figure the membership already trusts and would respond to. This is the fallback when neither 1 nor 2 turns up a clean entry point.
4. **No clean entry point found -- close a couple of individual members first, then use that as leverage for the larger group.** This is not a fallback of last resort, it's a legitimate strategy on its own, already proven: TSU (one of AHRI's 15 members) is the existing internal proof point CL already uses when approaching the rest of AHRI. When 1-3 don't turn up a clean single body -- confirmed the case for the 89-member HBCU Research Capacity Act cohort, no single coordinating association found -- land 2-3 individual members via normal Warm/Cold 1:1 entry, get a real outcome, then approach the wider group with that proof point as the credibility bridge instead of a cold group pitch.

Once Alex surfaces which of the four applies (and for which Consortium), Marvin/Inncuvate uses it to execute: a mass intro email referencing the Consortium affiliation as the credibility bridge (1), a webinar/info session invite through the gathering place (2), an introduction via the influence-holder (3), or a proof-point pitch built from the individual wins (4).

**Effect:** when this group-level action happens, every Warm/Partner-tagged contact in that Consortium who was reached by it moves to Entered simultaneously, not staggered individually. Same downstream mechanics as an individual entry (Deals Pipeline record created/advanced, Target populated) -- just triggered once for the group instead of once per contact.

**Tradeoff, worth stating plainly:** a group intro is weaker per-contact than a genuine bespoke 1:1 warm intro -- less personal, easier to ignore. It's the only way Warm/Partner paths scale past a handful of contacts, not a strictly better substitute for individual outreach. For the 2-3 contacts below the one-to-many threshold, individual intros are still the better move where Marvin/Inncuvate has the bandwidth.

**Who decides:** same as individual Warm/Partner entries -- Marvin confirms whether a given Consortium gets the one-to-many treatment (and, for Partner-path, which governance mode) before it's treated as committed. Alex surfaces the contact count and Consortium structure; he doesn't decide to trigger a group intro himself.

### Target -- ready to be contacted, then a channel/nurture-path decision

Entered moves a contact to Target -- they're ready to be contacted, and by construction (see Entered above) the channel is already implied by whichever path made that entry happen: Partner, We-run-it (warm or cold), Content engineering, Speaking events/other, or Lead magnets. No separate channel decision is needed at Target -- it's already decided by which path entered them. **I'd populate Target Organizations/Target Contacts immediately at Entered, not gated on further engagement** -- the real AHRI campaign record already shows 17 `Target Contacts` populated, which reads as the full outreach-ready list, not a filtered "only people who responded" list. This is a recommendation, not a lock -- say so if you intended a stricter engagement-gated bar instead.

This decision happens once, at Target, before entry into whichever nurture sequence applies -- it is not re-decided at every stage transition after.

## RFP/mandate opportunities -- a second lead type, different destination than consortium-member orgs

**Part of every regular run, not a separate or occasional pass** -- alongside sourcing consortium-member orgs each time Alex touches a campaign, also scan for RFP/mandate opportunities tied to that campaign's `Parent Cluster`. Not a fit-justification step, a distinct kind of lead surfaced in the same run. An RFP is a real bid/response commitment, closer to proposal work than routine outreach, so it gets a decision gate instead of flowing straight into active work:

1. Match the RFP to the relevant Campaign via its `Parent Cluster` relation (real field, both Campaign Hub and the Inbox relate to the same Clusters DB record -- no separate "Capital Event Association" field needed).
2. Link it to whatever specificity is available: link to the org if there's no contact yet, link to the contact if one already exists for that org (same org/contact records as consortium-member sourcing above -- don't create a parallel set).
3. Enter it into Deals Pipeline at `Stage = Targeting` (the real field is `Stage`, not `campaign_stage` -- `Targeting` is already a real option, see `Agents/sarah/Skills/campaign-manager.md`'s Campaign Stage Definitions) -- held, not actively worked.
4. **Priya** (Proposal Analyst, Maya's team -- deal classification/ROI scoring is her job) **and Sarah** score it together for pursue/don't-pursue -- not Blair (his boundary is capital/grant proposals; "RFP" specifically falls under Maya's team per the existing proposal engine boundary). Alex does not make this call, only surfaces the RFP correctly linked and staged. Do not auto-advance an RFP out of `Targeting` the way a regular lead auto-advances through email stages -- only Priya+Sarah's explicit decision moves it.

## The loop -- one continuous cycle across all Active campaigns, not two separate one-shot triggers

1. **Fill** -- source leads for whichever Active campaign needs them (Trigger 1's new campaign, or Trigger 2's depleted one) until the buffer reaches `Placement Target` x 1.25 (125%, i.e. Target + 25% -- same `1.25` multiplier already established in the OKR formula elsewhere in this pipeline, not an arbitrary buffer percentage).
2. **Pause** -- stop adding for that campaign at the ceiling. Do not keep sourcing past it -- an overstocked buffer just sits unused and risks working stale signal later. Log the pause with campaign name and buffer count.
3. **Wait** -- do nothing for that campaign until its buffer drops back to or below `Placement Target` (deals progressing consume the 25% cushion), or Marvin explicitly requests an add regardless of buffer state.
4. **On resume, priority order:**
   - First, check whether the *same* campaign's Consortium still has un-sourced named entities left -- if yes, keep filling that campaign back up to threshold.
   - Only once that Consortium is fully mined out (no targets left to add) does Alex move to a *different* Active campaign that needs filling.
5. **Conversion redirect -- automatic, checked every run, separate from the volume-based pause/resume above.** If a campaign's `Placements Closed` (real field) has already reached its `Placement Target`, that campaign has hit its OKR goal through actual conversions. Write the Campaign Hub's real `Status` field to **Paused** -- this makes the redirect visible and durable in Notion, not just an internal rule Alex silently re-decides every run. Then redirect sourcing effort to other Active campaigns that still need filling. This is a business-performance signal, not a volume signal -- a campaign converting well doesn't need more leads sourced just because its lead buffer isn't technically full. Existing leads already in that campaign's pipeline still get worked by Sarah as normal; Alex just stops adding new ones and the campaign no longer shows as Active.
6. **Repeat**, indefinitely, across every Active campaign -- this is Trigger 2's ongoing behavior, not a one-time check.

## Trigger 2 -- Buffer replenishment

For each Active campaign already sourced once: if the lead buffer (qualified leads not yet pulled into a deal, tagged to this `campaign_id`) falls to or below the campaign's `Placement Target`, resume sourcing per the priority order above until the buffer threshold is met again.

## What this skill does NOT do

- No scoring of the Campaign itself (CE Score is Cassie's, inherited not touched)
- No campaign creation (Scott's job) or outreach (Sarah's job, per Alex's standing "never sends external communications" boundary)
- No sourcing for a campaign Cassie's pause state has closed -- if the linked card's Status is Closed, stop sourcing for that campaign regardless of buffer state, same deference rule as Scott's
