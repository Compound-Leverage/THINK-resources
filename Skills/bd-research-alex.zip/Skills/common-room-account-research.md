# Common Room — Account Research

## Purpose
Pull account-level signals from Common Room to build a BD research brief on a target org. Feeds placement lead records, not general intel.

## Inputs
- Org name or domain
- Optional: known contacts at org

## Process
1. Query Common Room for the account: engagement history, product signals, job change alerts, intent signals
2. Cross-reference with Notion Orgs DB (2cc68799) for existing CL relationship context
3. Enrich with Clay if account not yet in CL CRM
4. Score account against Crystal or Gail ICP criteria

## Output
Account research brief for Sarah:
- Org name, size, sector
- Capital event proximity (any signals from Common Room data)
- ICP tier (Crystal / Gail / Neither)
- Recommended outreach angle based on account signals
- Existing CL touchpoints if any
