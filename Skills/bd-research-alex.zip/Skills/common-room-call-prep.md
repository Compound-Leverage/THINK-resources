# Common Room — Call Prep

## Purpose
Build a pre-call intel brief for a BD call. Standard pattern: Gmail search + Common Room signals + web research + Sarah outreach. Output is a brief Marvin or Sarah can scan in 2 minutes before a call.

## Inputs
- Contact name and org
- Call date and time (from calendar or explicit input)
- Known deal stage

## Process
1. Pull contact signals from Common Room (recent activity, job change, engagement)
2. Search Gmail for thread history with contact
3. Search web for recent org news, announcements, capital events
4. Read Deals Pipeline record if exists
5. Synthesize into a 1-page brief

## Output
Pre-call brief (Markdown, < 400 words):
- Contact: name, title, tenure at org
- Org: size, sector, recent capital events
- CL history: prior touchpoints, deal stage
- Recommended angle: what to lead with based on signals
- Open items: anything unresolved from prior thread
- Save to `output/{week}/call-prep-{contact}-{date}.md`
