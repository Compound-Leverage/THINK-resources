# Common Room — Compose Outreach

## Purpose
Draft outreach copy from Common Room contact signals. Alex composes; Sarah sends. Output feeds Sarah's outreach queue — not sent directly from this skill.

## Inputs
- Contact name, title, org
- Signal type from Common Room (job change, product engagement, intent signal, community post)
- Target ICP tier (Crystal / Gail)

## Process
1. Read the signal from Common Room
2. Select the outreach frame based on signal type:
   - Job change → timing + labor gap angle
   - Intent signal → acknowledgment + placement fit
   - Community post → content reference + resonance angle
3. Draft subject line and body (Sarah's HTML format standard applies)
4. Hand to Sarah with: contact info, signal reference, suggested send timing

## Output
Outreach draft delivered to Sarah:
- To: [contact email]
- Subject line
- Body (plain text for Sarah to format as HTML)
- Signal source and context note
- Marvin CC flagged
