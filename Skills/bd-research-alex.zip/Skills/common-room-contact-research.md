# Common Room — Contact Research

## Purpose
Individual contact enrichment from Common Room for a named BD prospect. Produces a contact record ready for Notion Contacts DB (170e1f64) and Sarah's outreach queue.

## Inputs
- Contact name
- Org name or domain

## Process
1. Look up contact in Common Room: engagement signals, recent activity, connections
2. Enrich via Clay if not in CL CRM
3. Verify email via Hunter.io if needed
4. Classify against ICP criteria (Crystal: labor gap + THINK School fit; Gail: DE subscription fit)
5. Write or update Notion Contacts record

## Output
Enriched contact record:
- Name, title, email, LinkedIn
- ICP classification (Crystal / Gail / Neither) with score
- Common Room signal summary (what triggered research)
- Recommended next action: outreach via Sarah, monitor, or disqualify
- Written to Notion Contacts DB
