# Common Room — Prospect

## Purpose
Source qualified prospects from Common Room community signals. Alex scans activity across connected communities (Beehiiv subscribers, THINK School members, referral network) for signal patterns that match CL ICP criteria. Output: placement lead records.

## Signal Patterns to Flag
- New community member with a title that matches Crystal ICP (operator, director, program manager with labor gap context)
- Existing subscriber who posts or engages with capital event content
- Referral submission from Common Room source
- Account that crossed an engagement threshold (repeated touches across CL channels)

## Process
1. Pull active signals from Common Room (daily or weekly sweep)
2. Filter for ICP-pattern matches
3. Enrich each match via Clay and Hunter.io
4. Score against Crystal or Gail ICP criteria
5. Add to Alex's sourcing queue for Sarah's outreach

## Output
Placement lead records per qualifying contact:
- Name, title, org, email
- Signal source (Common Room community, engagement type)
- ICP tier and score
- Recommended outreach type (Crystal: THINK School angle; Gail: DE placement angle)
- Hand to Sarah with context
