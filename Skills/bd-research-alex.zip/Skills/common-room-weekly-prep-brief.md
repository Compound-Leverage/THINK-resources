# Common Room — Weekly Prep Brief

## Purpose
Weekly BD prep brief synthesized from Common Room activity. Runs alongside Cal's weekly Marvin brief. Gives Marvin and Sarah a prioritized list of accounts and contacts to act on this week.

## Timing
Runs Sunday evening after Cal's brief is written. Surfaces Common Room signals from the past 7 days.

## Process
1. Pull the week's signals from Common Room: account-level activity, contact-level changes, intent spikes
2. Cross-reference against Deals Pipeline and Contacts DB (who is already in pipeline)
3. Rank by:
   - New signal from an existing pipeline account (highest priority)
   - New signal from an ICP-matching account not in pipeline
   - Re-engagement from a previously cold contact
4. Write brief

## Output
Weekly prep brief (Markdown, < 500 words):
- **This week's priority accounts:** [accounts with new or elevated signals]
- **New contacts to add to queue:** [names, orgs, signal type, recommended action]
- **Re-engagement targets:** [previously cold contacts showing new activity]
- Save to `output/{week}/common-room-weekly-{date}.md`
- Deliver summary line to Google Chat (Alex findings space)
