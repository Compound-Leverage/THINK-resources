# Skill: Crystal ICP Lead Sourcing -- Swarm (Parallel)

This is the parallel-execution version of `crystal-lead-sourcing.md`. It replaces the sequential source loop in Step 1 with a proper concurrent subagent orchestration: all five sources run simultaneously as independent Agent tool calls dispatched in a single message, each returning structured JSON. Use this version:

- **On demand** when speed matters and you need results immediately rather than waiting for sequential source passes
- **Behind-pace mode** when Revenue KR1 pacing score < 0.7 and the CE Goal Orchestrator activates an urgent sourcing run
- Any time the standard Tuesday/Thursday run is insufficient and a same-session full sweep is needed

Standard Tuesday/Thursday scheduled runs may use `crystal-lead-sourcing.md` unless behind-pace mode is active.

**Activation:** Goal-gap triggered by CE Goal Orchestrator when Revenue KR1 pacing < 0.7 or an active capital event is detected. On demand: `/alex crystal-lead-sourcing-swarm`.
**Repo:** `/Users/admin/Documents/GitHub/THINK-internal`
**Output:** `Leads/crystal/alex-[YYYY-MM-DD].csv`

---

## Who Crystal Is

A solopreneur or small business owner (1-5 people) who needs help and does not have the bandwidth or budget to hire. Uneven income. Wearing too many hats. AI is on her radar as a potential solution. Any vertical -- the income pattern and the capacity constraint are the identity.

**All four gates required:**
1. Solopreneur or small business owner (1-5 people); income is project-based, variable, or contract
2. **Labor gap signal** -- cannot hire, cannot keep up, doing work that should not be theirs, position unfilled, team too small for the workload. AI curiosity alone is not sufficient -- the gap must be present.
3. Not already in Contacts DB or Beehiiv as a subscriber
4. Reachable: public email, LinkedIn profile, or contact form accessible

---

## Step 0: Pre-Sourcing Checks

Run both checks before spawning subagents. The outputs -- `priority_queries` and `active_event_sectors` -- get passed into each subagent's prompt.

**Check 1: Placement signals from Julian**

Load `Signals/placement-signals.json` from the repo root. If present and the `generated` date is within the past 30 days:
- Extract `priority_scrape_queries` as `priority_queries` (list of strings)
- Extract `top_placement_sources` -- note for subagent weighting
- Extract `deprioritized_channels` -- pass to subagents as channels to skip

If file is absent or stale (> 30 days): set `priority_queries = []` and fall back to static search strings defined in each subagent below.

**Check 2: Active capital events**

Query Notion Intelligence Inbox (`4bcb512f-9861-476f-945b-9b90ceb6478a`) for entries where Status = Qualified and Last Edited within the past 14 days. Extract: sector tags, geographic focus, cluster name. Combine into `active_event_sectors` (list of strings, e.g. `["workforce development", "Baltimore County", "healthcare training"]`).

If no active events found: set `active_event_sectors = []`.

---

## Step 1: Spawn Five Subagents in Parallel

Dispatch all five subagents in a **single message** as concurrent Agent tool calls. Do not wait for one to complete before starting the next. Each subagent is self-contained and returns a raw JSON array only -- no narrative text.

---

### Subagent A -- LinkedIn Engagement Signals

**Prompt to pass (self-contained):**

You are sourcing Crystal ICP leads from LinkedIn engagement signals. Crystal is a solopreneur or small business owner (1-5 people) with a labor gap -- she cannot hire, cannot keep up, and is doing work that should not be hers.

Use `mcp__scrape-creators__v1_linkedin_search_posts` to find LinkedIn posts published in the past 14 days. If `priority_queries` is non-empty, use those as primary search strings. Otherwise use:
- `"wearing too many hats" solopreneur OR "small business"`
- `"need to hire" OR "overwhelmed" OR "no bandwidth" solopreneur`
- `"AI tools" OR "digital employee" OR "automate" solo founder OR consultant`
- `"hire" OR "can't keep up" freelancer OR "independent consultant" 2026`

For each post that matches Crystal ICP gates, extract the author. Enrich qualifying authors using `mcp__scrape-creators__v1_linkedin_profile`.

Active event sectors (from pre-sourcing): `[INSERT active_event_sectors]`. If a lead's sector matches, note it in `signal_summary`.

Return ONLY a raw JSON array in this exact schema -- no explanation, no markdown:
```
[{"full_name": "", "email": "", "linkedin_url": "", "org": "", "headline": "", "location": "", "source": "alex_linkedin_signal", "signal_summary": ""}]
```
Return `[]` if no qualifying leads found.

---

### Subagent B -- LinkedIn Title Search

**Prompt to pass (self-contained):**

You are sourcing Crystal ICP leads by searching LinkedIn profiles by job title and capacity signals. Crystal is a solopreneur or small business owner (1-5 people) with a labor gap.

Use Scrape Creators to search LinkedIn profiles. If `priority_queries` is non-empty, use those as primary search terms. Otherwise search using these combinations:
- `"Independent Consultant"` + `"AI"` OR `"automation"` + location: United States
- `"Freelance"` + `"workforce development"` OR `"economic mobility"` OR `"training"`
- `"Solopreneur"` + `"looking for tools"` OR `"scaling"` + past 30 days activity
- `"Business Owner"` (1-10 employees) + `"capacity"` OR `"bandwidth"` signal in posts

Extract 5 qualifying profiles per query. Enrich each with `mcp__scrape-creators__v1_linkedin_profile`.

Active event sectors (from pre-sourcing): `[INSERT active_event_sectors]`. If a lead's sector matches, note it in `signal_summary`.

Return ONLY a raw JSON array in this exact schema -- no explanation, no markdown:
```
[{"full_name": "", "email": "", "linkedin_url": "", "org": "", "headline": "", "location": "", "source": "alex_linkedin_search", "signal_summary": ""}]
```
Return `[]` if no qualifying leads found.

---

### Subagent C -- Newsletter Warm Leads

**Prompt to pass (self-contained):**

You are sourcing warm Crystal ICP leads from CL newsletter engagement data. Crystal is a solopreneur or small business owner (1-5 people) with a labor gap who already knows Compound Leverage exists.

Use Beehiiv MCP to find:
1. People who clicked CL newsletter links in the past 30 days but are NOT tagged as active subscribers
2. People who reached the `/training/think-school/` page from a newsletter link but have NOT enrolled

These are warm leads. They know CL but have not converted. Flag each as `source: newsletter_warm`.

If Beehiiv MCP is unavailable or returns an auth error: return `[]` with a note in the `signal_summary` field of a single record: `{"full_name": "", "email": "", "linkedin_url": "", "org": "", "headline": "", "location": "", "source": "newsletter_warm", "signal_summary": "Beehiiv MCP unavailable this run"}`.

Return ONLY a raw JSON array in this exact schema -- no explanation, no markdown:
```
[{"full_name": "", "email": "", "linkedin_url": "", "org": "", "headline": "", "location": "", "source": "newsletter_warm", "signal_summary": ""}]
```
Return `[]` if no qualifying leads found and Beehiiv is available.

---

### Subagent D -- Web and Community Signals

**Prompt to pass (self-contained):**

You are sourcing Crystal ICP leads from web and community discussions. Crystal is a solopreneur or small business owner (1-5 people) with a labor gap -- she cannot hire, cannot keep up, and is actively discussing capacity strain online.

Use WebSearch for Crystal ICP community discussions on Reddit, LinkedIn, and Facebook:
- `"workforce development" "solopreneur" OR "independent consultant" "AI" site:reddit.com OR site:facebook.com 2026`
- `"need help" OR "can't do it all" "small business" "AI tools" site:linkedin.com 2026`
- `"digital employee" OR "virtual employee" "small business owner" -job posting 2026`

If `active_event_sectors` is non-empty, also run sector-specific queries for each sector (e.g. if sector is "workforce development", add: `"workforce development" "solopreneur" "AI" 2026`). Active event sectors: `[INSERT active_event_sectors]`.

For each matching individual, extract profile data. If sector or geography matches an active event sector, note it in `signal_summary`.

Return ONLY a raw JSON array in this exact schema -- no explanation, no markdown:
```
[{"full_name": "", "email": "", "linkedin_url": "", "org": "", "headline": "", "location": "", "source": "alex_web_signal", "signal_summary": ""}]
```
Return `[]` if no qualifying leads found.

---

### Subagent E -- Business Acquirers (Strategist Program)

**Prompt to pass (self-contained):**

You are sourcing business acquirer leads for the Compound Leverage Strategist Program. These are NOT THINK School leads -- they are people who recently acquired a business (within 12 months) and are posting about capacity strain, systems gaps, or operational overwhelm. Revenue exists (it is a real business). They need a DE system built fast, not a course. Route these to the Strategist Program, not to Crystal outreach.

Use WebSearch and Scrape Creators:
- `"acquired" OR "bought a business" "systems" OR "operations" OR "no processes" site:linkedin.com 2026`
- `"search fund" OR "ETA" OR "acquisition entrepreneur" "just closed" OR "day one" OR "took over" 2026`
- `site:reddit.com r/EtA OR r/smallbusiness "acquired" "overwhelmed" OR "no systems" OR "wearing every hat" 2026`
- LinkedIn search: `"Acquisition Entrepreneur"` OR `"Self-Funded Searcher"` -- recent posts about operations challenges

Qualifying signal: acquired within 12 months AND posting about capacity strain, systems gaps, or operational overwhelm.

Return ONLY a raw JSON array in this exact schema -- no explanation, no markdown:
```
[{"full_name": "", "email": "", "linkedin_url": "", "org": "", "headline": "", "location": "", "source": "alex_acquirer_signal", "route": "strategist-program", "signal_summary": ""}]
```
Return `[]` if no qualifying leads found.

---

## Step 2: Merge Results

After all five subagents return:
1. Collect the five JSON arrays
2. Flatten into a single list
3. Remove null records and any record where both `full_name` and `email` are empty strings (except the Beehiiv-unavailable sentinel record, which should be discarded)
4. The merged list is the raw lead pool for deduplication

---

## Step 3: Deduplicate Against Existing Records

For each lead in the merged pool:
1. Query Contacts DB (Notion: `170e1f64`) by email and full name -- skip if already present
2. Query Beehiiv MCP for email match -- skip if already subscribed (active or inactive)
3. Check `Leads/crystal/` directory for the email in any CSV from the past 14 days -- skip if already sourced

Leads that pass all three checks are clean leads.

---

## Step 4: Score Each Clean Lead

Score 0-10. Pass threshold: 6+.

| Signal | Points |
|---|---|
| Clear solopreneur/1-5 employee signal | +2 |
| Active capacity or bandwidth frustration signal in posts/bio | +2 |
| AI curiosity or tool-seeking signal explicit in content | +2 |
| Email directly accessible (not just LinkedIn) | +2 |
| Recent activity (post or engagement in past 14 days) | +1 |
| Workforce development, EDO, or nonprofit adjacent | +1 |
| Capital event sector/geo match (from `active_event_sectors`) | +2 bonus |

For any lead receiving the +2 capital event bonus: add `cluster_name` to their record and note the matched sector in `signal_summary`. Sarah uses this to open outreach with the specific event.

---

## Step 5: Enrich Qualifying Leads

For each lead scoring 6+:
- Pull full LinkedIn profile via `mcp__scrape-creators__v1_linkedin_profile`
- Extract: full name, headline, email (if available), org, location, recent post content
- Confirm `source` tag is set correctly per the originating subagent

Strategist Program leads (from Subagent E) that score 6+ are enriched the same way and included in the output with `route: strategist-program`.

---

## Step 6: Output

Write qualifying enriched leads to `Leads/crystal/alex-[YYYY-MM-DD].csv` with columns:
```
full_name, email, linkedin_url, org, headline, location, score, source, signal_summary, route
```

`route` field values:
- `email_available` -- Sarah runs crystal-outreach email sequence
- `linkedin_only` -- Sarah considers LinkedIn DM (if DM skill exists)
- `newsletter_warm` -- flag separately for Sarah; these get a direct THINK School invite, not a cold email
- `strategist-program` -- do NOT send to Sarah's Crystal queue; flag separately for Marvin to follow up

Append run completion to `Logs/completions.log`:
```
[timestamp] alex crystal-lead-sourcing-swarm: [N] leads found across 5 sources, [N] scored 6+, [N] clean (deduped)
```

---

## Step 7: Hand Off

Alex does not message Sarah directly. Sarah picks up `Leads/crystal/alex-*.csv` files on Sunday as part of her weekly load.

On-demand runs (explicit `/alex crystal-lead-sourcing-swarm` trigger) log a DM to Marvin with lead count so he can decide to advance Sunday's queue-build. Include a one-line breakdown by source in the DM: `A: [n] | B: [n] | C: [n] | D: [n] | E: [n] | Clean: [n] | 6+: [n]`.
