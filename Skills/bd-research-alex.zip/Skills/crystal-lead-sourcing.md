# Skill: Crystal ICP Lead Sourcing

Alex actively sources Crystal-profile leads through signal detection and web research. He operates in parallel with Lori but uses different sources — LinkedIn engagement signals, community discussions, event activity, and content interaction patterns rather than Lori's Beehiiv/forum-scan approach.

**Activation:** Goal-gap triggered by CE Goal Orchestrator when Revenue KR1 pacing < 0.7 or an active capital event is detected. On demand: `/alex crystal-lead-sourcing`.  
**Repo:** `/Users/admin/Documents/GitHub/THINK-internal`  
**Output:** `Leads/crystal/alex-[YYYY-MM-DD].csv`

---

## Who Crystal Is

A solopreneur or small business owner (1-5 people) who needs help and does not have the bandwidth or budget to hire. Uneven income. Wearing too many hats. AI is on her radar as a potential solution. Any vertical — the income pattern and the capacity constraint are the identity.

**Pre-sourcing: check placement signals from Julian**

Check `Signals/placement-signals.json` in the repo root. If present and `generated` date is within the past 30 days:
- Load `priority_scrape_queries` — use these as the primary search strings for Sources A and B, replacing the static defaults below. Julian derived these from actual `path-placement` subscriber behavior — they are more accurate than static queries.
- Load `top_placement_sources` — weight these channels first in the search order
- Load `deprioritized_channels` — skip these sources this run (zero placement attribution in the past 30 days)

If file is absent or stale (> 30 days): fall back to the static search strings in Sources A–D below.

**Pre-sourcing: check active capital events**

Query Notion Intelligence Inbox (`4bcb512f-9861-476f-945b-9b90ceb6478a`) for entries where Status = Qualified and Last Edited within the past 14 days. Extract: sector tags, geographic focus, cluster name. Leads sourced in those same sectors and geographies are highest priority — the capital event has created a labor gap, which creates the placement need.

**All four gates required:**
1. Solopreneur or small business owner (1-5 people); income is project-based, variable, or contract
2. **Labor gap signal** — cannot hire, cannot keep up, doing work that should not be theirs, position unfilled, team too small for the workload. AI curiosity alone is not sufficient -- the gap must be present.
3. Not already in Contacts DB or Beehiiv as a subscriber
4. Reachable: public email, LinkedIn profile, or contact form accessible

**Priority scoring boost:** If the lead's sector or geography matches an active capital event from the pre-sourcing check, add +2 to their score and include `cluster_name`, `signal_summary`, and event window dates in the CSV output. Sarah uses this to open outreach with the specific event. A lead with a labor gap AND capital event proximity is the highest-intent prospect in the system.

---

## Step 1: Signal Sources (run all four in parallel)

### Source A — LinkedIn Engagement Signals
Use Scrape Creators MCP to identify Crystal ICP individuals engaging with relevant content:
- Search for LinkedIn posts in the past 14 days using queries:
  - `"wearing too many hats" solopreneur OR "small business"`
  - `"need to hire" OR "overwhelmed" OR "no bandwidth" solopreneur`
  - `"AI tools" OR "digital employee" OR "automate" solo founder OR consultant`
  - `"hire" OR "can't keep up" freelancer OR "independent consultant" 2026`
- For each matching post, extract the author's profile if they are Crystal ICP
- Use `mcp__scrape-creators__v1_linkedin_profile` to enrich qualifying authors

### Source B — LinkedIn Search (job title + signal)
Use Scrape Creators to search LinkedIn profiles matching Crystal ICP job titles:
- `"Independent Consultant"` + `"AI"` OR `"automation"` + location: United States
- `"Freelance"` + `"workforce development"` OR `"economic mobility"` OR `"training"`
- `"Solopreneur"` + `"looking for tools"` OR `"scaling"` + past 30 days activity
- `"Business Owner"` (1-10 employees) + `"capacity"` OR `"bandwidth"` signal in posts

Extract 5 qualifying profiles per query. Enrich with Scrape Creators.

### Source C — Newsletter Adjacent Signals (non-subscribers)
Use Beehiiv MCP to identify people who have:
- Clicked CL newsletter links in the past 30 days but are NOT tagged as active subscribers
- Reached the `/training/think-school/` page from the newsletter but have NOT enrolled

These are warm leads who know CL exists but haven't converted. Flag as `source: newsletter_warm`.

### Source D — Web/Community Signals
Use WebSearch for Crystal ICP community discussions:
- `"workforce development" "solopreneur" OR "independent consultant" "AI" site:reddit.com OR site:facebook.com 2026`
- `"need help" OR "can't do it all" "small business" "AI tools" site:linkedin.com 2026`
- `"digital employee" OR "virtual employee" "small business owner" -job posting 2026`

Extract any individual whose profile or post history matches Crystal ICP gates.

### Source E — Business Acquirers (Strategist Program leads — route separately)
Business acquirers are NOT THINK School leads. They route to the `strategist-program` campaign. Flag with `route: strategist-program` in the CSV.

Use WebSearch and Scrape Creators:
- `"acquired" OR "bought a business" "systems" OR "operations" OR "no processes" site:linkedin.com 2026`
- `"search fund" OR "ETA" OR "acquisition entrepreneur" "just closed" OR "day one" OR "took over" 2026`
- `site:reddit.com r/EtA OR r/smallbusiness "acquired" "overwhelmed" OR "no systems" OR "wearing every hat" 2026`
- LinkedIn search: `"Acquisition Entrepreneur"` OR `"Self-Funded Searcher"` — recent posts about operations challenges

**Qualifying signal for acquirers:** They recently acquired (within 12 months) and are posting about capacity strain, systems gaps, or operational overwhelm. Revenue exists (it's a real business). They need a DE system built fast, not a course. Strategist Program is the offer.

Assign `campaign: strategist-program` in the `route` field of the CSV. Do NOT send to Sarah's Crystal outreach queue. Flag separately for Marvin or Blair to follow up.

---

## Step 2: Deduplicate Against Existing Records

For each lead found across all four sources:
1. Query Contacts DB (Notion: `170e1f64`) by email and full name — skip if already present
2. Query Beehiiv MCP for email match — skip if already subscribed (active or inactive)
3. Check `Leads/crystal/` directory for the email in any CSV from the past 14 days — skip if already sourced

Leads that pass dedup are clean leads.

---

## Step 3: Score Each Clean Lead

Score 0-10. Pass threshold: 6+.

| Signal | Points |
|---|---|
| Clear solopreneur/1-5 employee signal | +2 |
| Active capacity or bandwidth frustration signal in posts/bio | +2 |
| AI curiosity or tool-seeking signal explicit in content | +2 |
| Email directly accessible (not just LinkedIn) | +2 |
| Recent activity (post or engagement in past 14 days) | +1 |
| Workforce development, EDO, or nonprofit adjacent | +1 |
| Explicit "hire AI / digital employee" language indicating Lane 1 intent | +1 (flag for Marvin alongside CSV — this is a Managed DE lead, not THINK School) |

**Lane Qualifier rule:**
- Score 6+, learn-to-build signal present → `lane_qualifier: 2` (THINK School)
- Score 6+, "hire someone to do it" or explicit DE hire signal → evaluate budget before assigning Lane 1. **Budget required:** active client base, funded engagements, or business revenue signals present in bio or posts (not pre-revenue or aspirational). If budget confirmed → `lane_qualifier: 1` (Managed DE), flag separately for Marvin, do not send to Sarah's Crystal queue. If no budget signal → `lane_qualifier: 2` with note "Lane 1 intent, budget unconfirmed."
- Source E (acquirers) → **budget required:** confirmed acquisition of a revenue-generating business (not an LOI or in-search phase). If acquisition confirmed → `lane_qualifier: 3` (Strategist Program). If pre-acquisition → `lane_qualifier: 2` with note "Lane 3 intent, acquisition not confirmed."

---

## Step 4: Enrich Qualifying Leads

For each lead scoring 6+:
- Pull full LinkedIn profile via `mcp__scrape-creators__v1_linkedin_profile`
- Extract: full name, headline, email (if available), org, location, recent post content
- Assign `source` tag: `alex_linkedin_signal`, `alex_linkedin_search`, `newsletter_warm`, or `alex_web_signal`

---

## Step 5: Output

Write qualifying enriched leads to `Leads/crystal/alex-[YYYY-MM-DD].csv` with columns:
```
full_name, email, linkedin_url, org, headline, location, score, source, signal_summary, route, capacity_problem, recommended_de, lane_qualifier
```

`route` field:
- `email_available` → Sarah runs crystal-outreach email sequence
- `linkedin_only` → Sarah considers LinkedIn DM (if DM skill exists)
- `newsletter_warm` → flag separately for Sarah — these get a direct THINK School invite, not a cold email

`capacity_problem` field: one sentence naming what they cannot do (derived from the signal that qualified them). Example: "Cannot keep lead pipeline full while delivering client work." If capital event sector match is present from the pre-sourcing check, reference it: "No system to track AI workforce funding opportunities in their practice vertical."

`recommended_de` field: default Crystal solopreneurs → `Alex + Sarah (THINK School library)`. Lane 1 signals → match to the roster by problem type. Lane 3 (acquirers) → `Alex + Sarah + Kyle + Lincoln (Full DE Stack)`.

`lane_qualifier` field: 1 / 2 / 3 per the Lane Qualifier rule in Step 3.

**High-priority routing:** Score 8+ AND active capital event sector match from the pre-sourcing check → also write a Placement Lead Record to Deals Pipeline (`789edd2b`) as a Prospect entry alongside the CSV output. These are not just profile leads — they are confirmed placement candidates with an active mandate context.

```
PLACEMENT LEAD RECORD
Org:              [name or practice name]
Trigger Event:    [capital event from pre-sourcing check — program name, sector, window]
Capacity Problem: [from capacity_problem field]
Recommended DE:   [from recommended_de field]
Lane:             [from lane_qualifier field]
Decision Maker:   Solopreneur / Practice Owner
Budget Signal:    [one sentence: revenue signals confirmed — active clients, funded engagements, or stated business revenue]
Priority Score:   [score * 10]
```

Append run completion to `Logs/completions.log`: `[timestamp] alex crystal-lead-sourcing: [N] leads found, [N] scored 6+, [N] new (deduped), [N] Deals Pipeline records created`

---

## Step 6: Hand Off

Alex does not message Sarah directly. Sarah picks up `Leads/crystal/alex-*.csv` files on Sunday as part of her weekly load. On-demand runs (explicit `/alex crystal-lead-sourcing` trigger) log a DM to Marvin with lead count so he can decide to advance Sunday's queue-build.
