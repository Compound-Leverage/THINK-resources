# KLR Signal Radar

Monitors KLR source for capital event and labor gap signals. Converts hits into placement lead records for Sarah's outreach queue.

## Signal targets

- Capital event announcements (grants, program launches, federal disbursements) affecting target org types
- Organizations with visible labor gap indicators: hiring freezes alongside program growth, new compliance obligations, expansion without headcount
- Sector-specific signals matching Gail ICP (operator-led, 10-50 FTE, capital event active) or Crystal ICP (expertise holder with adjacent sector activity)

## Process

1. Pull KLR signal feed for the scan period
2. Filter for ICP-relevant organizations and capital event types
3. Enrich matches via Scrape Creators (LinkedIn company + contact) and Clay where credits allow
4. Score: capital event proximity + labor gap strength + ICP fit
5. Write qualified leads to Notion Contacts and Deals Pipeline

## Output

Placement lead records in Notion. Handoff ping to Sarah with count and top-scored org.

## Threshold

Standard: 60+ → Deals Pipeline. Warm intro (Marvin/Inncuvate connection): 55+ → Deals Pipeline. Below threshold → Contacts only.

## Cadence

Weekly, alongside Finance360 and JT Workforce sweeps. Deduplicates against all existing pipeline entries before writing.
