# Skill: Newsletter Growth and Site Traffic Sourcing

Alex identifies people who should be in the CL newsletter but aren't, detects content signals that drive site traffic, and feeds both to the agents who act on them (Sarah for outreach, Julian for experiments, Justin for content).

**Run cadence:** Wednesday 6:00 AM ET. On demand: `/alex newsletter-growth`.  
**Output:** `output/newsletter-growth/alex-[YYYY-MM-DD].md`

---

## Part 1: Newsletter Invite List (Who Should Be a Subscriber)

### Source A — Warm Engagers (Not Subscribed)

Use Scrape Creators MCP to find people engaging with CL-adjacent LinkedIn content who are not subscribers:
- Search: `site:linkedin.com "Marvin Harris" Compound Leverage` — identify people commenting on or reacting to Marvin's content
- Search: `"workforce development" OR "economic mobility" "AI" "digital employee" site:linkedin.com 2026` — find Crystal-adjacent people discussing topics CL covers
- Extract profiles, cross-check against Beehiiv MCP subscriber list by name/email. Flag anyone not present.

### Source B — Event and Community Signals

Use WebSearch:
- Search recent workforce development, HBCU, and AI-for-business conferences/events where CL's ICP gathers
- Identify speakers, panelists, or attendees who are listed publicly and match Crystal or Gail ICP
- Flag anyone without CL newsletter subscription (check Beehiiv by name/org if email not directly available)

### Source C — Content Click-Throughs Without Conversion

Use Beehiiv MCP to query:
- Subscribers who clicked to `/training/think-school/` or `/findyourstart/` in the past 30 days but are NOT tagged as `think-school member` or `think-school trial`
- These are warm — they showed intent but didn't convert. Flag for Sarah's Crystal outreach as `newsletter_warm_intent` with their specific click as the context.

### Source D — Referral Network Scan

Use Notion MCP to query Contacts DB (`170e1f64`):
- Pull all contacts tagged as `Referred` or `Partner` who are not tagged as newsletter subscribers
- Anyone in CL's contact network who is not a subscriber is a missed invite

---

**Output for Part 1:**

For each person identified:
- Full name, email (if available), source, ICP match (Crystal / Gail / Neither), reason to invite
- Assign action:
  - `direct_invite` — Sarah sends a personal newsletter invite email (short, 2 sentences, no pitch)
  - `crystal_outreach` — passes to Alex's crystal-lead-sourcing skill output (if Crystal ICP and no email sequence yet)
  - `marvin_review` — Gail ICP or ambiguous — Marvin decides whether to add or hand to Sarah

Write the invite list to `output/newsletter-growth/alex-[date].md` under `## Newsletter Invite List`.

---

## Part 2: Site Traffic Signal Detection

Alex identifies what content topics are driving organic interest in Crystal and Gail communities, then routes findings to Julian (growth experiments) and Justin (LinkedIn content queue).

### Signal Source 1 — Community Questions
Use WebSearch:
- `"workforce development" "AI" OR "digital employee" question site:reddit.com OR site:quora.com 2026`
- `"HBCU" "grants" OR "AI" "help" OR "how to" site:reddit.com 2026`
- `"solopreneur" "hire" OR "AI assistant" OR "virtual employee" question 2026`

Extract: the question or thread, platform, engagement signal (upvotes, replies), topic cluster.

### Signal Source 2 — Rising Search Terms
Use WebSearch to identify what Crystal and Gail ICP people are actively searching for that CL could own:
- `"digital employee for" hire OR staffing site:google.com OR site:bing.com -"job posting" 2026`
- `"AI workforce development" training OR course OR consultant 2026`
- `"grant capture" AI OR automation university OR HBCU 2026`

Flag any query where CL does not currently have ranking content but the topic directly maps to CL's offer.

### Signal Source 3 — Competitor Content Gaps
Use WebSearch to check what CL's adjacent competitors (AI staffing, DE agencies, grant management firms) are publishing that CL is not:
- Search: `"digital employee" OR "AI employee" staffing company content 2026`
- Identify 1-2 content angles they are covering that CL isn't, where CL has the proof to do it better

---

**Output for Part 2:**

Write findings under `## Site Traffic Signals` in the same output file:
- **Top 3 questions** CL should answer (topic, platform, engagement level)
- **Top 2 search gaps** — queries where CL has no content but should
- **1 competitor gap** — what they're publishing that CL could own with proof

Route:
- Traffic signals → include in file tagged `[→ Julian]`
- Content topics → include in file tagged `[→ Justin]`
- Julian and Justin pick up Wednesday output on their next run

---

## Part 3: Content Intelligence Scrape (Labor Market Signals)

Alex scans Reddit and LinkedIn for verbatim Crystal and Gail ICP language — complaints, frustrations, questions, breakthrough moments — and writes them as `labor_market_signal` card candidates into the Notion Content Inbox before the Sunday pipeline runs. Kyle processes them Sunday into `topic-cards.json`. Ann and Joanna use them as Priority 0 sources.

This is the only automated pipeline that feeds verbatim audience language into the content system.

**What to look for:** labor gap signals -- posts where a person or org expresses that work is not getting done, they cannot hire, they are doing work themselves that should belong to someone else, or their team is too small for the workload. This is the primary intent signal for a DE placement. Capture the verbatim language -- that exact phrasing is what Ann and Joanna open content with.

### Source A — Reddit verbatim scrapes

Use `mcp__scrape-creators__v1_reddit_search` and `mcp__scrape-creators__v1_reddit_subreddit_search`:
- Search: `"can't afford to hire" OR "need to hire but" OR "doing everything myself"` — r/solopreneur, r/entrepreneur, r/smallbusiness
- Search: `"wearing too many hats" OR "can't keep up" OR "I am the bottleneck"`  — same subreddits
- Search: `"position unfilled" OR "short staffed" OR "no one to do it" workforce development`
- For each result: pull the post body or comment that names the specific work that is not getting done or the gap that exists. That is the labor gap signal.
- Collect posts with 10+ upvotes or 3+ comments.

### Source B — LinkedIn verbatim scrapes

Use `mcp__scrape-creators__v1_linkedin_search_posts`:
- Search: `"we cannot find" OR "still looking for" OR "position has been open" 2026`
- Search: `"I have been doing this myself" OR "no one to handle" solopreneur OR consultant 2026`
- Search: `"understaffed" OR "team is too small" workforce development OR HBCU OR nonprofit 2026`
- For each result: capture the exact post text (or the most quotable 1-3 sentences) that names the labor gap, and the author's job title/org type.

### Structuring signal cards

For each verbatim quote collected (target: 3-6 strong ones per Wednesday run):

Write a Notion page to the Content Inbox (`4bcb512f-9861-476f-945b-9b90ceb6478a`) with:
- **Title:** `[labor_market_signal] [2-3 word topic tag] — [date]`
- **Body:** the verbatim quote exactly as written, followed by:
  - Source: [Reddit post URL or LinkedIn post URL]
  - ICP: Crystal or Gail
  - Signal type: [capacity constraint / hire intent / AI curiosity / opportunity gap / frustration]
  - Composite score: estimate 65-80 based on specificity and resonance (70+ if it names a specific pain, 65 if general)
- **Status:** Unprocessed (Kyle picks it up Sunday)

Do not paraphrase. The verbatim language is the asset. Kyle will structure it; Ann and Joanna will use it as their opening line.

---

**Output for Part 3:**

Append to the same output file under `## Labor Market Signals`:
- Number of Notion Inbox entries written
- Top quote (the one with the highest estimated resonance)

Update completions log:
```
[timestamp] alex newsletter-growth: [N] invite prospects, [N] direct_invite, [N] crystal_outreach, [N] marvin_review — [N] traffic signals → Julian/Justin — [N] labor_market_signals → Notion Inbox
```
