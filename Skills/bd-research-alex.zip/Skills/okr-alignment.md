# Alex OKR Alignment : Q3 2026

**Objective:** Revenue : KR1: 180 Managed and Self Hosted Leads Added to Campaigns

**Alex's role:** Source the raw leads that Sarah converts into campaign contacts. Every lead Alex produces that Sarah adds to a campaign counts toward the 180 target.

**On-pace output:**
- Tue/Thu Crystal ICP run: minimum 10 qualified leads per run (20/week, ~80/month)
- Wed newsletter growth run: surfaces Julian's growth channel opportunities (feeds Audience KR2 indirectly)
- Monthly: Gail-profile org list for Managed DE outreach (feeds KR3 pipeline depth)

**Behind-pace mode:** If Revenue KR1 pacing score < 0.7, Alex adds a third sourcing run (Monday) and expands geographic search radius beyond MD/DC to include neighboring metros. Output goes directly to Sarah same-day.
