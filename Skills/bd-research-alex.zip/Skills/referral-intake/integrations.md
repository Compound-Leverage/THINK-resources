# Alex — Enrichment Integrations

Used during referral intake and on-demand lead enrichment. Run after ICP scoring to fill contact and company gaps before handing off to Sarah.

## Scrape Creators Tools

| Tool | Use when |
|------|----------|
| `linkedin_profile` | Contact name + company known but title/bio/role missing |
| `linkedin_company` | Org size, industry, headcount, or founding date unknown |
| `linkedin_company_posts` | Need recent signals on org priorities, hiring, announcements |
| `google_search` | General web research — press releases, news, grants received, leadership changes |

## Enrichment Sequence

Run only when the referral record is QUALIFIED or POSSIBLE (score 3+). Skip for LOW FIT.

### Step 1 — Company enrichment
If `referral_business` is present:
1. `linkedin_company` — pull: employee count, industry, headquarters, description
2. `linkedin_company_posts` (last 5 posts) — scan for: hiring signals, grant announcements, workforce language, DE/AI mentions

### Step 2 — Contact enrichment
If `referral_name` is present:
1. `linkedin_profile` — pull: current title, current org, tenure, bio summary
2. If LinkedIn profile not found: `google_search` for `"[name]" "[company]"` — extract title and any public contact info

### Step 3 — Signal boost
Re-score after enrichment. If new signals surface that add ICP points (e.g., LinkedIn post mentions WIOA or workforce grants), update the ICP score and rationale in the Notion record before invoking Sarah.

### Step 4 — Write enrichment to record
Use `notion-update-page` to add to Notes field:
```
[Enrichment — Alex]
Company: [size] employees · [industry] · [HQ]
Contact: [title] at [org] since [year]
Recent signals: [1-2 line summary of LinkedIn post signals]
Enriched: [date]
```

## Fallback
If Scrape Creators returns no result for a LinkedIn lookup, fall back to `google_search` for the same query. If both return nothing, note "Enrichment: not found" in the record and proceed with available data.

## Rate awareness
Check credit balance at start of each enrichment run:
`v1_account_credit_balance` — if balance < 10 credits, skip enrichment and log a low-credit warning to Google Chat.
