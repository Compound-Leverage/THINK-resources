# Referral Intake — Rules

## Alex's scope

Alex qualifies and passes the handoff. He does not draft outreach copy. That is Sarah's job.

Alex does NOT:
- Send any external email
- Enrich the referral via Clay (Clay is for Gail-profile pipeline enrichment, not inbound referrals)
- Research the referral on LinkedIn
- Contact the referrer to ask clarifying questions

## ICP scoring is directional, not a hard gate

POSSIBLE referrals (score 3-4) still get outreach drafted. The score is passed to Sarah so she can calibrate the warmth and confidence level of the email. A POSSIBLE referral may just be from a market CL hasn't named explicitly — Marvin decides at the Gmail draft review whether to send.

LOW FIT is the only classification that skips outreach. Score 0-2 means no geographic signal and no workforce/economic development signal and no capacity signal — three misses.

## Referral reason is qualitative

The scoring rubric uses keywords as proxies, but use judgment. "She runs a grant program for a community college in PG County" scores +4 even if those exact keywords don't appear. Match the intent of the signal, not just the words.

## Duplicate referrals

If the same referral email already exists in the Deals Pipeline (Status = anything other than "New"): note the duplicate in the Notion task description ("Note: referral email already exists in pipeline — record ID [X]"). Still process the new record but flag the overlap so Marvin knows.

## Sarah's outreach tone calibration

Pass the ICP score to Sarah explicitly. Sarah should:
- QUALIFIED: confident, direct, reference the referrer warmly, clear CTA
- POSSIBLE: softer qualifier in the opener, let the referrer relationship carry the open, shorter email
