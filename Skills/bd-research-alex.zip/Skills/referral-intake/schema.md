# Referral Intake — Schema

## Notion Database IDs

| Database | ID |
|---|---|
| Deals Pipeline | 789edd2b-162d-479b-aac6-06e6fdd1a04d |

## Record Fields Read

| Field | Type | Notes |
|-------|------|-------|
| Name | title | "[referral_name] — [referral_business]" |
| Email | email | referral's email |
| Source | select | filter value: "Referral" |
| Stage | select | "New Referral" |
| Status | select | filter value: "New" |
| Referrer Name | rich_text | who submitted the referral |
| Referrer Email | rich_text | referrer's email |
| Referral Reason | rich_text | why they thought of this person |
| Submitted Date | date | ISO date |

## Status Transitions

```
New → Processed (qualified/possible, drafts completed)
New → Low Fit (ICP score 0-2)
New → Sarah Failed — Manual Review (Sarah sub-agent error)
```

## Marvin User ID (for @mention)

`1e84ee83-25c6-4ac3-a3c9-da439bd9a30c`

## Environment Variables

- `NOTION_API_KEY` — Notion read/write (GitHub Secret, already present)

## Log Path

`Logs/alex-intake/YYYY-MM-DD.log`
