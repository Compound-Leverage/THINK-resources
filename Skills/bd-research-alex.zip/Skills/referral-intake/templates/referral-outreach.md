# Referral Outreach Email Template

**From:** marvin@compoundleverage.com (Marvin's draft — he sends)
**To:** [referral email]
**CC:** marvin@compoundleverage.com (already the sender — no CC needed)
**Subject:** [Referrer Name] suggested I reach out

---

## QUALIFIED template (score 5-6)

```
Subject: [Referrer Name] suggested I reach out

[First name],

[Referrer Name] mentioned you and I wanted to follow up directly.

[One sentence connecting the referrer's context to why this is relevant. Example: "She mentioned you're managing a workforce training program and dealing with the same bandwidth problem a lot of her peers are wrestling with."]

We help organizations like yours run research, outreach, and operational work through a team of Digital Employees — AI agents configured for your specific workflow. No extra headcount. The work just gets done.

[Referrer Name] can vouch for how it works in practice. Happy to show you what it looks like for your situation.

Worth 20 minutes?

Marvin Harris
Compound Leverage
```

---

## POSSIBLE template (score 3-4)

```
Subject: [Referrer Name] thought we should connect

[First name],

[Referrer Name] suggested I reach out — thought there might be some overlap between what we do and what you're working on.

We help organizations run research, outreach, and operational workflows through AI-configured Digital Employees. It works best when there's a bandwidth or timing problem to solve.

If that's relevant to what you're dealing with, I'm happy to share more. If not, no worries at all.

Marvin Harris
Compound Leverage
```

---

## Rules for Sarah

- Use the referral's first name in the opener
- Reference the referrer by name in the first sentence — the warm intro is the only reason to open this email
- No pricing. No product names. No "THINK Methodology."
- No em dashes anywhere
- Under 150 words for QUALIFIED, under 100 for POSSIBLE
- Do NOT invent claims about what the referral is dealing with unless it's directly stated in the Referral Reason — use hedging language ("thought there might be some overlap")
- CTA is a soft ask (20-minute call, not "book a demo" or "sign up")
- Plain text style. No HTML headers. `<p>` tags only if HTML is required.
