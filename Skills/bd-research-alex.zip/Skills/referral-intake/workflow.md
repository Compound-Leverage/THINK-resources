# Referral Intake — Workflow

**Agent:** Alex Schultz (BD Research)
**Sub-agent:** Sarah Grant (BD Execution)
**Trigger:** Daily queue sweep — runs as part of Alex's signal detection pass

---

## When This Runs

Any time a new record exists in the Deals Pipeline with:
- Source = "Referral"
- Status = "New"

Records are created automatically when someone submits the form at compoundleverage.com/referral.

---

## Step 1: Fetch the queue

Use Notion MCP `notion-query-database-view` to query the Deals Pipeline.

Filter: Source = "Referral" AND Status = "New"

If queue is empty: log the empty run and stop. No output.

---

## Step 2: Qualify each referral

For each record:

**2a. Read the record**
Pull: Referral Name, Referral Business, Referrer Name, Referrer Email, Referral Reason.

**2b. Score against CL ICP**

Score from 0-6. Add points for each signal present:

| Signal | Points | How to detect |
|--------|--------|---------------|
| MD-based or Mid-Atlantic geography | +2 | Business name, referral reason mentions location, or recognizable MD org |
| Workforce or economic development adjacent | +2 | "workforce," "economic development," "community," "workforce board," "HBCU," "EDO," "training," "grants," "research," in referral reason or business name |
| Capacity/velocity mismatch signal | +2 | "behind," "overwhelmed," "can't keep up," "not enough staff," "manual," "falling through cracks," "missing opportunities," "too slow" in referral reason |

**Score interpretation:**
- 5-6: QUALIFIED — strong ICP match, proceed to Sarah
- 3-4: POSSIBLE — partial match, still proceed to Sarah with ICP note
- 0-2: LOW FIT — does not match ICP, flag for Marvin, skip Sarah sub-agent

**2c. Write the ICP score and classification to the record**

Use Notion MCP `notion-update-page` to add a rich_text note to the record before processing:
- Field (or Notes): "ICP Score: [N]/6 — [QUALIFIED/POSSIBLE/LOW FIT] — [one-sentence rationale]"

---

## Step 3: Handle LOW FIT records

If classification = LOW FIT:
1. Update Status to "Low Fit"
2. @mention Marvin in a comment: "New referral flagged LOW FIT (Score [N]/6). From [Referrer Name]. Referral: [Referral Name] at [Business]. Reason: [brief rationale]. Recommend: no outreach unless Marvin directs otherwise."
3. Log and move to next record. Do not invoke Sarah.

---

## Step 4: Invoke Sarah as sub-agent (QUALIFIED and POSSIBLE only)

Pass Sarah this handoff block:

```
INTAKE TYPE: referral-outreach
REFERRAL: [referral_name], [referral_business]
REFERRAL EMAIL: [referral_email]
REFERRER: [referrer_name]
ICP SCORE: [N]/6 — [classification]
WHY THEM: [referral_reason, verbatim]
DEAL RECORD ID: [Notion record ID]
GMAIL ACTION: create_draft to Marvin's Gmail
NOTION ACTION: child page in Deals Pipeline record [ID], title: "Review and send outreach to [referral name]"
MENTION: 1e84ee83-25c6-4ac3-a3c9-da439bd9a30c
```

Sarah will:
1. Draft a warm outreach email (see `templates/referral-outreach.md`)
2. Create the Gmail draft via `mcp__claude_ai_Gmail__create_draft`
3. Create a child page in the Deals Pipeline record as a task for Marvin
4. @mention Marvin in a comment on the record

---

## Step 5: Update record status

After Sarah confirms completion, use Notion MCP `notion-update-page` to set Status to "Processed".

---

## Step 6: Log the run

Append to `Logs/alex-intake/YYYY-MM-DD.log`:
```
[timestamp] | alex | referral-intake | [N] processed ([N] qualified, [N] possible, [N] low fit) | [names]
```

Post to Google Chat only on exception:
- Sarah sub-agent returned an error
- Queue had entries but zero were processed

Routine completions are silent.
