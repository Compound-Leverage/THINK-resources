# Alex Schultz -- Hook Map

| When to run | Trigger type | Trigger value | Action |
|---|---|---|---|
| Mon-Fri 7:00 PM ET | Cron | `0 19 * * 1-5` | Run `/referral-intake` -- sweep referral submissions, score ICP, pass to Sarah |
| Mon-Fri 11:00 AM ET | Cron | `0 15 * * 1-5` | Run `campaign-lead-sourcing.md` -- one hour after Scott's Campaign Builder run, so new Campaign Hub records exist to source against |
| On demand | Explicit ask | "Alex: run [skill name]" or Marvin requesting an add regardless of buffer state | Run named skill |

## Notes

- Alex Schultz operates primarily as the research and lead enrichment layer.
- `/referral-intake` pulls from referral forms and qualifies leads before handing them off to Sarah.
- Alex works in tandem with Sarah to feed structured data for BD outreach.
- `campaign-lead-sourcing.md`: keeps each Active Consortium Campaign's lead buffer at its real `Placement Target` + 20%, stops at that ceiling, resumes when the buffer drops back to or below `Placement Target` or on Marvin's explicit request. Defers to Cassie's Window Closed status -- never sources for a campaign her pause logic has closed.
