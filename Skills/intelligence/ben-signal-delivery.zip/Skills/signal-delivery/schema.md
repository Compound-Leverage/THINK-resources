# Ben Thompson Signal Delivery Schema

## Notion
- Intelligence Inbox DB: `NOTION_INTEL_INBOX_ID` env var
- Brief output DB: `NOTION_BRIEF_OUTPUT_ID` env var

## Google Drive
- Client briefs folder: `BEN_GDRIVE_FOLDER_ID` env var
- Permissions: shared with client directly after creation

## Env vars
- `BEN_WEBHOOK_URL`: Google Chat findings webhook
- `NOTION_TOKEN`: Notion integration token
- `NOTION_INTEL_INBOX_ID`: Intelligence Inbox database ID
- `NOTION_BRIEF_OUTPUT_ID`: Brief output database ID
- `BEN_GDRIVE_FOLDER_ID`: Google Drive destination folder ID

## Output format
Brief documents: `CL_Brief_{topic}_{date}.md` stored in Google Drive.
Notion output: one record per brief with link to Drive file and summary.
