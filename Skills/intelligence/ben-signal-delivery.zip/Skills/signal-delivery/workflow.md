# Signal Delivery Workflow

1. Query the Notion Intelligence Inbox for unprocessed capital event signals matching the active client scope.
2. For each qualifying signal, synthesize a Stratechery-style brief: market context, strategic implication, and recommended client action.
3. Write the completed brief as a structured document to the designated Google Drive client folder.
4. Post a delivery summary to the Ben Thompson findings Google Chat space; flag any signals that could not be qualified or require Marvin judgment.

## Email Delivery (client send)

5. **Format as HTML email.** Use the Drive link as the primary CTA. Subject: `[Org Name] Intelligence Brief — [Brief Title] — [Date]`. Body: 2-3 sentence framing of the key signal, then the button.

   ```html
   Hi [first_name],
   
   Here is your latest capital event intelligence brief: [Brief Title].
   
   [One sentence on the core signal and why it matters to this client's portfolio.]
   
   [Read Brief button → Drive link]
   
   Marvin Harris
   Compound Leverage | marvin@compoundleverage.com
   ```

   **Button:**
   ```html
   <a href="[DRIVE_LINK]" style="display:inline-block;background-color:#6B21A8;color:white;
   padding:10px 20px;border-radius:4px;text-decoration:none;font-weight:bold;">
   Read Brief
   </a>
   ```

6. **Marvin approval gate.** Post to Google Chat:
   ```
   BEN — BRIEF READY: [Brief Title]
   Client: [Org Name] | Drive: [link]
   Reply SEND to deliver, HOLD to pause.
   ```
   Do not send until Marvin replies SEND.

7. **Send on GO.** Send via `config.zapier_marvin_send_action_url`. From: marvin@compoundleverage.com.
   After send: update Notion Intelligence Inbox record (status = Delivered, delivered_date = today). Log to Google Chat: `BEN — BRIEF SENT: [Brief Title] to [client name]`.

## Rules
- No external send without Marvin GO
- One email per brief per client — do not re-send if already delivered
- No em dashes in copy
- From is always marvin@compoundleverage.com
