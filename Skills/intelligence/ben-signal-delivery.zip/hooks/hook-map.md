# Hook Map — Ben Thompson

| Trigger | When to run | Skill fired |
|---------|-------------|-------------|
| New CE signals present in Intelligence Inbox | On demand or scheduled Inbox sweep | signal-delivery/workflow.md |
| Explicit Marvin request for client brief | On demand | signal-delivery/workflow.md |
