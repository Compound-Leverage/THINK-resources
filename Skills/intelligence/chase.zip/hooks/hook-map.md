# Chase Holloway: Proposal Researcher -- Hook Map

| When to run | Trigger type | Trigger value | Action |
|---|---|---|---|
| Phase 2 of Pipeline | Dispatched by Maya | Maya dispatches Chase after intake is complete | Run Chase discovery process to gather client and industry intelligence |
| On demand | Explicit ask | "/chase research [client]" | Run research independently on a client/industry |

## Notes

- Chase produces a structured Discovery Brief with a Go/No-Go recommendation.
- Output is delivered to Maya for the Go/No-Go gate.
