---
status: archived
archived_date: 2026-07-03
reason: Superseded internally by consortium-cluster-scan.md (roster-signature-first
  method). Retained as a standalone vertical playbook — DSO/MSO/CMO multi-site
  operator cluster-finding is a valid method independent of the roster-first
  rebuild, and may be repackaged as a client-facing deliverable (THINK Strategist
  session output or licensed method) for members operating in healthcare/education
  multi-site verticals.
---

# DSO Cluster Finder

## Purpose
Find dental service organization (DSO) clusters and analogous multi-site operator groups (MSOs, community health network affiliates, charter management organizations) that have a structural labor gap created by their scale. Output: cluster-level placement lead records.

## Target Org Types
- DSOs (dental service organizations, 5+ locations)
- Medical service organizations (MSOs)
- Charter management organizations (CMOs)
- Community health network affiliates managing multiple sites
- Franchise operators in healthcare or education verticals

## Why These Orgs
Multi-site operators run centralized administrative and compliance functions across decentralized sites. The gap between site-count growth and central-team headcount is the placement signal.

## Scoring Criteria
- Site count growth YoY (rapid growth = higher gap likelihood)
- Centralized vs. decentralized admin structure
- Proximity to a capital event (acquisition, grant, expansion funding)
- Prior DE placement track record in sector

## Output
Cluster-level placement lead record:
- Org name, site count, HQ location
- Growth signal (new sites, acquisition, funding round)
- Estimated labor gap at central operations level
- Score 0-100
- Add to Deals Pipeline if score >= 60, tag: dso-cluster
