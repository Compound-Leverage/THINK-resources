# Funder Intel Agent — Integrations

## Research Sources

| Source | Best for |
|---|---|
| CHIPS.gov | Official CHIPS Act allocations, state/regional semiconductor investments |
| grant.gov | Open federal grant programs by agency and keyword |
| Federal Register | NOFOs, program announcements, policy signals |
| DOL/ETA | WIOA programs, workforce innovation grants, RFP timelines |
| NSF.gov | AI-Ready America, STEM workforce, HBCU programs |
| EDA.gov | Economic development grants, regional cluster programs |
| SBA | Small business workforce programs |
| State workforce board websites | State WIOA allocations, open RFPs, appropriations bills |
| Congressional Budget Justifications | Forward-looking funding signals, 60-120 day lead |
| Foundation websites | Annual reports, grant cycles — Kauffman, Lumina, Gates, community foundations |
| LinkedIn | Decision-maker identification, org announcements |
| Regional newspaper/press releases | EDO/chamber initiatives, facility announcements |

## Research Patterns

**CHIPS Act Allocation Scan:**
- Sources: CHIPS.gov, state economic development agency announcements, regional coverage, LinkedIn
- Extract: Organization (state/region), funder type, funding amount, capital investment trigger, job projections, decision-maker

**WIOA RFP Timeline Scan:**
- Sources: State workforce board websites, federal WIOA program office (grant.gov), state legislative budget sessions
- Extract: State, funder type, funding available, RFP deadline, decision-maker, likelihood of AI workforce focus

**Quantum Corridor / Semiconductor Cluster Scan:**
- Sources: Economic development agency press releases, facility operator announcements, chamber news, LinkedIn
- Extract: Project name, location, investment, timeline, job projections, development stage, decision-maker contacts

**Foundation & Federal Grant Cycle Scan:**
- Sources: Foundation websites (annual reports, grant cycles), grant.gov, federal agency RFP calendars (SBA, EDA, DOL)
- Extract: Funder name, focus area, grant size, deadline, prior recipients, decision-maker contact

## Notion Writes

**Organizations record:**
```
INSERT INTO "Organizations":
- Name, Type (State Workforce Board | EDO | Foundation | Federal Agency)
- Capital Event (investment trigger)
- Funding Pot Available, Regional Focus
- Contact Person, Website
```

**Contacts record:**
```
INSERT INTO "Contacts":
- Name, Title, Organization
- Email, Phone
- Warm Intro Path (Direct | 1-Hop | 2-Hop)
- LinkedIn Profile, Known Priorities/Challenges
- Relationship Status (Not yet reached | Reached | Engaged)
```

**Deals Pipeline record:**
```
INSERT INTO "Deals Pipeline":
- Name: "[Organization] — [Capital Event]"
- Status: Prospect
- Amount: [Estimated bid, typically 25–33% of funder's allocation]
- Funding Pot Available, Funder Type, Funding Source
- Regional Focus (Data Center Hubs | Semiconductor Clusters | State Priority Industries)
- 90-Day Alignment: [TRUE if close date feasible this quarter]
- Capital Event Score: [60–100 = high priority]
- Next Action: [Routing recommendation]
- Stage: Prospect, Service Tier: Institutional, Type: Training
```
