# Funder Intel Agent — Rules

## Scoring Model

**Funding availability (0–30 pts):** Does funder have capital allocated?
**Timeline urgency (0–20 pts):** When does blindspot need fixing?
**Competition (0–20 pts):** Are other providers positioned already?
**Geography (0–20 pts):** Is this in primary territory (VA/DC/MD primary, TX secondary)?
**Capacity Gap Signal (0–15 pts):** Is there evidence the org lacks the staff or system to act on the capital event? Score higher for: explicit hiring signals (posting for grant manager, BD lead, research coordinator), tool complaints, staff-to-grant ratio strain, or public statements about missing opportunities. A capital event without a capacity gap is an awareness lead, not a placement lead.

**Bonuses:**
- +5 for warm intro path
- +5 for federal mandate
- +5 for concurrent funding sources

## Conversion Thresholds

| Score | Priority | Conversion Likelihood |
|---|---|---|
| 60+ | High-fit prospect — add to pipeline | 15–25% |
| 40–60 | Medium-fit — defer, monitor | 5–15% |
| < 40 | Low-fit — future pipeline | < 5% |

Only Score 60+ gets added to Deals Pipeline as "Prospect".

## Lane Qualifier Rule

Score 60+ AND org is Gail-profile (institution, EDO, workforce board, HBCU, nonprofit, government contractor) AND budget signal confirmed (active federal funding portfolio, state grant award, or operating budget with grants function) → **Lane 1 (Managed DE)**. Apply DE match based on the capacity gap type:

| Capacity Problem | Recommended DE(s) |
|---|---|
| Grant discovery / signal tracking | Chet (Opportunity Mapper) + Rohit (Intel Scan) |
| Proposal / grant writing | Blair (Proposal Engine) |
| BD outreach + pipeline management | Sarah (BD Execution) + Alex (BD Research) |
| Intelligence briefs / research delivery | Ben (Intelligence Brief Delivery) + Josh (Brief Writer) |
| Contact management / CRM intake | Kipp (Contact Enrichment) |

## Constraints & Rules

1. No cold outreach without approval — add prospects to Notion, user approves before any engagement
2. Score every prospect — only Score 60+ gets "high priority" flag
3. Capital Event required — prospect must have identifiable large capital investment trigger
4. Capacity Gap required — a capital event alone is insufficient; evidence of understaffing or missing system is required for a placement lead
5. Warm intro preferred — prioritize prospects with 1-hop or 2-hop intro paths
6. 90-Day alignment — flag if close date realistically feasible this quarter
