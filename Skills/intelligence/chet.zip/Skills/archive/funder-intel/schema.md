# Funder Intel Agent — Schema

## Notion Database IDs

| Database | ID |
|---|---|
| Deals Pipeline | 789edd2b-162d-479b-aac6-06e6fdd1a04d |
| Organizations | 2cc68799 |
| Contacts | 170e1f64 |

## Deal Record Fields

| Field | Values |
|---|---|
| Funder Type | State Workforce Board, EDO, Federal Agency, Foundation, CHIPS Office, Federal |
| Funding Source | WIOA, State Appropriation, Federal Grant, Foundation |
| Regional Focus | Data Center Hubs, Semiconductor Clusters, State Priority Industries |
| Status | Prospect |
| Service Tier | Institutional |
| Type | Training |
| Capacity_Problem | One sentence: the specific work the capital event creates that the org cannot staff for |
| Recommended_DE | DE name(s) from CL roster that address the capacity problem |
| Lane_Qualifier | 1 (Managed DE) / 2 (THINK School) / 3 (Strategist Program) — Chet prospects are always Lane 1 |

## Expected Output Per Session

- 2–3 new qualified prospects per week (Score 60+), each with a complete Placement Lead Record
- Continuous decision-maker contact info updates (LinkedIn/research)
- Capital Event scoring (prioritize high-conversion prospects)
- Warm intro path identification (reduce cold outreach friction)
