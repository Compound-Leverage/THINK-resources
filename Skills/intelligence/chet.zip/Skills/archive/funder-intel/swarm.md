# Funder Intel Agent -- Swarm Orchestrator

Parallel version of `workflow.md`. Use this skill for weekly scheduled runs where wall-clock time matters. Instead of running Phase 0 and Phase 1 sequentially, this orchestrator spawns 9 subagents simultaneously (2 Phase 0 + 7 Phase 1), collects all results, then runs scoring and prospect creation in a single consolidated pass. Expect roughly 70% reduction in total session time versus sequential execution.

When to use over `workflow.md`: any time this skill runs on a schedule or when Marvin asks for a full funder-intel scan and does not need interactive status updates between phases. Use `workflow.md` when running a narrowly scoped scan (single category, specific region) or when debugging a single data source.

---

## Pre-Scan: Intelligence Inbox Review

Runs first, in a single sequential session before any subagents are spawned. This is fast -- do not parallelize it.

Query Notion Intelligence Inbox (`4bcb512f-9861-476f-945b-9b90ceb6478a`) for entries added or updated in the past 7 days where Status = Qualified.

For each qualifying entry:
1. Check Deals Pipeline (`789edd2b`) for an existing record matching the org name or capital event name. If a deal already exists at any stage: skip, do not duplicate.
2. If no matching deal exists: score against the rubric below (inline scoring rules -- Phase 2 section). Score 0-100.
3. Score >= 60: add to `inbox_qualified` list. These entries skip Phase 1 and Phase 2 and go directly to Phase 3 (prospect creation).
4. Score < 60: log "Inbox signal reviewed -- below threshold." Do not create a deal.

Log inbox review results before proceeding:
```
[timestamp] | funder-intel-swarm | inbox-review | [N] entries reviewed | [N] qualified (score 60+) | [N] below threshold
```

After the log entry, proceed immediately to the parallel subagent launch below.

---

## Parallel Subagent Launch

In a single Agent tool call batch, spawn all 9 subagents simultaneously. Do not wait for one to complete before starting the next. Pass each subagent the exact prompt text written out below.

---

### Subagent P0-A: Complaint Signals

**Prompt to pass:**

You are running a targeted prospecting scan for Compound Leverage. Your job is to find HBCUs and MSIs (Minority-Serving Institutions) that have publicly expressed frustration with their current grant discovery tools: Pivot-RP, Grant Forward, InfoEd, Instrumentl, or GovWin IQ.

Search the following sources and extract every qualifying signal you find:

1. G2 reviews: search `site:g2.com "Grant Forward" OR "Pivot-RP" OR "InfoEd" OR "Instrumentl" review`
2. Capterra reviews: search `site:capterra.com "Grant Forward" OR "GovWin" review "keyword" OR "missing" OR "too many results"`
3. LinkedIn complaint posts: search `site:linkedin.com "Grant Forward" OR "Pivot-RP" OR "InfoEd" OR "Instrumentl" "keyword matching" OR "missing opportunities" OR "too much noise" OR "not strategic"`
4. Conference presentations: search `NCURA OR "SRA International" OR "HBCU AIRCS" "grant discovery" OR "grants pipeline" "manual" OR "missed" OR "velocity" 2024 2025 2026`
5. Public RFI responses: search `site:regulations.gov "grant discovery" OR "research development" HBCU OR MSI response`
6. Job postings: search `"improve grant capture" OR "systematic approach to funding" OR "grants pipeline" HBCU OR MSI site:linkedin.com OR site:higheredjobs.com`

Qualify each result: Is the reviewer or poster at an HBCU, MSI, or emerging-research institution? Filter out any result where institution type is unclear.

For each qualifying signal, extract:
- institution_name (string)
- institution_type (HBCU / MSI / emerging-research)
- leader_name (string or null -- name of research admin, VP Research, grants director, or TTO director if findable)
- complaint_quote (exact words from review, post, or presentation)
- source_url (direct URL to the review or post)
- signal_tier (always "A" for complaint signals)
- category (always "P0-Complaint")

Return a JSON array. If no qualifying signals are found, return an empty array. Do not summarize -- return raw JSON only.

---

### Subagent P0-B: Subscriber Discovery

**Prompt to pass:**

You are running a targeted prospecting scan for Compound Leverage. Your job is to find HBCUs and MSIs (Minority-Serving Institutions) that have confirmed subscriptions to grant discovery tools: Pivot-RP, Grant Forward, InfoEd, Instrumentl, or GovWin IQ -- without necessarily expressing a complaint.

Search the following sources and extract every qualifying signal you find:

1. Library research guides: search `"Grant Forward" OR "Pivot-RP" OR "InfoEd" OR "Instrumentl" site:lib.edu OR site:library.edu`
2. SAM.gov procurement: search SAM.gov for vendor names (InfoEd Global, Instrumentl, Deltek GovWin) combined with HBCU or MSI institution names
3. State procurement portals: search state procurement databases for research tool contract awards at HBCUs and MSIs
4. Job postings mentioning tools: search `"Grant Forward" OR "Pivot" OR "InfoEd" OR "Instrumentl" site:higheredjobs.com OR site:linkedin.com HBCU OR MSI`

Qualify each result: confirm the institution is an HBCU, MSI, or has documented R1/R2 research ambition (strategic plan, board directive, provost announcement). Filter out any result where institution type is unclear.

For each qualifying signal, extract:
- institution_name (string)
- institution_type (HBCU / MSI / emerging-research)
- tool_confirmed (the specific tool subscription confirmed)
- discovery_url (URL where subscription was confirmed)
- leader_name (string or null -- grants director, research development director, or VP Research if findable)
- signal_tier (always "B" for subscriber signals)
- category (always "P0-Subscriber")

Return a JSON array. If no qualifying signals are found, return an empty array. Do not summarize -- return raw JSON only.

---

### Subagent C1: CHIPS Act Allocations

**Prompt to pass:**

You are a capital event research agent for Compound Leverage. Scan for CHIPS Act state and regional capital events that imply a workforce gap -- specifically for organizations that provide workforce development, training, or AI/tech upskilling.

Search: CHIPS Act state and regional allocations, data center construction, semiconductor manufacturing facility investments announced or updated in the past 90 days. Use sources including CHIPS.gov, state economic development agency announcements, regional business press, and LinkedIn.

For each capital event found, extract:
- event_name (descriptive name for the event)
- org_or_program (the company, agency, or consortium receiving or deploying the investment)
- region (state or metro area)
- investment_amount (dollar figure or range as string)
- timeline (expected construction start, completion, or hiring ramp dates)
- labor_gap_signal (describe the implied workforce gap: job count projections, skill type needed, training gap)
- source_url (direct URL to the announcement or coverage)
- category (always "CHIPS")

Return a JSON array of raw capital event records. If no events found, return an empty array. Do not summarize -- return raw JSON only.

---

### Subagent C2: WIOA RFP Cycles

**Prompt to pass:**

You are a capital event research agent for Compound Leverage. Scan for active or upcoming WIOA (Workforce Innovation and Opportunity Act) state RFP cycles where workforce boards are deploying federal funding.

Search: state workforce board websites, federal WIOA program office (grant.gov), and state legislative budget session announcements. Focus on RFPs open now or opening in the next 90 days.

For each RFP cycle or funding announcement found, extract:
- event_name (descriptive name)
- org_or_program (state workforce board or issuing agency)
- region (state)
- investment_amount (funding pool size as string)
- timeline (RFP open date, close date, or award quarter)
- labor_gap_signal (what workforce need this funding is meant to address)
- source_url (direct URL)
- category (always "WIOA")

Return a JSON array of raw records. If nothing found, return an empty array. Do not summarize -- return raw JSON only.

---

### Subagent C3: State Appropriations

**Prompt to pass:**

You are a capital event research agent for Compound Leverage. Scan for state appropriations bills or budget line items that deploy funding for workforce development or economic development -- current legislative session only (2025-2026 session or fiscal year 2026-2027 budgets).

Search: state legislature websites, state budget office announcements, and business press covering state budget news. Focus on appropriations for workforce training, AI readiness, economic development, or community college capacity.

For each appropriation found, extract:
- event_name (descriptive name for the budget line or bill)
- org_or_program (state agency or program receiving the appropriation)
- region (state)
- investment_amount (appropriation amount as string)
- timeline (effective date or fiscal year)
- labor_gap_signal (what workforce or capacity need this addresses)
- source_url (direct URL to bill text, budget document, or press coverage)
- category (always "StateApprop")

Return a JSON array of raw records. If nothing found, return an empty array. Do not summarize -- return raw JSON only.

---

### Subagent C4: Quantum Corridor Projects

**Prompt to pass:**

You are a capital event research agent for Compound Leverage. Scan for quantum corridor site announcements, quantum computing facility construction, and quantum workforce development initiatives announced or updated in the past 90 days.

Search: economic development agency press releases, facility operator announcements, chamber of commerce news, federal quantum program office (quantum.gov), and LinkedIn. Focus on physical site investments and associated workforce projections.

For each project found, extract:
- event_name (descriptive name)
- org_or_program (company, agency, or consortium)
- region (state or metro)
- investment_amount (dollar figure as string)
- timeline (construction start, completion, or workforce ramp dates)
- labor_gap_signal (workforce projections: job count, skill types, training gap)
- source_url (direct URL)
- category (always "Quantum")

Return a JSON array of raw records. If nothing found, return an empty array. Do not summarize -- return raw JSON only.

---

### Subagent C5: Federal Grant Cycles

**Prompt to pass:**

You are a capital event research agent for Compound Leverage. Scan for open or upcoming federal grant cycles from DOL, EDA, and SBA focused on workforce innovation, AI readiness, and economic development. Look for programs that would benefit workforce development organizations, community colleges, HBCUs, or MSIs.

Search: grant.gov (DOL, EDA, SBA agency filters), Federal Register NOFOs, and agency program office websites. Focus on grants open now or with application deadlines in the next 120 days.

For each grant program found, extract:
- event_name (program name)
- org_or_program (federal agency and program office)
- region (national or specific target geography if applicable)
- investment_amount (total funding available or typical award size)
- timeline (application deadline or award quarter)
- labor_gap_signal (what workforce need the grant addresses, and what types of orgs are eligible)
- source_url (direct URL to NOFO or grant.gov listing)
- category (always "FederalGrant")

Return a JSON array of raw records. If nothing found, return an empty array. Do not summarize -- return raw JSON only.

---

### Subagent C6: EDO and Chamber Initiatives

**Prompt to pass:**

You are a capital event research agent for Compound Leverage. Scan for economic development organization (EDO) and chamber of commerce initiatives involving sector activation, workforce development partnerships, or AI/technology workforce programs announced in 2026.

Search: EDO websites, chamber of commerce newsrooms, regional business press, and LinkedIn. Focus on newly announced programs, partnerships, or funding rounds from regional economic development agencies.

For each initiative found, extract:
- event_name (descriptive name)
- org_or_program (EDO or chamber name)
- region (state or metro)
- investment_amount (dollar amount committed, if stated)
- timeline (program launch date or initiative window)
- labor_gap_signal (what workforce or capacity need the initiative is targeting)
- source_url (direct URL)
- category (always "EDO")

Return a JSON array of raw records. If nothing found, return an empty array. Do not summarize -- return raw JSON only.

---

### Subagent C7: Large Employer Announcements

**Prompt to pass:**

You are a capital event research agent for Compound Leverage. Scan for large employer facility expansion, new operations launch, or major relocation announcements where the implied workforce gap creates an opportunity for workforce development organizations, community colleges, or training providers.

Search: regional business press, state economic development announcements, chamber press releases, and LinkedIn. Focus on announcements from the past 90 days involving 200+ new jobs or major facility investments.

For each announcement found, extract:
- event_name (descriptive name: company + announcement type)
- org_or_program (company name)
- region (state or metro)
- investment_amount (facility investment or total commitment as string)
- timeline (operational date or hiring ramp start)
- labor_gap_signal (job count, skill types needed, adjacent training org opportunity)
- source_url (direct URL)
- category (always "LargeEmployer")

Return a JSON array of raw records. If nothing found, return an empty array. Do not summarize -- return raw JSON only.

---

## Collecting Results

Wait for all 9 subagents to return before proceeding. Collect all JSON arrays and flatten into a single raw prospect list. Remove duplicates: if two records share the same `org_or_program` and the same `event_name` (case-insensitive), keep the one with the richer `labor_gap_signal` field and discard the other.

Cross-reference every remaining record against Deals Pipeline (`789edd2b`): search by org name. If a matching deal already exists at any pipeline stage, drop the record. Do not duplicate pipeline entries.

The output of this step is: `phase1_raw` (deduped, not-yet-in-pipeline records from all 9 subagents).

---

## Phase 2: Scoring and Blindspot Analysis

For each record in `phase1_raw`, score 0-100 using the inline rubric below. Do not reference rules.md -- use this rubric directly.

**Scoring rubric:**

| Dimension | Points available | Guidance |
|---|---|---|
| Funding availability | 0-30 | Is capital allocated and confirmed? 30 = allocated and announced. 15 = strong signal, not yet confirmed. 0 = speculative. |
| Timeline urgency | 0-20 | How soon does the window close? 20 = deadline within 60 days. 10 = deadline within 6 months. 0 = no defined deadline. |
| Competition presence | 0-20 | Are other providers already positioned? 20 = no visible competition. 10 = some providers present but not dominant. 0 = crowded or entrenched. |
| Geography match | 0-20 | 20 = VA/DC/MD (primary territory). 12 = TX (secondary territory). 6 = other domestic. 0 = outside US. |

**Bonuses (add after base score):**
- HBCU or MSI is the prospect org or primary beneficiary: +10
- Workforce board is the prospect org or issuing agency: +8
- Community college is the prospect org: +6
- Active deal in this same sector already in pipeline (confirms sector alignment): +5
- Federal mandate attached to the funding: +5
- Concurrent funding sources (multiple funders, e.g. federal + state match): +5

**Thresholds:**
- Score 60+: advance to Phase 3
- Score 40-59: log as "defer and monitor" -- do not create a deal
- Score <40: discard

Log the score for every record, including discards. Do not silently drop records -- every record from `phase1_raw` must appear in the score log.

---

## Phase 3: Prospect Creation

Run for every record in `phase1_raw` with score >= 60, plus every entry in `inbox_qualified` from the Pre-Scan.

For each qualifying prospect, complete all four steps below in order:

**Step 1 -- Write to Intelligence Inbox (`4bcb512f-9861-476f-945b-9b90ceb6478a`):**

Create a new Notion page:
- Title: "[Capital Event Type] -- [Organization or Program Name] -- [State/Region]"
- Status: Qualified
- Sector: (primary sector -- Workforce Development / Research / CHIPS / AI Infrastructure / EDO / etc.)
- Geography: (state or metro region)
- Signal Summary: One sentence. What the capital event is, what it means for organizations in this space, and what the labor gap looks like. Example: "DOL awarded $12M to VA workforce boards for AI upskilling -- institutions without a scanning function will miss the sub-award windows opening Q3 2026."
- Funding Source: (federal agency, state program, or private funder)
- Estimated Funding: $(amount or range)
- Window Dates: (open date -- close date or expected quarter)
- Labor Gap Signal: Describe the bandwidth strain this event creates. "High grant volume relative to staff. Window timing requires fast action most offices cannot execute without additional capacity."
- Source: chet_funder_intel
- Related Org: (org name from Organizations record below)

**Step 2 -- Create or update Notion Organizations record (`2cc68799`):**
- Organization name, type, contact info, website, annual budget or appropriation
- Capital event triggering this prospect, regional focus

**Step 3 -- Create or update Notion Contacts record (`170e1f64`):**
- Decision-maker name, title, contact info (search the web if not already available)
- Warm intro path (direct, 1-hop, 2-hop) if discoverable
- Background, LinkedIn profile, known priorities or challenges

**Step 4 -- Create Notion Deals Pipeline record (`789edd2b`):**
- Deal name: "[Organization] -- [Capital Event Summary]"
- Status: Prospect
- Amount: Estimated bid (typically 25-33% of decision-maker's allocation)
- Funding Pot Available, Funder Type, Funding Source, Regional Focus
- 90-Day Alignment: TRUE if close date is feasible this quarter
- Capital Event Score: [score from Phase 2]
- Capital Event details: investment amount, timeline, workforce gap description
- Intelligence Inbox link: paste the URL of the Inbox record created in Step 1
- Next Action: Routing recommendation
- Stage: Prospect, Service Tier: Institutional, Type: Training

---

## Logging and Notification

**Completion log** -- append to `Logs/completions.log` after Phase 3 is complete:
```
[timestamp] | funder-intel-swarm | [session date] | COMPLETE | [N] prospects added, scores: [list], [N] Intel Inbox entries created
```

**High-signal notification** -- if any prospect scores 90 or higher, post immediately to Google Chat via the webhook at `$SARAH_WEBHOOK_URL`:

```
High-signal prospect: [Org], Score [X]/100. Signal: [one-sentence description from labor_gap_signal field].
```

Post one message per 90+ prospect. Do not batch them. Do not wait until Phase 3 is complete -- post as soon as the score is confirmed in Phase 2 (or during inbox review if a Pre-Scan entry clears 90).

---

## Execution Summary

| Phase | Runs | Mode |
|---|---|---|
| Pre-Scan (Inbox Review) | Before subagent launch | Sequential (fast) |
| Phase 0-A (Complaint Signals) | Parallel with all others | Subagent |
| Phase 0-B (Subscriber Discovery) | Parallel with all others | Subagent |
| C1 (CHIPS Act) | Parallel with all others | Subagent |
| C2 (WIOA RFP Cycles) | Parallel with all others | Subagent |
| C3 (State Appropriations) | Parallel with all others | Subagent |
| C4 (Quantum Corridor) | Parallel with all others | Subagent |
| C5 (Federal Grant Cycles) | Parallel with all others | Subagent |
| C6 (EDO/Chamber) | Parallel with all others | Subagent |
| C7 (Large Employer) | Parallel with all others | Subagent |
| Result collection + dedup | After all 9 return | Sequential |
| Phase 2 (Scoring) | After collection | Sequential |
| Phase 3 (Prospect creation) | After scoring | Sequential |
| Logging + notification | After Phase 3 | Sequential |

Target output: 2-3 new qualified prospects per session (Score 60+), with all four Notion records written and completion log appended.
