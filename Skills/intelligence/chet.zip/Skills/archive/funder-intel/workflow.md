---
status: archived
archived_date: 2026-07-05
reason: Retired as a standalone pipeline -- its individual-prospect-creation model (Phase 3) conflicted with Chet's actual job (cluster discovery, not prospect scans -- see Agents/chet/CLAUDE.md). Its two genuinely useful pieces were folded into consortium-cluster-scan.md instead: the capital-event category list (including policy/regulatory triggers -- executive orders, new law, compliance, market forces) now lives in that skill's Step 2, and the "capacity deficit" framing (renamed from "AI exploitation angle") is consistent with its Step 3 gap-volume language. What's left here is just historical reference for the Infrastructure Blindspot Scanner formula and Phase 0 tool-complaint sourcing patterns, not an active skill. The two live CCR triggers referencing this ("funder-intel-research", Tue; "Funder Intel Agent", Mon) are being paused by Marvin directly, not through this repo change.
---

# Funder Intel Agent — Workflow (ARCHIVED)

Weekly cadence. Target: 2–3 new qualified prospects per session (Score 60+).

---

## Pre-Scan: Intelligence Inbox Review

Before running any capital event scans, read the Intelligence Inbox (`4bcb512f-9861-476f-945b-9b90ceb6478a`) for entries added or updated in the past 7 days where Status = Qualified.

For each qualifying entry:
1. Check Deals Pipeline (`789edd2b`) for an existing record matching the org name or capital event name. If a deal already exists at any stage: skip, do not duplicate.
2. If no matching deal exists: evaluate the entry as a prospect using the scoring rubric in rules.md. Score it 0-100.
3. If score >= 60: proceed directly to Phase 3 (Prospect Creation) for this entry. It does not need to go through Phase 1 scanning -- the inbox entry is the signal source.
4. If score < 60: log it but do not create a deal. Note: "Inbox signal reviewed -- below threshold."

After processing all inbox entries, continue to Phase 0 below for additional independent scanning.

Why this matters: Rohit (Sunday content intel) and ce-signal-mapper (GitHub Actions, Sun/Tue/Wed) write capital event signals to this inbox from independent scans. Without this step, those signals never become Deals Pipeline records -- they exist in the inbox but nothing acts on them.

Log inbox review results:
```
[timestamp] | funder-intel | inbox-review | [N] entries reviewed | [N] new deals created | [N] below threshold
```

---

## Phase 0: Category Play Sourcing — Tool Complaint and Subscriber Signals

Run this before capital event scanning. These prospects are pre-qualified: budget allocated, pain named, category understood. A complaint signal is stronger than a subscription signal — prioritize in that order.

**Target tools:** Pivot-RP, Grant Forward, InfoEd, Instrumentl, GovWin IQ

**Tier 1 profile (all four required):**
1. HBCU or MSI
2. Public R1/R2 ambition — strategic plan, board directive, or provost announcement
3. Discoverable tool subscription or named tool frustration
4. Named research development leader (Executive Director of Research, VP Research, Director of Grants and Contracts, Director TTO)

---

### Source A: Complaint Signals (highest priority)

These prospects have already diagnosed their own problem. They are mid-wound.

**G2 and Capterra reviews:**
- Search: `site:g2.com "Grant Forward" OR "Pivot-RP" OR "InfoEd" OR "Instrumentl" review`
- Search: `site:capterra.com "Grant Forward" OR "GovWin" review "keyword" OR "missing" OR "too many results"`
- Extract: reviewer name, institution, title, the specific complaint
- Qualify: Is reviewer at HBCU/MSI or emerging-research institution?

**LinkedIn complaint posts:**
- Search: `site:linkedin.com "Grant Forward" OR "Pivot-RP" OR "InfoEd" OR "Instrumentl" "keyword matching" OR "missing opportunities" OR "too much noise" OR "not strategic"`
- Filter: research administrator, grants manager, VP research, director TTO titles
- Extract: name, institution, post URL, complaint quote

**Conference presentation signals:**
- Search: `NCURA OR "SRA International" OR "HBCU AIRCS" "grant discovery" OR "grants pipeline" "manual" OR "missed" OR "velocity" 2024 2025 2026`
- Presenters describing grants process pain are actively seeking solutions and have peer networks

**Public RFI responses:**
- Search: `site:regulations.gov "grant discovery" OR "research development" HBCU OR MSI response`
- Search: federal RFIs in AI, workforce, research infrastructure where institutions describe their gaps

**Job postings signaling tool failure:**
- Search: `"improve grant capture" OR "systematic approach to funding" OR "grants pipeline" HBCU OR MSI site:linkedin.com OR site:higheredjobs.com`
- A posting for "improve our grants capture rate" means the current tool is not working

---

### Source B: Tool Subscriber Discovery

For institutions without a public complaint, find the subscription through open signals.

**Library research guides:**
- Search: `"Grant Forward" OR "Pivot-RP" OR "InfoEd" OR "Instrumentl" site:lib.edu OR site:library.edu`
- Most university libraries publish their grant database subscriptions publicly
- Extract: institution name, tool confirmed, library guide URL

**Procurement records:**
- SAM.gov: search vendor name (InfoEd Global, Instrumentl, Deltek GovWin) + institution name
- State procurement portals: institution contract awards for research tools

**Job postings mentioning tools:**
- Search: `"Grant Forward" OR "Pivot" OR "InfoEd" OR "Instrumentl" site:higheredjobs.com OR site:linkedin.com HBCU OR MSI`
- A grants manager posting listing tool proficiency confirms the subscription

---

### Phase 0 Output

For each prospect found via Phase 0, document:
- Institution name and type (HBCU / MSI)
- R-status ambition (public statement or evidence)
- Tool confirmed + how discovered (URL)
- Complaint quote if available (exact words)
- Named leader (name, title, email if findable)
- Signal tier: A (complaint) or B (subscriber)

Score against rubric in rules.md. Score 60+ → advance to Phase 3 prospect creation. Do not run Phase 1 capital event scanning for Phase 0 prospects — the tool subscription is the capital event signal.

---

## Phase 1: Research & Capital Event Scanning

**Capital Event Scans (Weekly):**
1. CHIPS Act Allocations — State/regional data center, semiconductor manufacturing investments
2. WIOA RFP Cycles — State workforce board RFP timelines, funding pool sizes
3. State Appropriations — Workforce development, economic development bills (budget season)
4. Quantum Corridor Projects — Site announcements, construction timelines, job projections
5. Federal Grant Cycles — DOL, EDA, SBA workforce innovation programs
6. EDO/Chamber Initiatives — Sector activation, workforce development partnerships
7. Large Employer Announcements — Facility expansions, new operations (implies workforce gap)
8. Policy and Regulatory Triggers — executive orders, new law, compliance mandates, market forces/economic indicators. Not every capital event is a direct dollar allocation -- a new compliance requirement or executive order can create the same "capacity deficit the org can't staff for" pattern without a funding announcement attached. Same Phase 2 Blindspot Analysis applies once one of these is found.

See `integrations.md` for sources and research patterns.

---

## Phase 2: Blindspot Analysis

For each capital event discovered:

**Step 1: Identify the Capital Investment**
- Investment amount, timeline, job projections, location/region

**Step 2: Assess Workforce Shortage**
- Current workforce gap (unfilled positions)
- Required skill set (AI-strategic vs. generic IT vs. trade skills)
- Regional training capacity — does existing training match need?
- Competitive threat — other regions/companies recruiting talent

**Step 3: Identify the Capacity Deficit**
- What work does the capital investment create that the org cannot staff for?
- Where is the org capacity-constrained, not just headcount-constrained -- what would a DE placement actually absorb?
- What blocks the org from acting on the opportunity itself (not a framing exercise, the real operational gap)?

**Step 4: Size the Blindspot**
- Addressable market (workforce professionals needed)
- Serviceable market (what we can reach in 6–8 weeks)
- Revenue opportunity (funding available in decision-maker's budget)

**Step 5: Score (see rules.md)**

---

## Phase 3: Cluster Creation (not individual prospect creation)

We're looking for placement clusters, not one-off prospects. A single org hitting the Blindspot formula (capital investment + workforce shortage + capacity deficit) is a data point; the deliverable is the **cluster** of orgs sharing that same pattern -- same shape as `consortium-cluster-scan.md`'s output, just reached via a different discovery lens (public capital-event pattern-matching here, vs. roster-signature-first there).

For each high-fit capital event (Score 60+):

**Step 1 -- Scale it: find every other org matching the same pattern, not just the one that triggered the scan.** This is the formula's own 4th step ("Scale it") -- do not stop at the first hit. Search for the same capital-investment type + workforce-shortage + capacity-deficit combination across the sector/geography this event covers. The candidate list from this step is the cluster membership.

**Step 2 -- Write to Clusters DB (`b55107b8-5850-4157-b4d1-a877c3d45fc5`), one record for the group:**
- Cluster Name: descriptive of the shared pattern, e.g. "[Capital Event Type] -- [Sector/Region] Capacity Deficit"
- Layer 6 Targets: the org type this cluster covers (HBCUs / Workforce Boards / EDOs / etc.)
- Capacity Problem-equivalent notes: what the capital investment creates that these orgs can't staff for
- TAM/SAM/TOM: sized per Step 1's found membership vs. estimated full addressable population
- Orgs Matched: count of orgs actually identified in Step 1

**Step 3 -- Hand off to Cassie, same as `consortium-cluster-scan.md`.** Chet does not write individual orgs to the Intelligence Inbox, Organizations, Contacts, or Deals Pipeline himself -- that was the old per-prospect model. Cassie scores the cluster (CE Score) and gates it through the six-state Status machine; Alex sources the individual org/contact records once the cluster is Qualified and fanned out to a Campaign. This keeps one write path for cluster-sourced leads regardless of which discovery lens found them.
- 90-Day Alignment: TRUE if close date feasible this quarter
- Capital Event details (investment amount, timeline, workforce gap)
- Intelligence Inbox link: paste the URL of the Inbox record created in Step 1
- Next Action: Routing recommendation

**Step 5 -- Output Placement Lead Record:**

For every Deal record created, derive and embed the following block in the Deal record body:

```
PLACEMENT LEAD RECORD
Org:              [organization name]
Trigger Event:    [capital event name, funding amount, window dates]
Capacity Problem: [one sentence: the specific work the event creates that the org cannot staff for]
Recommended DE:   [DE name(s) — match to the capacity problem using rules.md DE Match table]
Lane:             1 (Managed DE)
Decision Maker:   [title of the person who controls the budget or approves the engagement]
Budget Signal:    [one sentence: evidence of purchasing capacity — active funding portfolio, confirmed grant award, or operating budget with grants function]
Priority Score:   [0-100 from this session's scoring]
```

Rules for the Capacity Problem field: derive it from the blindspot analysis in Phase 2. "Award received but no system to track sub-award windows" → grant discovery gap → Chet + Rohit DEs. "RFP cycle volume exceeds proposal team capacity" → proposal gap → Blair DE. "BD pipeline not systematically built" → Sarah + Alex DEs. "No research intelligence function" → Ben + Josh DEs.

Also embed this block in the Intelligence Inbox entry created in Step 1 under the Labor Gap Signal field.

**Log completion:**
Append to `Logs/completions.log`:
```
[timestamp] | funder-intel | [session date] | COMPLETE | [N] prospects added, scores: [list], [N] Intel Inbox entries created
```

Cal surfaces new Prospect-stage deals in the Sunday brief. No direct Google Chat ping unless a prospect scores 90+ (deal-level signal) -- in that case post immediately: "High-signal prospect: [Organization], Score [X]/100. Signal: [quote]."

---

## Execution Cadence

- Weekly capital event scans (recommend: Monday/Tuesday)
- Prospect batching: add 2–3 per week, submit for approval
- Monthly research refresh: update decision-maker contact info, RFP deadlines
