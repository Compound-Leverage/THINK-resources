---
status: archived
archived_date: 2026-07-06
reason: Never had a live config (no `hidden_labor_market` key in Agents/chet/config.json) or a standalone hook-map trigger, but was still listed as an active dependency in consortium-cluster-scan.md's Data Sources and in the stale core/capabilities.md -- both contradicted Chet's CLAUDE.md/redesign scope ("does not run prospect scans... or contact prospects"). This is a full individual-prospect scan/score/enrich/outreach-handoff engine (Step 6 routes HIGH FIT contacts to Sarah), exactly the activity the redesign scoped Chet out of. Archived rather than deleted -- the Gail hidden-pain scan pattern (LinkedIn/Facebook signal mining, 0-4 ICP score, Sarah handoff) may still be worth running from a DE whose scope actually covers individual-prospect outreach (Alex sources/enriches leads; Sarah executes outreach) -- reassignment is a product decision for Marvin, not made here.
---

# Hidden Labor Market Scan — Chet (Gail ICP) (ARCHIVED)

**Agent:** Chet (Opportunity Mapper)
**ICP target:** Gail — orgs carrying BD or ops burden manually, not yet looking for a solution
**Products:** Managed DE team, Strategist Program
**Trigger:** Weekly — runs alongside funder-intel scan

---

## Frame

Gail isn't posting an RFP. She's venting in a community group, asking for a tool recommendation, or describing a problem she thinks is normal. The signal is unmet pain, not buying intent. Chet maps where that pain lives and surfaces it before it becomes formal demand.

---

## Target Communities

Defined in `config.json` under `hidden_labor_market.gail_groups`. Operators add group URLs or names. Defaults:

**Government contractor BD:**
- Federal contractor / govcon BD communities
- SAM.gov users and federal procurement groups
- 8(a), WOSB, SDVOSB, HUBZone small business communities
- Proposal tool users (Unanet, GovWin, Cosential)

**Workforce and capacity:**
- Workforce development professionals
- Nonprofit operations and admin groups
- EDO and economic development networks
- Grant management tool users (Salesforce Nonprofit, Apricot, ETO, HMIS)

**General ops overload:**
- Small business operations groups
- Fractional COO and ops consultant communities
- "Hiring help" groups where orgs post looking for part-time ops support

---

## Signal Patterns

Scan post content for these patterns. A post matching 2+ signals is a qualified find.

| Signal | Example language |
|--------|-----------------|
| Manual BD overhead | "spend hours on SAM.gov", "I check it every morning", "keep missing opportunities" |
| Capacity strain | "just me doing all the BD", "can't keep up", "falling through the cracks" |
| Pipeline management pain | "how do you track your pipeline", "losing track of follow-ups", "proposal volume is killing us" |
| Ops overload | "too much admin", "drowning in paperwork", "need another me" |
| Looking for help (not a course) | "looking for someone to help with", "does anyone offer", "what does your team use" |
| Missed opportunities | "found out too late", "didn't see that RFP", "wish I had more lead time" |

**Not a signal:**
- Asking how to do something (learning intent → Crystal, not Gail)
- Celebrating a win
- General industry news discussion

---

## Scan Workflow

### Step 1a — LinkedIn post search
Run `linkedin_search_posts` for each query in `config.hidden_labor_market.linkedin_queries`. Default queries:

1. `"RFP" "too much time" OR "spending hours" OR "overwhelmed" BD proposal`
2. `"SAM.gov" frustrated OR "too much time" OR "can't keep up" government contractor`
3. `"GrantStation" OR "grant finding" OR "finding grants" overwhelmed OR "too much time"`
4. `"proposal writing" overwhelmed OR "no bandwidth" OR "BD team" small business`

Use `datePosted: pastMonth` for recency.

**Core rule:** The poster is almost always a competitor, vendor, or thought leader. They are not the lead. The **commenters and likers** are the leads — they are self-identifying the pain by engaging with the content.

- **Commenter** = active pain signal. Someone who wrote a paragraph about their BD nightmare is a warm lead.
- **Liker** = passive pain signal. Liking a "$400K BD overhead" post without commenting is quietly agreeing. Lower priority than commenters but still worth enriching if volume is low.

For each qualifying post:
1. `linkedin_post_comments` — pull all comments, classify each for signal language
2. For posts with high like counts (50+), treat likers as a secondary lead pool — note the post URL for manual like-list review if the tool supports it
3. Flag any commenter/liker whose org matches `competitor_list` — skip enrichment

Flag any poster whose org name matches known competitors in `config.hidden_labor_market.competitor_list` — skip that poster, but always pull comments and likers from their posts. Competitor posts attract the most relevant audience.

### Step 1b — Pull Facebook group posts
For each group in `config.hidden_labor_market.gail_groups`:
- `facebook_group_posts` — pull last 20-30 posts, last 14 days
- For each qualifying post: `facebook_post_comments` — pull all comments

### Step 2 — Classify each commenter/liker
For each comment or like engagement:
1. Comment matches 2+ signal patterns → **QUALIFIED**
2. Comment matches 1 signal pattern → **MONITOR**
3. Liker on a high-signal post (poster's content explicitly names the pain) → **POSSIBLE** (enrich, score before actioning)
4. No signal in comment → skip

### Step 3 — Enrich qualified contacts
For each qualified commenter or liker:
1. Extract name from comment or like record
2. `linkedin_profile` — pull title, company, industry
3. `linkedin_company` — pull headcount, org type
4. `google_search` if LinkedIn not found

### Step 4 — Score against Gail ICP
Score 0-4:

| Signal | Points |
|--------|--------|
| Org has existing BD or ops function (not starting from zero) | +1 |
| Headcount 5-200 (right size for DE team) | +1 |
| Industry matches operator territory (gov contractor, workforce, nonprofit) | +1 |
| Post language shows urgency or active pain (not hypothetical) | +1 |

**Score 3-4:** HIGH FIT — add to pipeline, route to Sarah
**Score 2:** POSSIBLE — add to pipeline as prospect, no immediate outreach
**Score 0-1:** LOW FIT — log only

### Step 5 — Write to pipeline
For HIGH FIT and POSSIBLE records, create Notion entries:
- Organizations record with enriched company data
- Contacts record with poster name, title, LinkedIn URL, post summary
- Deals Pipeline record:
  - Name: `[Name] — [Company] — Hidden Labor Market`
  - Source: `Facebook Group — [group name]`
  - Signal: `[2-3 word summary of pain posted]`
  - Status: Prospect
  - Next Action: Sarah outreach
  - Embed the following Placement Lead Record block in the record body:

```
PLACEMENT LEAD RECORD
Org:              [company name]
Trigger Event:    [what event or context explains their capacity pain — funding, growth, compliance, etc.]
Capacity Problem: [verbatim or close paraphrase of what they posted — this is their own description of the gap]
Recommended DE:   [DE name(s) — match by pain_pattern: bd_overhead → Sarah + Alex; ops_overload → Kipp; capacity_strain → Sarah + Alex; digital_staffing → Chet + Rohit]
Lane:             1 (Managed DE) for headcount 5-200 with existing BD/ops function; 3 (Strategist Program) for acquirer signals
Decision Maker:   [poster's title — or inferred from org type]
Priority Score:   [N * 25 — convert 0-4 score to 0-100]
```

### Step 6 — Route HIGH FIT to Sarah
Pass handoff block to Sarah:

```
INTAKE TYPE: hidden-labor-market-outreach
CONTACT: [name], [title] at [company]
SOURCE: [group name] — post dated [date]
PAIN SIGNAL: [verbatim quote or close paraphrase of what they posted]
ICP SCORE: [N]/4
ENRICHED: [headcount], [industry], [LinkedIn URL]
CAPACITY PROBLEM: [one sentence derived from their signal — what work they cannot staff for]
RECOMMENDED DE: [DE name(s)]
LANE: [1 for Managed DE / 3 for Strategist Program]
OUTREACH NOTE: Do not reference the Facebook group or that we found them there. Lead with the pain they named.
```

### Step 7 — Write labor market signal cards to content pipeline
For every QUALIFIED comment or post where the verbatim language is specific and vivid — not just a generic complaint — append a `labor_market_signal` card to `topic-cards.json` in the THINK-internal repo root.

The complaint IS the story arc. Do not summarize. Preserve the exact words.

```json
{
  "card_type": "labor_market_signal",
  "signal_text": "One sentence naming the pattern (e.g. 'Govcon BD overhead forcing firms to walk away from qualifying RFPs')",
  "audience": "Gail",
  "pain_pattern": "bd_overhead | ops_overload | capacity_strain | digital_staffing",
  "verbatim_quote": "exact words from the comment or post",
  "source_url": "LinkedIn post or Facebook group post URL",
  "source_type": "linkedin_comment | facebook_comment | facebook_post",
  "source_date": "YYYY-MM-DD",
  "poster_org": "company or org if available",
  "composite_score": 70,
  "sequence_ready": true
}
```

Score guide: 80+ if quote names a specific dollar amount, time cost, or named tool (SAM.gov, GrantStation). 70 if quote describes a clear operational pain. 60 if quote is general frustration without specifics.

Write at most 3 cards per run to avoid flooding the content pipeline.

### Step 8 — Log the run
```
[timestamp] | chet | hidden-labor-market | [N groups scanned] | [N qualified] | [N added to pipeline] | [N signal cards written]
```

---

## Config

```json
"hidden_labor_market": {
  "gail_groups": [
    { "name": "{{GROUP_NAME_1}}", "url": "{{GROUP_URL_1}}", "category": "gov-contractor" },
    { "name": "{{GROUP_NAME_2}}", "url": "{{GROUP_URL_2}}", "category": "workforce" }
  ],
  "linkedin_queries": [
    "\"RFP\" \"too much time\" OR \"spending hours\" OR \"overwhelmed\" BD proposal",
    "\"SAM.gov\" frustrated OR \"too much time\" OR \"can't keep up\" government contractor",
    "\"GrantStation\" OR \"grant finding\" OR \"finding grants\" overwhelmed OR \"too much time\"",
    "\"proposal writing\" overwhelmed OR \"no bandwidth\" OR \"BD team\" small business"
  ],
  "competitor_list": ["SLED.AI", "GovWin", "GrantStation", "Unanet", "CivIQ", "CLEATUS"],
  "scan_cadence": "weekly",
  "posts_per_group": 25,
  "lookback_days": 14,
  "min_signal_score": 2
}
```
