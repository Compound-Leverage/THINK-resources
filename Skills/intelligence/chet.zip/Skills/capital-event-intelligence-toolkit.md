# Capital Event Intelligence Toolkit

## Purpose
Structured toolkit for capital event research: scraping, classification, and scoring. Used by Chet when running a deep scan or when funder-intel requires supplemental sourcing. Output: structured event records ready for pipeline entry.

## Toolkit Components

### 1. Source Scraper
Pull raw event data from:
- SAM.gov award search (grants.gov awards by sector/CFDA)
- USASpending.gov (new awards, spending by agency/sector)
- Federal Register (NOFO announcements, program rules)
- State grant portals (varies by target state)
- Foundation databases (Candid/GuideStar, Foundation Directory)

### 2. Event Classifier
Classify each event by:
- Type: Grant | Federal Program | Infrastructure | Policy Change | Mandate
- Sector: Workforce | Health | Education | Energy | Housing | Other
- Scope: Local | Regional | National
- Urgency: Imminent (< 3 months) | Near-term (3-12 months) | Pipeline (12+ months)

### 3. Labor Gap Estimator
For each event, estimate the work it creates:
- What the org must do to capture or comply with the event
- Whether existing headcount can absorb it
- Which DE type would close the gap (BD, Compliance, Research, Admin)

### 4. Scoring Engine
Score each org-event pair 0-100 using the capital-event-radar.md criteria.

## Output
Structured event records in Notion Deals Pipeline or as CSV:
- Org, event, type, sector, urgency, labor gap, score, recommended DE tier
