# Capital Event Radar

## Purpose
Scan for active capital events — grants awarded, federal programs launched, infrastructure funding allocated, policy changes enacted — that create labor gaps in target orgs. Output: placement lead records, not intelligence summaries.

## Scan Sources
- Federal Register / SAM.gov new award announcements
- State grant disbursement feeds
- SBIR/STTR award notices
- Infrastructure bill program rollouts (CHIPS, IRA, BIL)
- Policy change trackers by sector

## Scoring Criteria
Each event scores 0-100 against:
- Proximity to active capital event (40 pts)
- Org size relative to event scope — labor gap likelihood (30 pts)
- Sector alignment to CL placement portfolio (20 pts)
- Urgency — window size and timeline (10 pts)

## Output
Placement lead record per org:
- Org name, type, location
- Capital event trigger (event name, amount, date)
- Estimated labor gap type and scope
- Score 0-100
- Recommended DE tier (Standard / Pro)
- Add to Notion Deals Pipeline if score >= 60
