# Skill: cluster-monitor

**Agent:** Chet Holmes (Sales -- Funder Intel)
**Cadence:** Monday 7am -- runs as part of the weekly cluster sweep, alongside `consortium-cluster-scan.md`

## Conceptual frame

Clusters are not events -- they are trajectories. The detection task is to identify when capital is concentrating in a sector before the opportunity window closes, not after. The logic follows Leopold Aschenbrenner's analysis of how resource aggregation creates compounding advantage for early movers:

> "Whoever is in the lead [when the cluster forms] will have a structural lock on what comes next."

Reference: [Racing to the Trillion-Dollar Cluster -- Situational Awareness](https://situational-awareness.ai/racing-to-the-trillion-dollar-cluster/)

The same dynamic applies at the sector and geography level: when federal awards, hiring signals, and private capital start concentrating in the same place, the window for CL positioning is narrow and front-loaded. This skill exists to detect that concentration before it is obvious.

## What it does

1. Reads active goal and pipeline state from Notion (Deals Pipeline + Capital Event Clusters DB)
2. Sweeps Capital Event Intelligence Inbox for new signals scored >= 70
3. Groups signals by sector, geography, and funding type -- updates cluster scores in the Clusters DB, **skipping any cluster with `Radar Active` unchecked** (Marvin's pause mechanism for a specific cluster -- pauses without archiving or deleting; same field `consortium-cluster-scan.md` checks)
4. Qualifies each cluster against the active goal: does this cluster contain a reachable prospect, an open funding window, and a signal CL can act on?
5. Auto-advances goal-aligned clusters: moves them to Active in the pipeline
6. Flags the rest for Marvin review with a one-line reason

## Output

- Updated cluster scores in Notion Capital Event Clusters DB
- Pipeline entries created or advanced for qualifying clusters — each entry includes a Placement Lead Record (see DE Match Logic below)
- Flagged exceptions posted to Google Chat (`CHET_WEBHOOK_URL`, "Chet Holmes findings" space) with cluster name, score, and reason for flag

## Detection signals (what to look for)

- Multiple federal awards in the same sector within a 90-day window
- Hiring concentration: 3+ institutions in the same geography posting the same role type
- Funding announcement followed by RFP within 60 days (compressed cycle = urgency signal)
- Cross-source corroboration: same sector appearing in Grants.gov + LinkedIn + Federal Register within 30 days

## Qualification criteria (auto-advance threshold)

A cluster auto-advances when all three are true:
- Cluster score >= 70 in the Capital Event Clusters DB
- At least one reachable contact in Notion Contacts DB matching the cluster's sector
- Active funding window open (award date + 180 days or RFP close date in the future)

Everything else gets flagged, not dropped.

## DE Match Logic

When a cluster auto-advances, the pipeline entry must include a Placement Lead Record. Derive the Recommended DE from the cluster's sector, and **write it to the real `Target DE` field on the Clusters DB record** -- this table gives the matching logic, but deriving the answer conceptually isn't enough if it never gets written; a live run flagged `Target DE` as empty on every existing cluster because this step was implicit, not an actual write instruction:

| Cluster Sector | Capacity Problem | Recommended DE(s) -- write to `Target DE` |
|---|---|---|
| Workforce / federal grants | Grant discovery and signal tracking — orgs miss sub-award windows | Chet (Opportunity Mapper) + Rohit (Intel Scan) |
| Proposal / RFP | Writing volume exceeds team capacity | Blair (Proposal Engine) |
| BD outreach / pipeline | No systematic prospecting or follow-up system | Sarah (BD Execution) + Alex (BD Research) |
| Research / intelligence | No function for translating sector signals into action | Ben (Intelligence Brief Delivery) + Josh (Brief Writer) |
| Contact / CRM | Intake and enrichment done manually or not at all | Kipp (Contact Enrichment) |

If the cluster already has a `Target DE` set (e.g. a roster-first Consortium cluster from `consortium-cluster-scan.md`, which sets it from `roster_capacity_map.json`'s `de_id` match), do not overwrite it with a sector-derived guess -- the roster-first match is more specific and takes precedence. This table is the fallback for clusters that didn't originate from a known DE signature.

All cluster-level pipeline entries are Lane 1 (Managed DE). Individual Crystal leads surface through Lori and Alex, not through cluster advancement.

## What this skill does NOT do
- Send external communications -- Sarah (BD Execution) owns outreach once a cluster advances to Deals Pipeline; Blair (Pitch Development) owns it once a deal reaches Proposal stage. Same Sales-department handoff as any other Chet-sourced deal, no new logic here.
- Apply its own scoring model -- individual signal scoring is Cassie's model (Operations), applied before signals reach this skill
- Remove clusters from the DB -- flags only, Marvin decides on removal
- Source new signals from the open web, or write to the Intelligence Inbox at all -- Chet's `consortium-cluster-scan.md` writes clusters (Clusters DB) only; turning a cluster into individual Inbox events is `ce-intelligence-agent`'s job, not this skill's or that one's

## Relationship to other Inbox sources (not a duplicate)

This skill is source-agnostic -- it sweeps whatever is already sitting in the Intelligence Inbox at score >= 70, regardless of which skill wrote it: `Agents/cassie/Skills/ce-intelligence-agent/` (covers AI Infrastructure, AI Workforce, and Consortium cluster types -- including Chet's roster-sourced clusters), `ce-radar-agent`, `ce-signal-mapper`, or `funder-intel-research`. It does not source anything itself and does not apply its own scoring model -- both are the sourcing skill's job. Sequence: a sourcing skill runs first to populate the Inbox, cluster-monitor runs after (Monday 7am) to decide pipeline advancement.
