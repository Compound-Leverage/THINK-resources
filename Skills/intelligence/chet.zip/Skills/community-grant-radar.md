# Community Grant Radar

## Purpose
Monitor community development grant programs — CDFI, EDA, HUD CDBG, foundation disbursements, municipal grants — for orgs that received awards and now face a labor gap to execute. Output: placement lead records.

## Target Grant Categories
- CDFI fund awards and NMTC allocations
- EDA Economic Development grants
- HUD CDBG / HOME awards
- SBA Community Navigator grants
- Private foundation grants > $250k to nonprofits with program delivery mandates
- State ARPA subgrant disbursements

## Scoring Criteria
- Award size relative to org capacity (labor gap likelihood)
- Time since award — closer to disbursement date = higher urgency
- Program delivery requirement (direct services required = higher intent)
- Prior CL placement in sector

## Output
Placement lead record per org:
- Org name, grant program, award amount, disbursement date
- Labor gap assessment: program delivery work the org likely cannot staff
- Score 0-100
- Add to Deals Pipeline if score >= 60, tag: community-grant
