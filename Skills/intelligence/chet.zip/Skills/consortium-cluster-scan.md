# Consortium Cluster Scan

## Purpose
Roster-signature-first cluster finding. Instead of scanning broad for capital events and testing which DE fits, start from a DE capability CL already knows how to place (`roster_capacity_map.json`), then hunt for every named consortium carrying that exact gap. One confirmed capability signature fans out into one campaign candidate per qualifying consortium, not one per event.

**The core question every step below answers, in two parts: does this initiative or policy create enough capacity shortages (Step 3's gap-volume test) for an audience we can serve (a real `de_id` match in `roster_capacity_map.json`, Steps 1-2)?** Both halves have to clear -- volume without a servable audience is a Build candidate for Marty (Step 6), not a cluster; a servable audience without enough volume doesn't clear the fan-out threshold (Step 5) either way.

No volume cap on scanning. Runs continuously, independent of any downstream card's Pause Status in Cassie's lead-pulling logic (`Agents/cassie/Skills/pause-resume-state-machine.md`) -- that logic governs lead-pulling within already-Qualified cards, never whether Chet keeps scanning or new cluster cards get created.

## Required load
`Agents/chet/core/roster_capacity_map.json` — one entry per placement-capable DE: `de_id`, `capacity_solved`, `signal_keywords`, `known_consortiums`. Load this before running any step below.

## Step 1 — Load pre-validated clusters
For each `de_id` in `roster_capacity_map.json` with `known_consortiums` populated, treat every listed consortium as a pre-validated cluster. Its dependency is already confirmed by the consortium's own documented existence — do not re-test dependency or re-derive it.

**Pause/stop check, before any per-cluster work below (Steps 3-4, 7) -- two gates, one manual and one automatic:**
- **Manual:** `Radar Active` unchecked -- Marvin's pause switch for a specific cluster, without archiving or deleting it. Separate from and unrelated to Cassie's Pause Status (which governs lead-pulling inside an already-Qualified Inbox card, not Chet's scanning).
- **Automatic:** Cluster Status = Saturating or Closed -- stop doing research on it. No Step 2 discovery expansion, no Step 3-4 re-mining. A Saturating or Closed cluster's window is ending or over; continuing to research it is wasted work regardless of `Radar Active`.

Either gate alone is enough to skip a cluster entirely this run.

## Step 2 — Discover new consortiums for unmapped signatures
For each `de_id` with `known_consortiums: []`, run its `signal_keywords` against the output of `capital-event-radar.md`, `community-grant-radar.md`, and `mandate-search-agent.md`. A hit that resolves to a named, bounded recipient list (a real consortium, cohort, or membership body — not a one-off org) becomes a new `known_consortiums` entry. Write it back into `roster_capacity_map.json` immediately so the next scan treats it as pre-validated (Step 1).

**What counts as a capital event, for those upstream radar sources (folded in from the now-retired `funder-intel` skill -- it was just a feed of capital-event updates, not a separate pipeline):** every category below traces back to one of two root causes -- **market conditions converging** (multiple economic/demand forces aligning on a sector or region) or **policy being enacted** (a law, order, or mandate creating the event directly). Either root cause opens a capacity window -- a time-bounded period where the resulting work has to get done before the window closes, whether or not a dollar allocation is attached.

- Market-convergence-driven: CHIPS Act allocations, Quantum Corridor projects, EDO/chamber initiatives, large employer facility announcements. Usually collapses into one initiative directly.
- Policy-enactment-driven: WIOA RFP cycles, state appropriations (workforce/economic development bills), federal grant cycles (DOL/EDA/SBA), and the broader policy/regulatory category -- executive orders, new law, compliance mandates, market forces/economic indicators. **Policy is distinct from market convergence in one important way: one policy event can cascade into multiple separate initiatives and consortiums, not just one.** Real example: the HBCU Research Capacity Act (one policy) produced both AHRI (a tight 15-member consortium) *and* the separate, wider HBCU Research Capacity Act cohort (89 non-AHRI HBCUs) as two distinct consortium-level responses to the same Act -- not one cluster, two.

**Implication for Step 2 discovery: when a policy-driven capital event is found, do not stop at the first matching consortium.** Explicitly check for cascade siblings -- other distinct consortium formations responding to the same policy. The difference between siblings isn't just scope/membership size -- **different sides of the affected network can have genuinely different capacity deficits from the same root policy**, not just a bigger or smaller version of the same gap. AHRI's tier (R1/R2-ambitious, already-competitive institutions) likely needs something further up the capability curve than the broader 89-member cohort's more foundational gap (basic OSP/grant-discovery capacity), even though both trace back to the same Act. Mine `capacity_solved`/`gap_volume` per sibling independently -- do not assume one sibling's profile applies to another. Each real cascade sibling is its own `known_consortiums` entry, not a duplicate of the first one found.

Not every capital event is a direct dollar allocation; a new compliance requirement can create the same capacity-deficit pattern without a funding announcement attached.

## Step 3 — Capacity gap volume test
Per consortium (existing or newly found in Step 2): count the entities within it that show the `signal_keywords` pattern. This is the gap-volume count. Roster status is implied Fill — the scan started from a confirmed DE capability, so do not re-score fit against the roster a second time.

## Step 4 — Mine per consortium
For each qualifying consortium, mine:
- `named_entities` — the consortium's membership list
- `buyer_identity` — title/role with hiring or contracting authority, per entity
- `budget_confirmation` — line item confirmed vs. inferred
- `window` — time estimate until the gap goes public or gets staffed elsewhere
- `gap_volume` — count from Step 3

Mine per qualifying consortium, not per individual event — a consortium with 15 members showing the signal is one candidate record covering all 15, not 15 separate records.

## Step 5 — Fan-out rule
One `capacity_solved` signature can produce multiple campaign candidates: one per qualifying consortium. Do not collapse multiple consortiums into a single output. Every consortium clearing the gap-volume threshold (configurable in `config.json`; default: gap_volume ≥ 3) gets its own candidate record.

## Step 6 — Unmatched signal routing
A signal that doesn't match any `de_id` signature in `roster_capacity_map.json`, seen 2+ times across scans, is not forced into a cluster. Log it as a Build candidate and route it to Marty (`Agents/marty/`) — Head of Product, DE library expansion — not reported as a placement cluster.

## Step 7 — Ongoing maintenance: refresh, cleanse, archive
Re-run Steps 3-4 against existing `known_consortiums` each Monday to keep `named_entities`, `budget_confirmation`, `window`, and `gap_volume` current, correcting or removing stale entries found along the way -- skip any cluster caught by either gate in Step 1's pause/stop check (`Radar Active` unchecked, or Status = Saturating/Closed), same as initial scanning.

**Archive on closed window:** when a candidate's `window` estimate has passed without conversion, archive that campaign record in Campaign Hub (Status → closed) rather than leaving it stale as Active. Loop in Julian (`Agents/julian/`, `JULIAN_WEBHOOK_URL`) when archiving — he owns segment-density scoring (`market-segment-session.md`) and needs to know when a scored segment's opportunity has actually closed.

## Output schema
Per qualifying consortium:
```json
{
  "de_id": "matched signature",
  "consortium": "named cluster",
  "named_entities": [],
  "buyer_identity": [],
  "budget_confirmation": "confirmed | inferred",
  "gap_volume": 0,
  "window": "estimate",
  "source": "known | newly-discovered"
}
```
No 0-100 fit score and no roster-status field — both are implied by starting the scan from `roster_capacity_map.json`.

Chet writes clusters, not individual Capital Events -- the Intelligence Inbox is not his to write to. Write each qualifying consortium candidate as a record in the Capital Event Clusters DB (`b55107b8-5850-4157-b4d1-a877c3d45fc5`), carrying `named_entities`, `buyer_identity`, `budget_confirmation`, `window`, and `gap_volume` as cluster fields/notes. **`Cluster Type` is a sector field (`Other`/`AI Workforce`/`AI Infrastructure`), not a structural one -- do not write "Consortium" there, it isn't a real option.** The Cluster Name itself is what signals this is a named consortium (e.g. "AHRI Consortium"), and `Layer 6 Targets` tags the org segment (HBCUs, Workforce Boards, etc.) where applicable.

**Write `Target DE` -- this is the real gap a live run flagged as empty on every cluster.** Set it to the matched DE's display name (e.g. "Grant" -- from `roster_capacity_map.json`'s `de_id`, not the raw `de_id` string) plus `capacity_solved` as one line, same format as the real Campaign Hub convention ("Grant Intelligence DE / Grant Intelligence DE Team"). This is what `cluster-monitor.md`'s DE Match Logic and downstream placement routing actually key off of -- an empty `Target DE` breaks that regardless of everything else being correct. Tag with `de_id` + consortium name too — that's the OKR/KR attribution path revenue traces back to the source capability signature through.

**Cluster Status is the flag, not a separate notification.** Real values: Forming / Confirmed / Active / Saturating / Closed.
- Newly-discovered consortium (Step 2, this run): Status = **Forming**.
- Once Step 3-4 confirm dependency and mine `named_entities`/`budget_confirmation`/`gap_volume` past the fan-out threshold: Chet promotes **Forming -> Confirmed autonomously**. This is Chet's own authority for the Consortium cluster type he owns end-to-end -- unlike Cassie's AI Infrastructure/Workforce clusters (manual-only promotion, her `ce-intelligence-agent/schema.md` Cluster Status Transitions table), Consortium clusters don't need Marvin's review to confirm because the dependency bar is mechanical: a named, bounded consortium either has the documented gap or it doesn't.
- Refresh (Step 7): leave Status as Confirmed/Active unless window < 30 days (-> Saturating, same auto-allowed transition Cassie uses).

Forming, Confirmed, and Active are all in Cassie's scan scope -- setting the right Status is the entire trigger for her `ce-intelligence-agent` to pick the cluster up. Turning a cluster into individual Capital Event records in the Inbox is entirely her job (Signal Sweep) -- her per-cluster scan already covers whatever is in scope in the Clusters DB, and Chet's rich mining here (Steps 3-4) gives her a running start instead of a cold WebSearch. No live coordination between them -- she reads the Clusters DB on her own schedule the same way she already does for AI Infrastructure/Workforce clusters.

## Data sources (queried, not owned by this skill)
`capital-event-radar.md`, `community-grant-radar.md`, `mandate-search-agent.md` — these stay as-is. This skill reads their output; it does not modify them. (`hidden-labor-market/workflow.md` was removed from this list 2026-07-06 -- it was never actually live (no config, no trigger) and its individual-prospect scan/score/outreach-handoff model contradicted Chet's "never contacts prospects" scope; archived at `Agents/chet/Skills/archive/hidden-labor-market/`.)

## Operating principle
Chet does not produce intelligence for its own sake — every output has a pipeline action attached (same principle as `placement-radar.md`). The difference here is direction: this skill starts from "what can CL already fill" and searches outward for consortiums, rather than starting from "what event is happening" and searching inward for fit.
