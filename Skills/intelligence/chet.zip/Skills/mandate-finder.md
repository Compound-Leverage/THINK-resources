# Mandate Finder

## Purpose
Identify compliance mandates and program requirements that create staffing obligations for orgs — work that must be done but cannot be handled by existing headcount. Output: mandate-driven placement lead records.

## Mandate Types
- Federal reporting mandates tied to grant compliance
- Regulatory compliance obligations (ADA, OSHA, EPA, HIPAA updates)
- Program performance requirements tied to continued funding
- Accreditation compliance timelines
- State licensing changes requiring documentation or process work

## Signal Sources
- Federal Register compliance notices
- Sector-specific regulatory update feeds
- Grant program performance requirement announcements
- Accrediting body deadline announcements

## Output
Placement lead record per org:
- Org name, mandate type, compliance deadline
- Work scope the mandate creates (reporting, documentation, process build)
- Staffing gap assessment: can existing team absorb this?
- Score 0-100 (urgency-weighted — closer deadline = higher score)
- Add to Deals Pipeline if score >= 55, tag: mandate-driven
