# Mandate Search Agent

## Purpose
On-demand search for specific mandate types by sector, region, or org type. Complements mandate-finder.md (which runs broad sweeps); this skill executes targeted searches when Marvin or another agent specifies a mandate context.

## Invocation
Pass: mandate type, target sector, target region, and/or org type.
Example: "Search for reporting mandates hitting community health centers in Texas following HRSA award cycles."

## Process
1. Parse mandate type and scope from input
2. Run targeted search across Federal Register, SAM.gov, sector news, and compliance feeds
3. Score each result against the org's ability to absorb the compliance work internally
4. Return ranked placement lead records

## Output
Ranked placement lead records — same schema as mandate-finder.md:
- Org name, mandate type, compliance deadline
- Staffing gap assessment
- Score 0-100
- Flag if score >= 55 for Deals Pipeline entry
