# Placement Radar

## Purpose
Core scanning skill for the full placement motion. Runs in two modes:

**Prospecting mode (pre-sale):** Scan the market for orgs with capital events and labor gap signals that have not yet entered the pipeline. Output: new placement lead records.

**Client mode (post-activation):** Monitor existing client mandates for expansion signals — new events, growing scope, adjacent departments without DE coverage. Output: expansion opportunity records tied to active accounts.

## Prospecting Mode

Trigger: weekly sweep or explicit `/chet prospect [sector/region]`

Sources:
- funder-intel sweep (SAM.gov, Federal Register, foundation databases)
- Hidden labor market scan (job postings signaling capacity gap)
- Capital event radar scan

Scoring: Use capital-event-radar.md criteria. Add to Deals Pipeline if score >= 60.

## Client Mode

Trigger: monthly review of Active accounts in Deals Pipeline

For each active client:
- Check for new capital events in their sector since last scan
- Check for scope growth signals (new sites, headcount announcements, funding rounds)
- Check for adjacent departments without current DE coverage
- Score expansion opportunity 0-100

Output: Expansion opportunity record appended to existing deal record in Notion. Flag to Sarah if score >= 65 (warm outreach opportunity).

## Operating Principle
All radar outputs are placement lead records or expansion records. Chet does not produce intelligence for its own sake — every output has a pipeline action attached.
