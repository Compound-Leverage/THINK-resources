# Schmidt 5-Year Forward Map

## Purpose
Build a 5-year forward-looking capital event map for a target sector. Identifies the pipeline of anticipated events — infrastructure cycles, legislative funding reauthorizations, grant program expirations and renewals, regulatory overhaul timelines — so CL can position placements before the window opens rather than after.

## Inputs
- Target sector (e.g., clean energy, community health, workforce development)
- Optional: target geography

## Process
1. Map known funding cycles and reauthorization timelines in the sector
2. Identify anticipated regulatory changes with implementation deadlines
3. Assess which orgs are likely recipients by size, track record, and proximity to program
4. Estimate the labor gap each event creates (scope, duration, urgency)
5. Rank by proximity to window opening

## Output
5-year sector capital event map:
- Event name, type, anticipated date range
- Likely org recipients (org name, location, estimated award range)
- Labor gap assessment per event
- CL placement window (optimal outreach timing = 6-12 months pre-event)
- Priority tier: Tier 1 (within 12 months), Tier 2 (1-2 years), Tier 3 (3-5 years)

Save to: `output/sector-maps/{sector}-{year}-forward-map.md`
