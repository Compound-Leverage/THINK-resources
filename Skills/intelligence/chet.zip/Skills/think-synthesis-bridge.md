# THINK Synthesis Bridge

## Purpose
Convert intelligence output from Rohit, Josh, and Ben into actionable placement lead records. Intelligence briefs contain signal — this skill extracts the orgs and events within a brief that represent placement opportunities.

## When to Use
After receiving a THINK Intelligence Brief, Marvin Brief, or Rohit scan output. Run this skill to extract placement leads from the signal rather than treating the brief as an end product.

## Process
1. Read the intelligence brief or scan output
2. Identify every org mentioned — filter for orgs with:
   - A named capital event (grant, program launch, policy change)
   - A stated or implied labor constraint
   - Size profile consistent with CL placement (5-500 FTE)
3. Score each org-event pair using capital-event-radar.md criteria
4. Output as placement lead records

## Output
Placement lead records extracted from brief:
- Org name, event mentioned in brief, labor gap inference
- Score 0-100
- Source brief reference
- Add to Deals Pipeline if score >= 60

Attach a "sourced from: [brief name/date]" tag to each record for pipeline traceability.
