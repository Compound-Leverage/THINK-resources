# Chet Holmes — Hook Map

| When to run | Trigger | Fires |
|---|---|---|
| Weekly, Monday 3:00am ET | Cron schedule | **Research + update:** `consortium-cluster-scan.md` -- discover/mine consortiums, write as Consortium-type clusters to the Clusters DB, refresh/archive. Writes clusters only, never the Intelligence Inbox. Must complete before Cassie's 4am `ce-intelligence-agent` run, which turns clusters into individual Inbox events |
| Weekly, Monday 7:00am ET | Cron schedule | **Advance:** `cluster-monitor.md` sweeps the Intelligence Inbox (score >= 70, any source) and decides Deals Pipeline advancement |
| Marty routes a `roster_capacity_map.json` `_needs_review` research flag | Explicit handoff from `Agents/marty/Skills/product-review.md` | Research and populate `signal_keywords`/`known_consortiums` for the flagged DE; write result back, notify Marty it's resolved |
| Explicit ask naming Chet or clusters | User message in Claude Code session | Cluster scan or advance, scoped to what's asked |
| End of the 7am advance run | Automatic, same Monday sequence | One consolidated completion report to Google Chat (`CHET_WEBHOOK_URL`) -- consortiums researched, clusters written, clusters advanced, exceptions flagged to Marvin |
