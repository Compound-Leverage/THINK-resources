# Free Playbook Generator

## Purpose
Produce a free playbook as a lead magnet or pre-sale asset. The free playbook demonstrates DE value in the prospect's specific context — it is a placement motion asset, not a generic resource.

## When to Use
- A qualified prospect is evaluating CL before committing
- Marvin wants to demonstrate DE value before a sales call
- A THINK School member is a warm placement prospect

## Playbook Types
- **DE Starter Playbook:** What a placed DE would do in the prospect's org in the first 30 days
- **Capital Event Response Playbook:** How to capture a specific event opportunity the prospect is facing
- **Labor Gap Audit Playbook:** How to assess what work is going undone in their org

## Process
1. Read prospect record from Deals Pipeline or Contacts DB
2. Identify their capital event context and labor gap type
3. Select playbook type based on context
4. Generate playbook (< 8 pages, actionable, DE-centric)
5. Present to Marvin for review
6. On GO: deliver via Sarah's HTML email to prospect

## Output
Free playbook (Markdown → PDF via Canva/Drive):
- Stored to Drive: `assets/playbooks/free/{org-slug}-{date}.pdf`
- Delivered by Sarah with placement framing in the email body
