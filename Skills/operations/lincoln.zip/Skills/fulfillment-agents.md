# Fulfillment Agents

## Purpose
Orchestration skill for the full client fulfillment motion. Coordinates Lincoln's own playbook builds with Marcus (proof points) and Marty (DE capability additions) to ensure a placed client gets the full success package.

## Scope
Fulfillment = everything from signed agreement to a fully operational DE team at the client.

Lincoln owns:
- Onboarding framework (new-client-setup.md)
- Playbook delivery (success playbooks, expansion motion designs)
- DE performance check-ins

Marcus owns:
- Proof point capture (testimonials, case studies from this client)
- Evidence package for renewal and expansion conversations

Marty owns:
- DE capability additions if client scope grows
- DE upgrade briefs for custom requirements

## Coordination Pattern
1. Lincoln runs onboarding and first 90 days
2. At day 30: Marcus collects first proof points
3. At day 60: Lincoln delivers success playbook
4. At day 90: Lincoln produces expansion motion design; Marty reviews for new DE additions
5. Marty opens DE upgrade brief if expansion is approved

## Output
Fulfillment status log per client in Notion Deals Pipeline (Active stage fields):
- Onboarding: complete / in progress
- First proof points: collected / pending
- Success playbook: delivered / pending
- Expansion motion: designed / pending
