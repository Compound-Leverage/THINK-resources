# Irreplaceable Playbook Builder

## Purpose
Build the Irreplaceable Playbook — CL's signature client deliverable that makes the client org's CL DE team irreplaceable by documenting the DE workflows, decision logic, and outputs as institutional knowledge. Positioned as a retention and expansion asset.

## When to Use
- Client is at 60+ days of active operation
- Renewal conversation is approaching
- Client is evaluating expansion to additional departments

## What the Playbook Contains
1. **DE Roster Summary:** each placed DE, their role, and what they produce
2. **Workflow Documentation:** the 3-5 workflows each DE runs, step by step
3. **Output Inventory:** what would stop happening if the DE subscription ended
4. **Gap Map:** work the org's team still does manually that a DE could absorb
5. **Expansion Roadmap:** recommended next DEs based on the org's growth trajectory

## Process
1. Read current client record: DE scope, active workflows, org structure
2. Interview Marvin (or client operator) for workflow confirmation
3. Build playbook sections (5 sections, 15-20 pages total)
4. Review gate: Marvin approves before delivery
5. Deliver via Sarah's email to primary client contact

## Output
Irreplaceable Playbook:
- Google Drive: `clients/{org-slug}/irreplaceable-playbook-{date}.pdf`
- Delivered by Sarah with renewal/expansion framing
