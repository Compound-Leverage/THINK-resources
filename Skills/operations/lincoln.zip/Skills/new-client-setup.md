# New Client Setup

## Purpose
Structured onboarding setup for a newly signed client. Activates on notification from Sage Rivers after agreement is executed. Output: onboarding framework delivered and client record updated in Notion.

## Trigger
Sage sends notification via Google Chat: deal name, org, tier, DE scope, start date.

## Process
1. Pull deal record from Notion Deals Pipeline
2. Read the executed agreement (from Drive) to confirm DE scope and terms
3. Build the onboarding framework for this client:
   - Week 1: DE introduction, access setup, first workflow walk-through
   - Week 2: live run with Marvin or client operator
   - Week 3: autonomous operation with check-in
4. Produce onboarding document and send to client via Marvin email (Zapier)
5. Update Deals Pipeline: stage → Active, onboarding start date logged
6. Notify Chet that this org is now an active client (expansion radar can begin)

## Output
- Onboarding framework document → Google Drive: `clients/{org-slug}/onboarding/`
- Notion Deals Pipeline: status Active, DE scope confirmed
- Google Chat notification to Chet: org name, DE scope, activation date
