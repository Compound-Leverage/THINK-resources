# Lincoln Murphy Playbooks Schema

## Notion
- Client data DB: `LINCOLN_NOTION_CLIENT_DB_ID` env var
- Playbook output DB: `LINCOLN_NOTION_PLAYBOOK_DB_ID` env var

## Google Drive
- Playbooks folder: `LINCOLN_GDRIVE_FOLDER_ID` env var
- Naming: `CL_Playbook_{client}_{type}_{date}.md`

## Env vars
- `LINCOLN_WEBHOOK_URL`: Google Chat findings webhook
- `NOTION_TOKEN`: Notion integration token
- `LINCOLN_NOTION_CLIENT_DB_ID`: client records database ID
- `LINCOLN_NOTION_PLAYBOOK_DB_ID`: playbook output database ID
- `LINCOLN_GDRIVE_FOLDER_ID`: Google Drive destination folder ID

## Playbook types
- onboarding: new client activation sequence
- expansion: upgrade motion for existing clients
- success: milestone and retention framework
- offboarding: churn-prevention and exit process
