# Playbook Workflow

1. Read client data from Notion (engagement details, goals, current stage, any prior notes).
2. Identify playbook type needed: onboarding framework, customer success playbook, or expansion motion design.
3. Draft the structured playbook document with clear milestones, owner assignments, and success criteria.
4. Write the finished document to Notion or Google Drive and post a summary with the output link to Google Chat.
5. Flag any missing client data or ambiguous scope to Marvin before proceeding.

## Email Delivery (client send)

New client trigger: when a Deals Pipeline record moves to Status = Active (subscription signed), Lincoln builds the onboarding playbook and delivers it via email.

6. **Format as HTML email.** Subject: `Welcome to Compound Leverage — Your Onboarding Playbook`. Body: brief welcome, what the playbook covers, Drive link as CTA.

   ```html
   Hi [first_name],
   
   Welcome to Compound Leverage. I've put together your onboarding playbook — everything
   you need for the first 30 days: your DE team setup, key milestones, and who to contact
   at each stage.
   
   [View Playbook button → Drive link]
   
   Your first check-in is at day 7. I'll reach out then. In the meantime, reply here with
   any questions.
   
   Marvin Harris
   Compound Leverage | marvin@compoundleverage.com
   ```

   **Button:**
   ```html
   <a href="[DRIVE_LINK]" style="display:inline-block;background-color:#6B21A8;color:white;
   padding:10px 20px;border-radius:4px;text-decoration:none;font-weight:bold;">
   View Your Playbook
   </a>
   ```

7. **Marvin approval gate.** Post to Google Chat:
   ```
   LINCOLN — PLAYBOOK READY: [Client Name]
   Type: [onboarding / success / expansion] | Drive: [link]
   Reply GO to send, HOLD to review first.
   ```
   Do not send until Marvin replies GO.

8. **Send on GO.** Send via `config.zapier_marvin_send_action_url`. From: marvin@compoundleverage.com.
   After send: update Deals Pipeline record (onboarding_playbook_sent = true, onboarding_sent_date = today). Log to Google Chat: `LINCOLN — PLAYBOOK SENT: [Client Name]`.

## Rules
- No external send without Marvin GO
- Build playbook before requesting GO — never request GO on an incomplete draft
- No em dashes in copy
- From is always marvin@compoundleverage.com
