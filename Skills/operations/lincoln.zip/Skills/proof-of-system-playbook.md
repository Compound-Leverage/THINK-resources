# Proof of System Playbook

## Purpose
Build a Proof of System Playbook for a prospect or early-stage client. Shows that CL's DE placement system produces measurable results — not a promise, a documented track record. Feeds the sales motion and closes skepticism before it blocks a deal.

## When to Use
- A prospect asks "has this worked for orgs like mine?"
- A qualified prospect needs proof before committing
- A new client is evaluating after their first 30 days

## What the Playbook Contains
1. **System Overview:** how the DE placement motion works (1 page, no jargon)
2. **Case Evidence:** 2-3 proof points from Marcus with org context, event type, DE type, and measurable outcome
3. **Fit Assessment:** why this prospect/client's context matches the proven pattern
4. **Next Step:** one clear action (schedule a call, sign agreement, expand scope)

## Proof Point Source
Pull from Marcus's proof-points/ output. Filter for:
- Sector match with the prospect
- Capital event type similarity
- Org size proximity

## Process
1. Identify target prospect/client from Deals Pipeline
2. Pull relevant proof points from Marcus's output
3. Build playbook (4-6 pages, tight)
4. Marvin reviews before delivery
5. Deliver via Sarah's email

## Output
Proof of System Playbook → Drive: `assets/playbooks/proof-of-system/{org-slug}-{date}.pdf`
