# Hook Map -- Lincoln

| Trigger | When to run | Action |
|---------|-------------|--------|
| New client engagement created in Notion | Client enters THINK School or Accelerator at onboarding stage | Run playbook workflow, produce onboarding framework |
| Explicit request from Marvin | Any time Marvin asks for a playbook or expansion motion design | Load Skills/playbooks/workflow.md and execute |
| Client reaches expansion milestone in Notion | Client advances past initial onboarding stage | Run expansion motion design workflow |
