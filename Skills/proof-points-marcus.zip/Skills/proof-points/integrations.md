# Proof Point Agent — Integrations

## Notion Queries

**Get recent fulfillment items:**
```
SELECT * FROM "Fulfillment Tracker"
WHERE Status IN ['Completed', 'In Progress']
AND Type IN ['Diagnostic', 'Accelerator', 'THINK School Outcome']
ORDER BY "Completion Date" DESC
LIMIT 10
```

**Get proof points by funder type:**
```
SELECT * FROM "Proof Points"
WHERE "Funder Type Tags" CONTAINS "WIOA"
ORDER BY "Creation Date" DESC
```

**Get most recent completed proofs:**
```
SELECT * FROM "Proof Points"
WHERE Status = "Completed"
ORDER BY "Completion Date" DESC
LIMIT 5
```

**Create/update Proof Points record:**
```
INSERT INTO "Proof Points":
- Name: "[Organization] — [Challenge Type]"
- Status: Active | Completed
- Challenge Description, Methodology Applied, Key Results, Client Quote
- Funder Type Tags: WIOA | EDA | Federal | Foundation | CHIPS (multi-select)
- Case Study (Formatted): [1-page narrative]
- Source: Fulfillment Tracker | THINK School | Accelerator
- Creation Date: [Today]
```

**Link to Newsletter DB (on Completed):**
```
INSERT INTO "Newsletter":
- Headline: "[Organization] Achieves [Key Metric]"
- Body: [Case study 1-pager]
- Status: Ready to publish
- Content Type: Case Study
```
