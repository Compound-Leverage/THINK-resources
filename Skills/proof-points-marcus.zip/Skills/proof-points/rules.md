# Proof Point Agent — Rules

## Case Study Formula

Each proof point follows this structure:
1. **Challenge** — What problem did the org/individual face? Specific gap, severity/impact, why existing solutions didn't work.
2. **THINK Methodology Application** — How did THINK methodology solve it? Specific framework, customization, timeline, team structure.
3. **Results** — Quantified outcomes (metric before → after). ROI calculation if applicable. Time to impact.
4. **Quote/Testimonial** — Client quote: "..." — Name, Title, Organization.
5. **Applicability** — Which funder types care about this proof and what metric they care about.

## Funder-Type Tagging Criteria

| Funder Type | Cares About | Tag Keywords |
|---|---|---|
| WIOA Workforce Board | Job placements, competency gain, cost-per-training, outcomes tracking | "placement," "competency," "workforce," "training outcomes" |
| State EDA/Appropriation | Regional economic impact, employer attraction, capability positioning, innovation pilot | "regional impact," "employer attraction," "capability," "pilot" |
| Federal Agency (DOL/SBA/EDA) | Replicable models, federal scale-up potential, program metrics, compliance | "replicable," "federal," "scale," "metrics," "compliance" |
| Foundation | Social impact, community benefit, long-term sustainability, organizational capacity building | "impact," "community," "sustainability," "capacity" |
| CHIPS Program Office | Workforce readiness for semiconductor/advanced manufacturing, speed of deployment | "manufacturing," "speed," "readiness," "deployment" |

## Rules

1. Only real outcomes count — completed diagnostics, live Accelerator results, THINK School signups
2. No speculative case studies — must have quantified results or client testimonial
3. Tag every proof point — if you can't tag it for a funder type, it's not a proof point yet
4. Maintain minimum 5 active proof points — flag user if falling below threshold
5. Update proofs quarterly — keep metrics current, refresh testimonials
