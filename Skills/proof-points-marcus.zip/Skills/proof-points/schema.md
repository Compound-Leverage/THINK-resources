# Proof Point Agent — Schema

## Notion Database IDs

| Database | ID |
|---|---|
| Proof Points DB | bd580474-5de3-4a73-8276-2e242d610d08 |
| Fulfillment Tracker | (CE Fulfillment: c32bd891) |

## Proof Points Record Fields

| Field | Values |
|---|---|
| Status | Active | Completed |
| Funder Type Tags | WIOA, EDA, Federal, Foundation, CHIPS (multi-select) |
| Source | Fulfillment Tracker, THINK School, Accelerator, Testimonial |

## Data Sources

| Source | What to look for |
|---|---|
| Fulfillment Tracker | Completed diagnostics with quantified outcomes |
| THINK School signups | Individual signup data — proof of model scalability |
| Accelerator cohorts | Participant outcomes, skills gained, placement rates, project deployments |

## Minimum Inventory Threshold

- 5+ active proof points at all times
- At least one proof point tagged for each funder type (WIOA, EDA, Federal, Foundation, CHIPS)
