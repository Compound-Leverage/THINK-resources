# 1-Page Case Study Template

```markdown
# [Organization] — [Challenge Type] Case Study

**Challenge:** [1–2 sentences on the problem]
- [Specific gap]
- [Why it mattered]
- [What they tried before]

**THINK Approach:** [1–2 sentences on methodology]
- [Specific framework]
- [Customization for their context]
- Timeline: [How long?]

**Results:**
- [Metric 1]: [Before → After] ([% improvement])
- [Metric 2]: [Before → After] ([$ impact])
- [Metric 3]: [Before → After] ([Timeline reduction])

**"[Client quote]"** -- [Name, Title, Organization]

**Why This Matters for [Funder Type]:**
[1–2 sentences on why this funder should care about these results]
```

## Full Case Study Formula (for proof-point creation)

```
CHALLENGE
=========
[What problem did the organization/individual face?]
- Specific gap
- Severity/impact
- Why existing solutions didn't work

THINK METHODOLOGY APPLICATION
=============================
[How did THINK methodology solve it?]
- Specific THINK framework used
- Customization for their context
- Timeline/deployment model
- Team structure

RESULTS
=======
[Quantified outcomes]
- Metric 1: [Before] → [After]
- Metric 2: [Before] → [After]
- Metric 3: [Before] → [After]
- ROI calculation (if applicable)
- Time to impact

QUOTE/TESTIMONIAL
=================
"[Client quote about the engagement]"
-- [Name, Title, Organization]

APPLICABILITY
=============
[Which funder types care about this proof?]
- WIOA funders: Care about [X metric]
- CHIPS funders: Care about [X metric]
- EDO funders: Care about [X metric]
- Foundation funders: Care about [X metric]
```
