# Proof Point Agent — Workflow

Weekly extraction. Target: 1–2 new case studies per session. Maintain minimum 5 active proof points.

---

## Phase 1: Data Extraction

**Query Fulfillment Tracker:**
```
SELECT * FROM "Fulfillment Tracker"
WHERE Status IN ['Completed', 'In Progress']
AND Type IN ['Diagnostic', 'Accelerator', 'THINK School Outcome']
ORDER BY "Completion Date" DESC
LIMIT 10
```

**Extract from each:**
- Challenge: What problem did they have?
- Methodology: What THINK framework/tools were used?
- Results: What quantified outcomes? (%, $, timeline reduction, capability gain)
- Testimonial: Can you get a quote?
- Funder relevance: Which funder types would find this compelling?

---

## Phase 2: Case Study Narrative Creation

See `templates/case-study.md` for the 1-page case study structure.

---

## Phase 3: Funder-Type Tagging

Tag each proof point with which funder types find it most compelling (see rules.md for tagging criteria).

**Tagging in Notion:**
```
"Funder Relevance" (Multi-Select):
☑ WIOA
☑ State EDA
☐ Federal
☑ Foundation
☑ CHIPS
```

---

## Notion Integration

**Create/Update Proof Points Database:**
```
INSERT INTO "Proof Points":
- Name: "[Organization] — [Challenge Type]"
- Status: Active | Completed
- Challenge Description: [1–2 sentences]
- Methodology Applied: [THINK framework used]
- Key Results: [Quantified outcomes]
- Client Quote: [Testimonial]
- Funder Type Tags: [Multi-select: WIOA | EDA | Federal | Foundation | CHIPS]
- Case Study (Formatted): [1-page narrative]
- Applicability: [Why funders should care]
- Source: [Fulfillment Tracker | THINK School | Accelerator]
- Creation Date: [Date proof point compiled]
```

**Link to Newsletter Database (when marked "Completed"):**
```
INSERT INTO "Newsletter":
- Headline: "[Organization] Achieves [Key Metric]"
- Body: [Case study 1-pager]
- Status: Ready to publish
- Content Type: Case Study
```

---

## Weekly Proof Point Report

```
PROOF POINTS STATUS
===================
Active Proof Points: [X]
- WIOA-relevant: [X]
- EDA-relevant: [X]
- Federal-relevant: [X]
- Foundation-relevant: [X]
- CHIPS-relevant: [X]

Newly Completed This Week: [X]
[List new case studies]

Proof Points by Source:
- Diagnostics: [X]
- Accelerator: [X]
- THINK School: [X]

Recommendations for Pitch Dev Agent:
[Which proof points are most relevant to current deals in Pitch stage?]
```

---

## Execution Cadence

- Weekly extraction: check Fulfillment Tracker for new completions
- Monthly proof point review: update tags, identify gaps in funder-type coverage
- Quarterly deep clean: refresh testimonials, update metrics
