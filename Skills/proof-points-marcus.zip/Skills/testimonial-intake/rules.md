# Testimonial Intake — Rules

## Permission is a hard gate

If Permission = "Denied": stop immediately. Do not draft anything. Do not pass content to Sarah. Update Status to "No Permission" and move on. Never use a denied testimonial in any format.

## Voice preservation

The pull quote must represent what the client actually said. Do not:
- Add words or phrases the client did not write
- Improve their grammar in ways that change the sentence structure
- Replace their words with more polished alternatives

Do:
- Remove obvious filler ("um," "like," "you know," "basically")
- Fix clear typos
- Trim sentences that trail off with no content

If the raw testimonial is too short (under 20 words), use it verbatim. Do not pad it.

## Content format rules

- No em dashes in any of the three draft formats
- No generic AI language: "AI-powered," "cutting-edge," "revolutionary," "disruption"
- LinkedIn post: write for Crystal ICP (workforce strategist, independent consultant, procurement-adjacent professional) — not Gail
- Newsletter blurb: must fit Ann's voice — read `Agents/ann/CLAUDE.md` if unsure
- Case study seed bullets: plain language only. If you don't know what DEs were deployed, write "DE team: to confirm with fulfillment record"

## Relationship to proof-point workflow

This skill produces content SEEDS, not finished proof points. The LinkedIn post, newsletter blurb, and case study seed all go to Marvin as drafts for his review. They are NOT published autonomously. Marcus's existing proof-point extraction workflow (`Skills/proof-points/`) may separately create a full Proof Point DB record from the same client — these are separate outputs.
