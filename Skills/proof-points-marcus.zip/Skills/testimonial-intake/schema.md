# Testimonial Intake — Schema

## Notion Database IDs

| Database | ID |
|---|---|
| CE Fulfillment (Fulfillment Tracker) | c32bd891-00e3-46bc-a26e-9a6e3f045de4 |

## Record Fields Read

| Field | Type | Notes |
|-------|------|-------|
| Name | title | "[client_name] — [business_name]" format |
| Source | select | filter value: "Testimonial" |
| Status | select | filter value: "New" |
| Client Name | rich_text | individual's name |
| Business Name | rich_text | org or company name |
| Experience | rich_text | client's free-text experience description |
| Biggest Result | rich_text | client's described result |
| Permission | select | "Granted" or "Denied" |
| Submitted Date | date | ISO date |

## Status Transitions

```
New → Processed (permission granted, drafts completed)
New → No Permission (permission denied)
New → Sarah Failed — Manual Review (Sarah sub-agent error)
```

## Marvin User ID (for @mention)

`1e84ee83-25c6-4ac3-a3c9-da439bd9a30c`

## Environment Variables

- `NOTION_API_KEY` — Notion read/write (GitHub Secret, already present)

## Log Path

`Logs/marcus-intake/YYYY-MM-DD.log`
