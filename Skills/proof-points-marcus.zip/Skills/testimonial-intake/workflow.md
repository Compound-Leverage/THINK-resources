# Testimonial Intake — Workflow

**Agent:** Marcus Sheridan (Evidence Builder)
**Sub-agent:** Sarah Grant (BD Execution)
**Trigger:** Daily queue sweep — runs as part of Marcus's proof-point harvest

---

## When This Runs

Any time a new record exists in the CE Fulfillment (Fulfillment Tracker) database with:
- Source = "Testimonial"
- Status = "New"

Records are created automatically when a client submits the form at compoundleverage.com/testimonial.

---

## Step 1: Fetch the queue

Use Notion MCP `notion-query-database-view` to query the CE Fulfillment database.

Filter: Source = "Testimonial" AND Status = "New"

If queue is empty: log the empty run and stop. No output.

---

## Step 2: Process each record

For each record:

**2a. Check permission**

Read the Permission field.
- If Permission = "Denied": skip all drafting steps. Update Status to "No Permission". Log. Move to next record.
- If Permission = "Granted": proceed.

**2b. Format the pull quote**

Read Experience and Biggest Result fields.

Combine into a clean pull quote:
- 40-60 words total
- Preserve the client's authentic voice — only remove filler words, fix obvious typos, trim run-ons
- Do not add words the client did not use
- Format: "Quote text." — [Client Name], [Business Name]
- No em dashes anywhere

**2c. Draft three content formats**

**Format 1: LinkedIn post (200-250 words)**
- Open with a specific scenario or result from the testimonial (not the quote)
- Second paragraph: what made it possible (DE team work, not "AI" generically)
- Third paragraph: the pull quote as blockquote
- Close with a CTA appropriate for Crystal ICP (workforce/economic dev professional)
- No em dashes. No generic AI hype language.

**Format 2: Newsletter blurb (80-100 words)**
- Designed to drop inline in Ann Reeves's WARM edition
- Format: short proof-first sentence + the pull quote + one-sentence context
- No header needed — it slots between paragraphs
- Fits the Ann Reeves newsletter voice: conversational, evidence-first, no fluff

**Format 3: Case study seed (3 bullets)**
- Bullet 1 — Situation: what the client was dealing with before
- Bullet 2 — DE team deployed: which agents, what they did
- Bullet 3 — Result: what changed, with specifics if available

If the testimonial doesn't contain enough detail for a specific result, write: "Result: [specific outcome from testimonial — or 'To be confirmed with client if featured']"

---

## Step 3: Invoke Sarah as sub-agent

Pass Sarah this handoff block:

```
INTAKE TYPE: testimonial
CLIENT: [client_name], [business_name]
FULFILLMENT RECORD ID: [Notion record ID]
PULL QUOTE: [formatted pull quote]
LINKEDIN DRAFT: [full post text]
NEWSLETTER BLURB: [blurb text]
CASE STUDY SEED: [3 bullets]
GMAIL ACTION: create_draft to Marvin's Gmail
NOTION ACTION: child page in CE Fulfillment record [ID], title: "Approve and publish testimonial for [client name]"
MENTION: 1e84ee83-25c6-4ac3-a3c9-da439bd9a30c
```

Sarah will:
1. Bundle all three formats into a single Gmail draft with clear section headers
2. Create the Gmail draft via `mcp__claude_ai_Gmail__create_draft`
3. Create a child page in the CE Fulfillment record as a task for Marvin
4. @mention Marvin in a comment on the record

---

## Step 4: Update record status

After Sarah confirms completion, use Notion MCP `notion-update-page` to set the record's Status to "Processed".

---

## Step 5: Log the run

Append to `Logs/marcus-intake/YYYY-MM-DD.log`:
```
[timestamp] | marcus | testimonial-intake | [N] processed, [N] skipped (no permission) | [names]
```

Post to Google Chat only on exception:
- Sarah sub-agent returned an error
- Queue had entries but zero were processed

Routine completions are silent.
