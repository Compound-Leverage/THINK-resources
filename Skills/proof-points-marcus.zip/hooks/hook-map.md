# Marcus Sheridan -- Hook Map

| Trigger | Event | What fires | Notes |
|---------|-------|------------|-------|
| Fulfillment Tracker updated (Notion) | New or updated diagnostic, THINK School signup, or Accelerator cohort record | `/proof-point` skill | Weekly cadence; target 1-2 new case studies per run |
| Manual invoke | Marvin or Pitch Dev Agent requests a specific case study | `/proof-point` skill with client name arg | On-demand; bypasses weekly schedule |
