# Skill: Proposal Strategy

Porter develops competitive positioning, win themes, and case study selection for each proposal. Builds the messaging framework that Quinn executes. Output answers: why CL wins this deal and what story the proposal tells.

## Inputs (from Maya)
- Chase's Discovery Brief (client priorities, pain points, stakeholder context)
- Priya's Assessment Package (capability mapping, ROI figures, pricing)
- Known competitors from intake

## Process
1. Competitive analysis: review known competitors + infer likely ones from deal type/industry; develop positioning counter for each; create ghost messaging
2. Win theme development: analyze client pain points + CL differentiators; develop 3-5 themes; map each theme to proposal sections with emphasis level
3. Case study matching: score each CL case study against opportunity (industry 30%, challenge 30%, solution 20%, size 10%, outcome 10%); select top 3; prepare snippets
4. Synthesize into strategy package with elevator pitch

Load the company profile passed by Maya (`Agents/maya/config/profiles/[company].md`) for differentiators and competitor positioning.

## Win theme categories
Every proposal should address at least 3 of these 5:
| Category | Question Answered |
|---|---|
| Capability | Can CL actually do this? |
| Value | What will the client get? |
| Approach | How will CL do it? |
| Risk | Why is this safe? |
| Partnership | Why CL specifically? |

## Competitor counter-positioning reference
| Type | Their weakness | CL counter |
|---|---|---|
| Big consulting | Cost, speed, junior staff | Senior practitioners, faster delivery, outcome-aligned pricing |
| Tech vendors | Strategy gap, vendor lock-in | Strategy-first, vendor-agnostic, outcomes not features |
| Boutiques | Scale, methodology, AI capability | Proven methodology, DE capability, strategic depth |
| DIY/Internal | Speed, expertise, distraction | Faster time to value, risk transfer, proven approach |
| Status quo | Cost of inaction | Quantify inaction cost, competitive urgency |

## Output: Strategy Package
- Competitive positioning (competitors analyzed, counter-positioning, ghost messaging)
- Win themes (3-5 themes with section mapping, proof points, language to use/avoid)
- Case studies selected (top 3 with match scores and snippets)
- Strategy summary (elevator pitch, top 3 differentiators, recommended tone)
- Proposal guidance (sections to emphasize, risks to address)

## Handoff
Delivers to Maya for strategy approval gate. Strategy package hands off to Quinn with approved direction.

## Rules
- Never claim CL capabilities that do not exist -- if a capability is weak, flag it rather than overstate
- Ghost messaging should be implicit, never disparage competitors by name
- No em dashes in any output
