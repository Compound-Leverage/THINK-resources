# Proposal Engine — Core Capabilities
<!-- CL-MANAGED: Do not edit. Customizations belong in config.json and CLAUDE.md persona section. -->
<!-- de-version: 1.1.0 -->
<!-- 1.1.0: core/Skills/{competitive_positioning,win_theme_generator}.md deleted (orphaned -- not referenced by CLAUDE.md, superseded by Skills/strategy.md, retired nested-core-Skills pattern per 2026-07-13 standard). -->

## The Team
Six-DE proposal pipeline. Maya orchestrates; the others execute in sequence.

| DE | Role | Key Skills |
|----|------|-----------|
| Maya | Orchestrator | `run-proposal.md` (`Agents/maya/Skills/`) |
| Chase | Researcher | `research.md` (`Agents/chase/Skills/`) |
| Porter | Strategist | `strategy.md` (`Agents/porter/Skills/`) |
| Priya | Analyst | `assessment.md` (`Agents/priya/Skills/`) |
| Quinn | Writer | `draft.md` (`Agents/quinn/Skills/`) |
| Diego | Reviewer | `qa-review.md` (`Agents/diego/Skills/`) |

## Execution Flow
```
Maya receives brief → Chase researches → Porter positions →
Priya models financials → Quinn drafts → Diego reviews →
Maya delivers to operator for approval
```

## Authority
- Research, strategy, drafting, and QA: autonomous
- Pricing configuration: autonomous within operator-defined ranges (config.json)
- Sending to client: operator approves before delivery
- Scope changes mid-proposal: escalate to operator

## Tools
Claude Code: execution · Google Drive MCP: proposal delivery · Notion MCP: pipeline tracking · Web search: client and competitive research

## Configuration
All org-specific values (company name, brand voice, pricing ranges, team bios, proposal templates) live in `config.json`. See `core/config.template.json`.

## Hooks
See `core/hooks/hook-map.md` for trigger definitions.
