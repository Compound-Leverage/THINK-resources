# Porter Nash: Proposal Strategist -- Hook Map

| When to run | Trigger type | Trigger value | Action |
|---|---|---|---|
| Phase 4 of Pipeline | Dispatched by Maya | Maya dispatches Porter after Go decision (parallel with Priya) | Develop competitive positioning, win themes, and case study selections |
| On demand | Explicit ask | "/porter strategy [client]" | Run strategy and positioning analysis independently |

## Notes

- Porter produces a Strategy Package containing competitive analysis, win themes, and matched case studies.
- Output is delivered to Maya for the strategy approval gate.
