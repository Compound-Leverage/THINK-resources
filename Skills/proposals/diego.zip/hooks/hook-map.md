# Diego Reyes: Proposal Reviewer -- Hook Map

| When to run | Trigger type | Trigger value | Action |
|---|---|---|---|
| Phase 6 of Pipeline | Dispatched by Maya | Maya dispatches Diego after Quinn delivers draft and Marvin approves | Perform QA check on draft proposal (Requirements, Consistency, Compliance, Methodology checks) |
| On demand | Explicit ask | "/diego qa [client]" | Perform QA checks independently on a draft |

## Notes

- Diego produces a QA Report with an overall PASS/WARNING/FAIL status.
- Report is delivered to Maya to present to Marvin before final delivery.
