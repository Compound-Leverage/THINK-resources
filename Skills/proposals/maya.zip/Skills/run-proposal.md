# Skill: Run Proposal

Full 7-phase proposal workflow from intake to final document. Maya orchestrates; each phase dispatches a specialist DE and gates at human approval before proceeding.

**Trigger:** `/maya run-proposal [client]` or `new proposal [client]`
**Output:** `Agents/maya/proposals/[client-name]/` with all phase artifacts + final document

---

## Phase 1: Intake

On trigger, announce and ask the 8 intake questions defined in `Agents/maya/CLAUDE.md`.

Create proposal folder: `Agents/maya/proposals/[client-name]/inputs/intake.json`

Do not dispatch Chase until Marvin confirms intake information is complete.

---

## Phase 2: Research (Chase)

Dispatch Chase with intake package.

Chase runs all five research tasks in parallel (client, industry, compliance, technology, stakeholder) and delivers Discovery Brief:
- `proposals/[client]/research/discovery_brief.json`
- `proposals/[client]/research/discovery_summary.md`

Report findings to Marvin. Gate: GO / NO-GO / CONDITIONAL GO.

If NO-GO: archive the opportunity folder, log reason, stop.
If GO or CONDITIONAL GO: proceed to Phase 3.

---

## Phase 3: Assessment (Priya)

Dispatch Priya with Chase's Discovery Brief.

Priya classifies deal, maps capabilities, builds ROI model, configures pricing.

Delivers Assessment Package:
- `proposals/[client]/strategy/assessment.json`
- `proposals/[client]/strategy/roi_model.json`
- `proposals/[client]/strategy/pricing_config.json`

Report key findings to Marvin. Gate: APPROVED / REVISE.

If REVISE: feed feedback to Priya, re-run, re-report. If APPROVED: proceed to Phase 4.

---

## Phase 4: Strategy (Porter)

Dispatch Porter with Chase's Discovery Brief + Priya's Assessment Package.

Porter runs competitive analysis, develops win themes, selects case studies.

Delivers Strategy Package:
- `proposals/[client]/strategy/strategy.json`
- `proposals/[client]/strategy/win_themes.md`

Report positioning + themes to Marvin. Gate: APPROVED / REVISE. Also ask: which template? (Government / Commercial / Simple / SOW)

If REVISE: feed feedback to Porter, re-run. If APPROVED: proceed to Phase 5.

---

## Phase 5: Draft (Quinn)

Dispatch Quinn with all packages + selected template.

Quinn drafts all sections, threads win themes, integrates ROI and case studies, writes executive summary last.

Delivers Draft Package:
- `proposals/[client]/drafts/proposal_draft.md`
- `proposals/[client]/drafts/draft_notes.md`

Report draft summary (page count, section status, placeholder list) to Marvin. Gate: PROCEED TO QA / REVISE.

---

## Phase 6: QA (Diego)

Dispatch Diego with Quinn's draft + original requirements + Priya's pricing.

Diego runs all four checks (requirements, consistency, compliance, methodology).

Delivers QA Report:
- `proposals/[client]/review/qa_report.json`
- `proposals/[client]/review/qa_summary.md`

Report QA status to Marvin.
- PASS + Marvin "approved": proceed to Phase 7
- WARNING + Marvin "proceed": proceed to Phase 7 with warnings noted
- FAIL or Marvin "fix": dispatch Quinn for revisions, re-run Diego QA, re-report

---

## Phase 7: Output

Apply brand guidelines from the loaded company profile (`Agents/maya/config/profiles/[company].md`). Format final document. Save to:
- `proposals/[client]/final/proposal_final.md`

Report to Marvin:
```
PROPOSAL COMPLETE
Client: [Name]
File: proposals/[client]/final/proposal_final.md
Due: [Date]

Remaining Tasks:
- Fill placeholders: [list]
- Final proofread
- Export to submission format
- Submit by [deadline]
```

Update Deals Pipeline in Notion with proposal status.

---

## Proposal folder structure

```
Agents/maya/proposals/[client-name]/
  inputs/
    intake.json
  research/
    discovery_brief.json
    discovery_summary.md
  strategy/
    assessment.json
    roi_model.json
    pricing_config.json
    strategy.json
    win_themes.md
  drafts/
    proposal_draft.md
    draft_notes.md
  review/
    qa_report.json
    qa_summary.md
  final/
    proposal_final.md
    checklist.md
```

---

## Quick commands during workflow

| Command | Action |
|---|---|
| `status` | Show current phase and last gate status |
| `go` | Approve Go decision |
| `approved` | Approve current phase |
| `revise [feedback]` | Request revision with specific feedback |
| `pipeline` | Show all active proposals and their phases |
