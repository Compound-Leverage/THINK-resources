# Profile: [Company Name]

---

# Company

```yaml
company:
  name: "[Company Name]"
  legal_name: "[Legal Entity Name]"
  tagline: "[Tagline]"
  website: "[https://...]"

contact:
  email: "[primary@company.com]"
  phone: "[phone]"
  address: "[street, city, state zip]"

leadership:
  - name: "[Name]"
    title: "[Title]"
    bio: "[2-3 sentence bio for proposal signatory]"
```

---

# Brand

```yaml
brand:
  colors:
    primary: "[hex]"
    secondary: "[hex]"
    accent: "[hex]"

  fonts:
    headings: "[Font]"
    body: "[Font]"

  voice:
    tone: "[e.g. Professional but direct, confident not arrogant]"
    perspective: "[e.g. Second person]"
    sentence_length: "[e.g. Max 15 words]"
    reading_level: "[e.g. 6th grade]"

  terminology:
    use:
      - "[preferred term] (not [term to avoid])"
    avoid:
      - "[phrase or word to never use]"

  rules:
    - "[Writing rule 1]"
    - "[Writing rule 2]"
```

---

# Methodology

```yaml
# Describe the frameworks this company uses in proposals.
# Add or remove frameworks as needed.

framework_1:
  name: "[Framework Name]"
  phases:
    "[Phase 1 label]": "[Description]"
    "[Phase 2 label]": "[Description]"

framework_2:
  name: "[Framework Name]"
  dimensions:
    "[Dimension 1]": "[Description]"
    "[Dimension 2]": "[Description]"
```

---

# Pricing Model

```yaml
pricing:
  components:
    - id: "[COMPONENT-ID]"
      name: "[Component Name]"
      base_price: 0
      description: "[What this component delivers]"

  packages:
    - name: "[Package Name]"
      components: ["[COMPONENT-ID]"]
      price: 0
      typical_duration: "[X-Y weeks]"

  success_fee:
    enabled: false
    percentage: 0
    cap: 0
    trigger: "[Condition that triggers success fee]"

  payment:
    - milestone: "[Milestone]"
      percentage: 0
      terms: "Net 30"
```

---

# Deal Types

```yaml
deal_types:
  - id: "[DEAL_TYPE]"
    name: "[Deal Type Name]"
    tone: "[Tone guidance]"
    min_deal_size: 0
    requirements:
      - "[Requirement 1]"
```

---

# Offerings

```yaml
offerings:
  - id: "[OFFERING_ID]"
    name: "[Offering Name]"
    description: "[What it delivers]"
    typical_duration: "[X-Y weeks]"
    price_range: "$X - $Y"
    best_for:
      - "[Use case]"
```

---

# ROI Calculation Defaults

```yaml
roi_defaults:
  hourly_rates:
    executive: 150
    manager: 100
    professional: 75
    administrative: 50
    default: 75

  efficiency_assumptions:
    automation_time_savings: "60-80% of manual time"
    ramp_up_period: "First 2 months at 50% savings"

  guidelines:
    - "Use client's own numbers when possible"
    - "Use lower end of savings estimates"
    - "Round savings down, costs up"
    - "Separate hard savings from soft benefits"
    - "Note all assumptions clearly"
```

---

# Case Studies

```yaml
case_studies:
  - id: "CASE_001"
    client: "[Client name or anonymous descriptor]"
    industry: "[Industry]"
    challenge: "[Core problem]"
    solution: "[What was delivered]"
    outcomes:
      - "[Quantified result]"
    tags: ["[tag1]", "[tag2]"]
```

---

# Differentiators

```yaml
differentiators:
  - name: "[Differentiator Name]"
    message: "[One sentence positioning statement]"
    proof: "[Evidence or proof point]"
```

---

# Competitor Positioning

```yaml
competitors:
  category_name:
    examples: ["[Competitor 1]", "[Competitor 2]"]
    their_strengths: ["[Strength]"]
    their_weaknesses: ["[Weakness]"]
    our_counter: "[How this company wins against them]"
```
