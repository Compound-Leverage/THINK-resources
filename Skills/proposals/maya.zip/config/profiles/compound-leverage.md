# Profile: Compound Leverage

---

# Company

```yaml
company:
  name: "Compound Leverage"
  legal_name: "Compound Leverage LLC"
  tagline: "Digital Employees for Strategic Decisions"
  website: "https://compoundleverage.com"

contact:
  email: "marvin@compoundleverage.com"
  phone: "[UPDATE]"
  address: "[UPDATE]"

leadership:
  - name: "Marvin Harris"
    title: "Principal"
    bio: "[UPDATE]"
```

---

# Brand

```yaml
brand:
  colors:
    primary: "#6944BA"      # THINK Purple
    secondary: "#000000"    # Black
    accent: "#4A4A4A"       # Charcoal Gray

  fonts:
    headings: "Calibri"
    body: "Calibri"

  voice:
    tone: "Professional but direct, confident not arrogant"
    perspective: "Second person - always 'you' and 'your'"
    sentence_length: "Max 15 words"
    reading_level: "6th grade"

  terminology:
    use:
      - "Digital Employee" (not AI, bot, automation)
      - "THINK" (not think, Think)
      - "SPEEDS" (not speeds, Speeds)
      - "Investment" (not cost, fee, price)
      - "Compound Leverage" (not CL)
    avoid:
      - "AI-powered" (use "Digital Employee")
      - "Cutting-edge" or "Revolutionary"
      - "We're excited to..."
      - "Best-in-class"
      - em dashes

  rules:
    - "Lead with the problem, not your solution"
    - "Sell the destination, not the airplane"
    - "Focus on transformation, not technology"
    - "Problem-first, then solution"
    - "Quantify pain before presenting cure"
    - "Never use emojis unless client does first"
```

---

# Methodology

## THINK Framework
```yaml
think:
  phases:
    T: "Task - Frame the decision clearly"
    H: "Hypothesis - Define expected outcome"
    I: "Invest - Allocate resources appropriately"
    N: "Network - Engage right stakeholders"
    K: "Knowledge - Capture and apply learnings"
```

## SPEEDS Framework
```yaml
speeds:
  dimensions:
    S: "Segment - Define target users/processes"
    P: "Problem - Quantify the pain"
    E: "Evaluate - Assess options systematically"
    E: "Execute - Implement with discipline"
    D: "Display - Measure and visualize results"
    S: "Set - Establish governance"
```

---

# Pricing Model

```yaml
pricing:
  components:
    - id: "THINK-METHOD"
      name: "THINK Methodology"
      base_price: 12000
      description: "Framework, governance, measurement discipline"

    - id: "DE-TEAM"
      name: "Digital Employee Fulfillment Team"
      base_price: 15000
      description: "Replaces ~120 hours of human configuration work"
      hours_replaced: 120

    - id: "THINK-HUMAN"
      name: "Human THINK Strategy Team"
      base_price: 23000
      description: "Strategy, decisions, adoption coaching"

    - id: "PM-OUTCOMES"
      name: "Program Management & Outcomes"
      base_price: 15000
      description: "Coordination, accountability, tracking"

  packages:
    - name: "THINK Strategist"
      components: ["THINK-METHOD", "THINK-HUMAN", "PM-OUTCOMES"]
      price: 50000
      typical_duration: "8-12 weeks"

    - name: "METHOD Training"
      components: ["THINK-METHOD", "PM-OUTCOMES"]
      price: 27000
      typical_duration: "4-6 weeks"

    - name: "THINK Implementation"
      components: ["DE-TEAM", "THINK-HUMAN", "PM-OUTCOMES"]
      price: 53000
      typical_duration: "10-14 weeks"

    - name: "Full Package"
      components: ["THINK-METHOD", "DE-TEAM", "THINK-HUMAN", "PM-OUTCOMES"]
      price: 65000
      typical_duration: "12-16 weeks"

  success_fee:
    enabled: true
    percentage: 25
    cap: 60000
    trigger: "Documented Year 1 savings exceed base investment"
    verification: "Joint measurement against established baseline"

  payment:
    - milestone: "Contract Execution"
      percentage: 50
      terms: "Net 30"
    - milestone: "Midpoint (typically Week 8-9)"
      percentage: 25
      terms: "Net 30"
    - milestone: "Engagement Complete"
      percentage: 25
      terms: "Net 30"
    - milestone: "Success Fee"
      percentage: "Per formula"
      terms: "Net 30 from verification"
```

---

# Deal Types

```yaml
deal_types:
  - id: "GOVERNMENT"
    name: "Government RFP"
    template: "government_style"
    tone: "Formal, compliance-focused, section-numbered"
    min_deal_size: 50000
    requirements:
      - "Section numbering matches RFP exactly"
      - "Past performance section required"
      - "Compliance matrix if requested"
      - "Key personnel bios"
      - "Certifications appendix"

  - id: "COMMERCIAL"
    name: "Commercial"
    template: "commercial_style"
    tone: "Professional, outcome-focused, narrative-driven"
    min_deal_size: 25000
    requirements:
      - "Strong ROI analysis"
      - "Flexible structure"
      - "Relevant case studies"
      - "Clear investment section"

  - id: "PARTNERSHIP"
    name: "Partnership / JV"
    template: "partnership_style"
    tone: "Collaborative, mutual benefit emphasis"
    min_deal_size: 0
    requirements:
      - "Shared risk/reward model"
      - "Long-term vision"
      - "Joint success metrics"
      - "Governance structure"

  - id: "ECONOMIC_DEV"
    name: "Economic Development"
    template: "economic_dev_style"
    tone: "Community impact focused"
    min_deal_size: 25000
    requirements:
      - "Job creation metrics"
      - "Local benefit emphasis"
      - "Public value proposition"
```

---

# Offerings

```yaml
offerings:
  - id: "THINK_STRATEGIST"
    name: "THINK Strategist"
    description: "Strategic decision framework implementation"
    typical_duration: "8-12 weeks"
    price_range: "$40,000 - $75,000"
    components: ["THINK-METHOD", "THINK-HUMAN", "PM-OUTCOMES"]
    best_for:
      - "Organizations facing complex decisions"
      - "Leadership alignment challenges"
      - "Strategic planning needs"

  - id: "METHOD_TRAINING"
    name: "METHOD Training Program"
    description: "Team capability building with THINK/SPEEDS"
    typical_duration: "4-8 weeks"
    price_range: "$20,000 - $40,000"
    components: ["THINK-METHOD", "PM-OUTCOMES"]
    best_for:
      - "Teams needing decision frameworks"
      - "Organizations scaling methodology"
      - "Training and enablement focus"

  - id: "THINK_IMPLEMENTATION"
    name: "THINK Implementation"
    description: "Digital Employee deployment with strategic oversight"
    typical_duration: "10-16 weeks"
    price_range: "$45,000 - $100,000"
    components: ["DE-TEAM", "THINK-HUMAN", "PM-OUTCOMES"]
    best_for:
      - "Automation/AI deployment"
      - "Process transformation"
      - "Capability building"

  - id: "COMBINATION"
    name: "Full Engagement"
    description: "Complete THINK + Digital Employee solution"
    typical_duration: "12-20 weeks"
    price_range: "$60,000 - $150,000"
    components: ["THINK-METHOD", "DE-TEAM", "THINK-HUMAN", "PM-OUTCOMES"]
    best_for:
      - "Enterprise transformation"
      - "Multiple capability areas"
      - "Maximum value capture"
```

---

# ROI Calculation Defaults

```yaml
roi_defaults:
  hourly_rates:
    executive: 150
    manager: 100
    professional: 75
    administrative: 50
    default: 75

  efficiency_assumptions:
    automation_time_savings: "60-80% of manual time"
    ramp_up_period: "First 2 months at 50% savings"
    risk_mitigation_value: "50% of exposure"

  guidelines:
    - "Use client's own numbers when possible"
    - "Use lower end of savings estimates"
    - "Round savings down, costs up"
    - "Separate hard savings from soft benefits"
    - "Note all assumptions clearly"
    - "Cite data sources"
```

---

# Case Studies

```yaml
case_studies:
  - id: "CASE_001"
    client: "[PLACEHOLDER - Add real case]"
    industry: "Staffing"
    challenge: "Manual recruiting processes consuming 40+ hours/week"
    solution: "Digital Employee implementation for screening, matching, outreach"
    outcomes:
      - "35% reduction in time-to-fill"
      - "$85,000 annual savings"
      - "4-month ROI payback"
    tags: ["staffing", "recruiting", "automation", "digital-employee"]

  - id: "CASE_002"
    client: "[PLACEHOLDER - Add real case]"
    industry: "Professional Services"
    challenge: "Inconsistent decision-making across leadership team"
    solution: "THINK methodology implementation with coaching"
    outcomes:
      - "60% faster strategic decisions"
      - "Improved alignment across departments"
      - "Framework adopted company-wide"
    tags: ["strategy", "think", "leadership", "decisions"]
```

---

# Differentiators

```yaml
differentiators:
  - name: "Digital Employee Methodology"
    message: "We originated this approach. We don't teach philosophy -- we deploy working systems."
    proof: "Documented methodology, trained practitioners"

  - name: "Integrate, Don't Replace"
    message: "Your systems stay. Digital Employees augment what you've already built."
    proof: "Integration track record, no system replacement required"

  - name: "Speed to Value"
    message: "Results in weeks, not quarters. Pilots before full rollout."
    proof: "Typical pilot in 4-6 weeks, full deployment 10-16 weeks"

  - name: "Human Control"
    message: "AI recommends. Your team approves. Every decision logged."
    proof: "Human-in-the-loop architecture, audit trail, override capability"

  - name: "Outcome-Aligned Investment"
    message: "Success fee means we win when you win. No results, no fee."
    proof: "25% success fee structure, capped at $60K"

  - name: "Hybrid Delivery"
    message: "Digital Employee + Human teams working together."
    proof: "Combined team structure, not pure automation"
```

---

# Competitor Positioning

```yaml
competitors:
  big_consulting:
    examples: ["McKinsey", "Accenture", "Deloitte"]
    their_strengths: ["Brand recognition", "Resources", "Breadth"]
    their_weaknesses: ["Cost", "Speed", "Junior staff doing work"]
    our_counter: "Senior practitioners, faster delivery, outcome-aligned pricing"

  tech_vendors:
    examples: ["Salesforce", "ServiceNow", "UiPath"]
    their_strengths: ["Platform", "Scale", "Features"]
    their_weaknesses: ["Strategy gap", "Implementation complexity", "Vendor lock-in"]
    our_counter: "Strategy-first, vendor-agnostic, focused on outcomes not features"

  boutiques:
    examples: ["Regional consultants", "Solo practitioners"]
    their_strengths: ["Price", "Relationships", "Flexibility"]
    their_weaknesses: ["Scale", "Methodology", "AI capability"]
    our_counter: "Proven methodology, Digital Employee capability, strategic depth"

  diy:
    examples: ["Internal teams", "Build in-house"]
    their_strengths: ["Institutional knowledge", "No external cost"]
    their_weaknesses: ["Speed", "Expertise", "Distraction from core"]
    our_counter: "Faster time to value, proven approach, risk transfer"

  status_quo:
    examples: ["Do nothing", "Wait and see"]
    their_strengths: ["No investment", "No change management"]
    their_weaknesses: ["Competitive pressure", "Cost of inaction", "Falling behind"]
    our_counter: "Quantify cost of inaction, competitive urgency, risk of waiting"
```
