# Profile: Inncuvate

---

# Company

```yaml
company:
  name: "Inncuvate"
  legal_name: "[UPDATE: Legal entity name]"
  tagline: "[UPDATE]"
  website: "[UPDATE]"

contact:
  email: "marvin@inncuvate.com"
  phone: "[UPDATE]"
  address: "[UPDATE]"

leadership:
  - name: "Marvin Harris"
    title: "[UPDATE: Title at Inncuvate]"
    bio: "[UPDATE]"
```

---

# Brand

```yaml
brand:
  colors:
    primary: "[UPDATE: hex]"
    secondary: "[UPDATE: hex]"
    accent: "[UPDATE: hex]"

  fonts:
    headings: "[UPDATE]"
    body: "[UPDATE]"

  voice:
    tone: "[UPDATE]"
    perspective: "Second person - always 'you' and 'your'"
    sentence_length: "Max 15 words"
    reading_level: "6th grade"

  terminology:
    use:
      - "[UPDATE: preferred terms]"
    avoid:
      - "[UPDATE: terms to never use]"

  rules:
    - "Lead with the problem, not your solution"
    - "Quantify pain before presenting cure"
    - "Never use emojis unless client does first"
    - "[UPDATE: any Inncuvate-specific rules]"
```

---

# Methodology

```yaml
# UPDATE: Replace with Inncuvate's actual frameworks
framework_1:
  name: "[UPDATE]"
  phases:
    "[Phase label]": "[Description]"
```

---

# Pricing Model

```yaml
# UPDATE: Replace with Inncuvate's actual pricing
pricing:
  components:
    - id: "[COMPONENT]"
      name: "[UPDATE]"
      base_price: 0
      description: "[UPDATE]"

  packages:
    - name: "[UPDATE]"
      components: ["[COMPONENT]"]
      price: 0
      typical_duration: "[UPDATE]"

  success_fee:
    enabled: false
    percentage: 0
    cap: 0
    trigger: "[UPDATE if applicable]"

  payment:
    - milestone: "Contract Execution"
      percentage: 50
      terms: "Net 30"
    - milestone: "Engagement Complete"
      percentage: 50
      terms: "Net 30"
```

---

# Deal Types

```yaml
# UPDATE: Add Inncuvate's deal types
deal_types:
  - id: "COMMERCIAL"
    name: "Commercial"
    tone: "Professional, outcome-focused"
    min_deal_size: 0
    requirements:
      - "[UPDATE]"
```

---

# Offerings

```yaml
# UPDATE: Replace with Inncuvate's actual offerings
offerings:
  - id: "[OFFERING]"
    name: "[UPDATE]"
    description: "[UPDATE]"
    typical_duration: "[UPDATE]"
    price_range: "[UPDATE]"
    best_for:
      - "[UPDATE]"
```

---

# ROI Calculation Defaults

```yaml
roi_defaults:
  hourly_rates:
    executive: 150
    manager: 100
    professional: 75
    administrative: 50
    default: 75

  efficiency_assumptions:
    automation_time_savings: "60-80% of manual time"
    ramp_up_period: "First 2 months at 50% savings"

  guidelines:
    - "Use client's own numbers when possible"
    - "Use lower end of savings estimates"
    - "Round savings down, costs up"
    - "Separate hard savings from soft benefits"
    - "Note all assumptions clearly"
```

---

# Case Studies

```yaml
# UPDATE: Add Inncuvate case studies
case_studies:
  - id: "CASE_001"
    client: "[UPDATE]"
    industry: "[UPDATE]"
    challenge: "[UPDATE]"
    solution: "[UPDATE]"
    outcomes:
      - "[UPDATE]"
    tags: ["[tag]"]
```

---

# Differentiators

```yaml
# UPDATE: Add Inncuvate's differentiators
differentiators:
  - name: "[UPDATE]"
    message: "[UPDATE]"
    proof: "[UPDATE]"
```

---

# Competitor Positioning

```yaml
# UPDATE: Add Inncuvate's competitive context
competitors:
  category:
    examples: ["[Competitor]"]
    their_strengths: ["[Strength]"]
    their_weaknesses: ["[Weakness]"]
    our_counter: "[UPDATE]"
```
