# Classify Opportunity Agent

## Purpose
Classify the opportunity by deal type and offering type to select the correct template and approach.

## Inputs
- Parsed client data (from parse_input)
- Requirements list
- Client industry and context

## Classification Tasks

### 1. Deal Type Classification

| Deal Type | Indicators | Template | Pages |
|-----------|------------|----------|-------|
| **government_rfp** | Federal/state agency, compliance-heavy, formal RFP process, security requirements | government_style | 20-30 |
| **commercial** | Private company, ROI-focused, faster decision, business impact | non_government_style | 12-15 |
| **partnership** | University, nonprofit, shared mission, experiential learning | partnership | 10-15 |
| **economic_dev** | Workforce board, SBDC, chamber, regional impact | economic_dev | 12-18 |

#### Government RFP Indicators
- Client is federal contractor or government agency
- EEOC, NIST, FedRAMP, CMMC mentioned
- Formal RFP/RFQ process
- Compliance and audit requirements
- Security clearance requirements
- FAR/DFARS references

#### Commercial Indicators
- Private company
- ROI and business case focus
- Faster timeline expectations
- Less formal process
- Cost reduction / efficiency focus

#### Partnership Indicators
- University or nonprofit
- Student involvement / experiential learning
- Shared mission language
- Community impact focus
- MOU rather than contract

#### Economic Dev Indicators
- SBDC, workforce board, chamber
- Regional economic impact
- Workforce development metrics
- Scalability / replication focus
- Grant funding possible

### 2. Offering Type Classification

| Offering Type | Indicators | Components |
|---------------|------------|------------|
| **think_strategist** | Assessment, strategy, roadmap needed | THINK-METHOD, THINK-HUMAN |
| **method_training** | Team enablement, framework adoption | THINK-METHOD, training hours |
| **implementation** | Build and deploy Digital Employees | All 4 products |
| **combination** | Multiple needs | Custom mix |

#### THINK Strategist Indicators
- "We need to understand our options"
- "Help us develop a strategy"
- "Assessment" or "roadmap" language
- Early stage, not ready to build

#### METHOD Training Indicators
- "Train our team"
- "Adopt the framework"
- "Build internal capability"
- Enablement focus

#### Implementation Indicators
- "Build this for us"
- "Automate this process"
- Specific problem to solve
- Ready to execute
- Digital Employee deployment

#### Combination Indicators
- Multiple needs expressed
- Phased approach discussed
- Training + implementation
- Strategy + execution

### 3. Confidence Scoring

Rate confidence for each classification:
- **High (>80%)**: Clear indicators, unambiguous
- **Medium (50-80%)**: Some indicators, could go either way
- **Low (<50%)**: Unclear, need more information

## Output Format
```json
{
  "deal_type": {
    "classification": "government_rfp | commercial | partnership | economic_dev",
    "confidence": "high | medium | low",
    "indicators": [],
    "alternative": null
  },
  "offering_type": {
    "classification": "think_strategist | method_training | implementation | combination",
    "confidence": "high | medium | low",
    "indicators": [],
    "components": []
  },
  "template_selected": "government_style | non_government_style | partnership | economic_dev",
  "page_target": {
    "min": 0,
    "max": 0
  },
  "sections_required": [],
  "compliance_sections_needed": true | false,
  "speeds_scorecard_needed": true | false,
  "classification_notes": ""
}
```

## Decision Rules

### If Uncertain on Deal Type
1. Default to more formal (government_rfp > commercial)
2. Ask user to clarify
3. Note uncertainty in classification_notes

### If Uncertain on Offering Type
1. Default to implementation (most common)
2. Ask user to clarify
3. Can always add components later

### Mixed Signals
- Government contractor but simple project → commercial template with compliance sections
- Nonprofit but formal RFP → government_rfp template with partnership tone
- Note hybrid approach in classification_notes
