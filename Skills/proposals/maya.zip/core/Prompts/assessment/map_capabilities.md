# Map Capabilities Agent

## Purpose
Map client requirements to company capabilities and identify positioning strategy.

## Inputs
- Parsed requirements (from parse_input)
- Client pain points
- Company profile (company_profile.json)
- Pricing model (pricing_model.json)

## Mapping Tasks

### 1. Requirement → Capability Mapping

For each requirement:
1. Identify which company capability addresses it
2. Rate fit: strong, moderate, weak, gap
3. Identify which proposal section will address it
4. Note any caveats or conditions

### 2. Pain Point → Solution Mapping

For each pain point:
1. Identify which offering component solves it
2. Quantify the solution impact
3. Identify proof points (case studies, metrics)

### 3. Gap Analysis

Identify:
- Requirements we can't fully address
- Capabilities needed but not in our portfolio
- Partner or subcontractor needs
- Risk areas requiring mitigation

### 4. Positioning Strategy

Based on mappings, determine:
- Lead message (what to emphasize first)
- Differentiators to highlight
- Competitive positioning
- Objections to preemptively address

## Capability Categories

### THINK Methodology
- Strategic decision-making frameworks
- Governance and measurement discipline
- Process documentation
- Best fit for: strategy, assessment, roadmap requirements

### Digital Employee Fulfillment Team
- AI-powered automation
- Manual task replacement
- Process automation
- Best fit for: automation, efficiency, time savings requirements

### Human THINK Strategy Team
- Strategic guidance
- Decision support
- Adoption coaching
- Change management
- Best fit for: complex decisions, organizational change requirements

### Program Management
- Project coordination
- Accountability tracking
- Outcome measurement
- Best fit for: execution oversight, reporting requirements

## Output Format
```json
{
  "requirement_mapping": [
    {
      "requirement_id": "R1",
      "requirement": "",
      "capability": "",
      "fit": "strong | moderate | weak | gap",
      "proposal_section": "",
      "notes": ""
    }
  ],
  "pain_point_mapping": [
    {
      "pain_point": "",
      "solution_component": "",
      "quantified_impact": "",
      "proof_points": []
    }
  ],
  "gaps": [
    {
      "gap": "",
      "mitigation": "",
      "risk_level": "low | medium | high"
    }
  ],
  "positioning_strategy": {
    "lead_with": "",
    "secondary_emphasis": "",
    "differentiators": [],
    "competitive_positioning": "",
    "objections_to_address": [
      {"objection": "", "response": ""}
    ]
  },
  "overall_fit": {
    "score": 0,
    "assessment": "strong | moderate | weak",
    "go_no_go_recommendation": "go | conditional | no_go",
    "conditions": []
  },
  "pricing_components_needed": [],
  "case_studies_to_use": [],
  "personnel_to_feature": []
}
```

## Fit Scoring

### Strong Fit (8-10)
- Direct capability match
- Proven past performance
- Clear differentiator

### Moderate Fit (5-7)
- Capability exists but not exact match
- Similar past performance
- Can address with some adaptation

### Weak Fit (3-4)
- Partial capability
- Limited experience
- Requires significant adaptation

### Gap (0-2)
- No capability
- Need partner or pass
- High risk area

## Go/No-Go Criteria

### Go
- Overall fit score 7+
- No critical gaps
- Clear path to win

### Conditional Go
- Overall fit score 5-7
- Gaps can be mitigated
- Requires specific conditions

### No-Go
- Overall fit score <5
- Critical gaps without mitigation
- Low probability of win
