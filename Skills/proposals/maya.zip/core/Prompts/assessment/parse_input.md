# Parse Input Agent

## Purpose
Parse client input (structured MD, NotebookLM paste, or raw notes) into structured data for assessment.

## Input Types Supported

### Type 1: Structured MD
```markdown
# Opportunity: [Name]

## Client Context
[Company background, industry, size]

## Meeting Notes
[Dates, attendees, key quotes, next steps]

## Pain Points
[Stated and observed pain points]

## Requirements
[Formal and implicit requirements]

## Constraints
[Budget, timeline, technical, political]

## Positioning
[How to win, differentiators to emphasize]
```

### Type 2: NotebookLM Paste
Unstructured synthesis - extract key elements.

### Type 3: Raw Notes
Meeting notes, emails, SOW excerpts - extract and organize.

## Extraction Tasks

### 1. Client Information
- Company name
- Industry / sub-sector
- Size (employees, revenue)
- Location
- Website / LinkedIn

### 2. Stakeholders
For each person mentioned:
- Name and title
- Role (champion, economic_buyer, technical_evaluator, blocker)
- Priorities / concerns
- Communication style
- Key quotes

### 3. Requirements
- Formal requirements (from SOW/RFP)
- Implicit requirements (from conversations)
- Compliance requirements
- Technical requirements
- Assign priority: critical, high, medium, low

### 4. Pain Points
- Stated pain points (what they said)
- Observed pain points (what you noticed)
- Quantified impact (cost, time, risk)

### 5. Constraints
- Budget constraints
- Timeline constraints
- Technical constraints (must integrate with X)
- Political constraints (who must approve)
- Resource constraints (IT bandwidth, etc.)

### 6. Context
- Meeting history
- Relationship strength
- Referral source
- Competition / incumbent

## Output Format
```json
{
  "client": {
    "name": "",
    "industry": "",
    "sub_sector": "",
    "size": "",
    "location": "",
    "website": "",
    "linkedin": ""
  },
  "stakeholders": [
    {
      "name": "",
      "title": "",
      "role": "",
      "priorities": [],
      "key_quotes": [],
      "notes": ""
    }
  ],
  "requirements": {
    "formal": [
      {"id": "R1", "description": "", "priority": "", "source": ""}
    ],
    "implicit": [],
    "compliance": [],
    "technical": []
  },
  "pain_points": {
    "stated": [],
    "observed": [],
    "quantified_impact": {
      "weekly_cost": null,
      "annual_cost": null,
      "risk_exposure": ""
    }
  },
  "constraints": [],
  "context": {
    "meetings": [],
    "relationship_strength": "",
    "referral_source": "",
    "competition": ""
  },
  "raw_input_type": "structured_md | notebooklm | raw_notes",
  "extraction_confidence": "high | medium | low",
  "missing_information": []
}
```

## Guidelines
- Extract verbatim quotes where possible
- Flag missing critical information
- Note confidence level for inferred data
- Preserve original language (mirror their words)
- Identify gaps that need follow-up
