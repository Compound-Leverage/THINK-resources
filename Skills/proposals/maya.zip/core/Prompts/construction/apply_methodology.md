# Apply Methodology Agent

## Purpose
Integrate THINK, SPEEDS, and THINK Layer methodology into proposal sections where appropriate.

## When to Apply Each Framework

### THINK Framework
**Use in sections:** 2.2 Solution Overview, 3.4 Methodology

**Apply when:**
- Explaining our approach
- Showing strategic thinking process
- Justifying recommendations
- Demonstrating rigor

**How to integrate:**
```markdown
Our approach follows the THINK framework:

**Task**: We identified [specific bottleneck] consuming [X hours/week]
**Hypothesis**: We evaluated [3 options] for automation
**Invest**: Using SPEEDS scoring, Option [X] scored highest at [X/10]
**Network**: This solution can expand to [other use cases]
**Knowledge**: We'll document patterns for continuous improvement
```

### SPEEDS Framework
**Use in sections:** 2.2 Solution Overview, Appendix (Scorecard)

**Apply when:**
- Technical/implementation proposals
- Architecture decisions
- Justifying solution selection
- Demonstrating evaluation rigor

**How to integrate:**
```markdown
We evaluated this architecture using SPEEDS scoring:

| Dimension | Score | Rationale |
|-----------|-------|-----------|
| Segment   | 8/10  | [Brief rationale] |
| Problem   | 9/10  | [Brief rationale] |
| Evaluate  | 8/10  | [Brief rationale] |
| Execute   | 8/10  | [Brief rationale] |
| Display   | 7/10  | [Brief rationale] |
| Set       | 8/10  | [Brief rationale] |
| **Total** | **8.0/10** | **Strongly Recommended** |
```

### THINK Layer
**Use in sections:** 1.1 Executive Summary, 3.5 Risk Mitigation

**Apply when:**
- Synthesizing findings
- Adding business context
- Explaining trade-offs
- Managing risk perception

**How to integrate:**
```markdown
**Strategic Context:**
While [technical option A] scored marginally higher, we recommend
[option B] because [business reality]. This trade-off accepts
[what we lose] in exchange for [what we gain], with [contingency]
if assumptions prove incorrect.
```

## Section-Specific Integration

### Executive Summary (1.1)
- THINK Layer synthesis for positioning
- Quantified problem (Task phase insight)
- Solution confidence (SPEEDS total score reference)

### Solution Overview (2.2)
- Full THINK framework walkthrough
- Reference SPEEDS evaluation
- Show methodology rigor

### Methodology (3.4)
- Explain THINK framework
- How it applies to this engagement
- Why this approach works

### Risk Mitigation (3.5)
- THINK Layer risk assessment
- Trade-off acknowledgment
- Contingency planning

### Appendix - SPEEDS Scorecard
- Full scorecard with all 6 dimensions
- Detailed rationale for each score
- Recommendation summary

## Integration Levels

### Light Touch
- Brief framework reference
- No detailed explanation
- Use for: Executive Summary, shorter sections

### Moderate Integration
- Framework overview
- Key scores/findings
- Use for: Solution Overview, Methodology

### Deep Integration
- Full framework application
- Detailed scoring and rationale
- Use for: Appendix, technical sections

## Output Format

For each section, note:
```json
{
  "section_id": "",
  "methodology_applied": {
    "think_framework": {
      "applied": true | false,
      "integration_level": "light | moderate | deep",
      "phases_referenced": []
    },
    "speeds_framework": {
      "applied": true | false,
      "integration_level": "light | moderate | deep",
      "scorecard_included": true | false
    },
    "think_layer": {
      "applied": true | false,
      "elements_used": []
    }
  }
}
```

## Guidelines

### Do
- Integrate naturally, not forced
- Use methodology to strengthen arguments
- Show rigor without overwhelming
- Reference frameworks by name (builds brand)

### Don't
- Force methodology where irrelevant
- Over-explain frameworks to technical audience
- Use methodology as filler
- Contradict methodology principles
