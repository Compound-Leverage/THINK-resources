# Calculate ROI Agent

## Purpose
Generate accurate, defensible ROI calculations for the Investment and ROI sections.

## Inputs
- Client pain points with quantified impact
- Pricing model (pricing_model.json)
- Engagement scope (from outline)
- Success metrics targets

## ROI Calculation Framework

### Step 1: Establish Baseline Costs

#### Labor Cost Baseline
```
Current weekly cost = [Hours/week] × [People] × [Hourly rate]
Current annual cost = Weekly cost × 52
```

Example:
```
15 hrs/week × 3 recruiters × $75/hr = $3,375/week
$3,375 × 52 = $175,500/year
```

#### Opportunity Cost (Optional)
```
Hours freed × Value of redirected work
```

#### Risk Cost (Optional)
```
Probability of risk × Impact of risk
Example: 20% chance of $500K EEOC penalty = $100K risk exposure
```

### Step 2: Calculate Expected Savings

#### Hours Replaced by Digital Employees
```
DE hours replaced = [From deliverable_mapping]
Typical: 120 hours over engagement
Ongoing: [X] hours/month after implementation
```

#### Efficiency Gains
```
Time reduction = [Current time] - [Expected time]
Value = Time reduction × [Hourly rate] × [Frequency]
```

#### Quality Improvements
```
Error reduction value = [Current error rate] - [Expected error rate] × [Cost per error]
```

### Step 3: Calculate Investment Recovery

#### Month-by-Month Model
```
Month 0: -$65,000 (base investment)
Month 1: -$65,000 + $X,XXX (first month savings) = -$XX,XXX
Month 2: Previous + $X,XXX = -$XX,XXX
Month 3: Previous + $X,XXX = $0 (BREAK-EVEN)
Month 6: +$XX,XXX (cumulative positive)
Month 12: +$XXX,XXX (Year 1 total)
```

#### Break-Even Calculation
```
Break-even month = Base investment / Monthly savings
Example: $65,000 / $22,000 = 2.95 months ≈ Month 3
```

### Step 4: Calculate Year 1 Value

```
Year 1 Gross Savings = Monthly savings × 12
Year 1 Net Value = Gross Savings - Base Investment
ROI % = (Net Value / Base Investment) × 100
```

Example:
```
Year 1 Gross Savings: $264,000
Base Investment: $65,000
Year 1 Net Value: $199,000
ROI: 306%
```

### Step 5: Success Fee Calculation

```
If Year 1 Savings > threshold:
  Success Fee = Savings × 25% (capped at $60,000)

Total Investment = Base + Success Fee
Total Value = Savings - Total Investment
```

## Output Format

### For Section 5.3 ROI Analysis
```markdown
## 5.3 Return on Investment (ROI) Analysis

### Baseline
Your current process costs approximately **$[X]** annually:
- [X] hours/week across [X] team members
- At $[X]/hour blended rate
- Plus risk exposure of $[X] from [risk factor]

### Expected Savings
Our solution will deliver approximately **$[X]** in Year 1 savings:
- **[X] hours freed** per week from [specific task]
- **[X]% reduction** in [metric]
- **[X]** eliminated risk exposure

### Investment Recovery

| Month | Investment | Cumulative Savings | Net Position |
|-------|------------|-------------------|--------------|
| 0 | -$65,000 | $0 | -$65,000 |
| 1 | $0 | $22,000 | -$43,000 |
| 2 | $0 | $44,000 | -$21,000 |
| 3 | $0 | $66,000 | **$1,000** |
| 6 | $0 | $132,000 | $67,000 |
| 12 | $0 | $264,000 | $199,000 |

**Break-even: Month 3**

### Summary
| Metric | Value |
|--------|-------|
| Base Investment | $65,000 |
| Year 1 Savings | $264,000 |
| Year 1 Net Value | $199,000 |
| ROI | 306% |
| Payback Period | 3 months |
```

### ROI Calculation JSON
```json
{
  "baseline": {
    "weekly_hours": 0,
    "people_count": 0,
    "hourly_rate": 0,
    "weekly_cost": 0,
    "annual_cost": 0,
    "risk_exposure": 0
  },
  "expected_savings": {
    "hours_freed_weekly": 0,
    "efficiency_gain_percent": 0,
    "monthly_savings": 0,
    "annual_savings": 0,
    "risk_eliminated": 0
  },
  "investment": {
    "base": 65000,
    "success_fee_potential": 0,
    "total_range_min": 65000,
    "total_range_max": 125000
  },
  "returns": {
    "break_even_month": 0,
    "year_1_net_value": 0,
    "roi_percent": 0,
    "payback_months": 0
  },
  "monthly_projection": [
    {"month": 0, "investment": -65000, "savings": 0, "net": -65000},
    {"month": 1, "investment": 0, "savings": 0, "net": 0}
  ]
}
```

## Guidelines

### Be Conservative
- Use lower end of ranges
- Round savings down
- Round costs up
- Better to exceed than disappoint

### Be Specific
- Show your math
- Cite data sources
- Use their numbers when possible
- Avoid vague multipliers

### Be Defensible
- Only include quantifiable benefits
- Separate hard savings from soft benefits
- Note assumptions clearly
- Provide ranges for uncertain values

### Common Mistakes
- Overstating savings
- Ignoring implementation dip
- Double-counting benefits
- Mixing gross and net figures
- Inconsistent numbers across sections
