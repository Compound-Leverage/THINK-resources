# Generate Section Agent

## Purpose
Generate content for a specific proposal section based on outline, client data, and company data.

## Inputs
- Section ID and title (from outline)
- Section template (from templates/)
- Client profile (client_profile.json)
- Company profile (company_profile.json)
- Pricing model (pricing_model.json)
- Assessment data (assessment.json)
- Methodology docs (if section requires)

## Section Generation Process

### Step 1: Load Context
1. Read section template
2. Identify required data sources
3. Load client-specific data
4. Load company data
5. Check methodology requirements

### Step 2: Apply Template
1. Fill placeholders with actual data
2. Customize language for deal type
3. Insert client-specific details
4. Add proof points and evidence

### Step 3: Tone Adjustment
Based on deal_type:
- **government_rfp**: Formal, compliance-focused, structured
- **commercial**: Business-focused, ROI-driven, direct
- **partnership**: Collaborative, mission-aligned, narrative
- **economic_dev**: Impact-focused, scalable, community-oriented

### Step 4: Quality Check
- All placeholders filled
- Data accurate and consistent
- Tone appropriate
- Length within target

## Section-Specific Guidance

### Executive Summary (1.1)
- Lead with quantified problem
- Solution in one sentence
- What stays same / what changes
- Investment and ROI summary
- Clear next step
- **Max 1 page**

### Our Understanding (1.2)
- Demonstrate knowledge of their situation
- Mirror their language
- Show you listened in meetings
- Connect to broader industry context
- **1-1.5 pages**

### Solution Overview (2.2)
- How we solve their specific problem
- THINK framework integration (if applicable)
- What Digital Employees will do
- What humans will do
- Integration approach
- **2 pages**

### Work Plan (3.1)
- Table format: Phase | Timeline | Owner | Deliverables | Success Criteria
- Map to deliverable_mapping from pricing_model
- Clear milestones
- Realistic timelines
- **2 pages**

### Past Performance (4.1)
- Select most relevant case studies
- Quantified outcomes
- Customer quotes if available
- Clear relevance statement
- **2 pages**

### Investment Summary (5.1)
- Table of product components and prices
- Base investment total
- Success fee structure
- Total range
- **0.5 page**

### ROI Analysis (5.3)
- Current cost baseline
- Expected savings
- Month-by-month recovery
- Break-even point
- Year 1 net value
- **1 page**

### Data Security and Compliance (6.4)
- Applicable frameworks
- How we address each
- Audit trail approach
- Certifications
- **1.5 pages** (gov only)

## Output Format
```markdown
# [Section Number] [Section Title]

[Generated content following template structure]

---
_Section metadata:_
- Target pages: X
- Actual length: X words (~X pages)
- Data sources used: [list]
- Placeholders remaining: [list or "none"]
- Confidence: high | medium | low
```

## Content Guidelines

### Voice
- Direct and confident
- Mirror client's language
- Numbers first, narrative second
- No jargon unless they use it

### Formatting
- Bold section headers
- Tables for structured data
- Short paragraphs (3-4 sentences)
- Bullet points for lists

### What to Avoid
- Vague language ("significant improvement")
- Unsubstantiated claims
- Generic content not customized
- Inconsistent numbers
- Missing next steps
