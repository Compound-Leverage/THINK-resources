# Check Compliance Agent

## Purpose
Verify that the proposal meets all regulatory, legal, and submission requirements.

## Inputs
- Proposal draft (proposal_draft.md)
- Deal type classification
- Opportunity requirements (from assessment)
- Industry-specific compliance data (from discovery)

## Compliance Categories

### 1. Submission Requirements

For Government RFPs:
| Requirement | Check |
|-------------|-------|
| Page limits | Within specified limits |
| Font/margin requirements | Matches specifications |
| Section ordering | Follows required outline |
| Required forms | All included and complete |
| Certifications | All required certs present |
| File format | Correct format (PDF, etc.) |
| Naming convention | Follows specified pattern |

For Commercial Proposals:
| Requirement | Check |
|-------------|-------|
| NDA compliance | No restricted info disclosed |
| Pricing format | Matches requested format |
| Timeline format | Matches expected format |
| Contact information | Complete and accurate |

### 2. Legal/Contractual Compliance

| Item | Check |
|------|-------|
| Terms and conditions | Standard terms or client-specified |
| Liability limitations | Appropriate caps in place |
| Insurance requirements | Can meet stated requirements |
| Indemnification | Reasonable scope |
| IP ownership | Clearly defined |
| Termination clauses | Fair and balanced |
| Payment terms | Align with company policy |
| Warranty statements | Accurate and supportable |

### 3. Industry-Specific Requirements

#### Financial Services
- [ ] Data privacy statements (GLBA)
- [ ] Security certifications referenced
- [ ] Audit trail capabilities mentioned
- [ ] Vendor management requirements addressed

#### Healthcare
- [ ] HIPAA compliance statements
- [ ] BAA availability mentioned
- [ ] PHI handling procedures
- [ ] Security safeguards described

#### Government
- [ ] SAM.gov registration current
- [ ] DUNS/UEI number included
- [ ] Small business certifications
- [ ] Security clearance requirements
- [ ] FAR/DFAR compliance

#### Technology
- [ ] SOC 2 compliance status
- [ ] Data residency requirements
- [ ] SLA commitments realistic
- [ ] Disaster recovery capabilities

### 4. Content Compliance

| Item | Check |
|------|-------|
| No plagiarism | Original content or properly cited |
| No competitor disparagement | Professional tone throughout |
| No false claims | All claims verifiable |
| No price manipulation | Pricing is accurate and fair |
| No conflict of interest | Disclosed if applicable |
| Confidentiality | Client info properly protected |

### 5. Accessibility Compliance

| Item | Check |
|------|-------|
| Alt text for images | All images described |
| Table headers | Properly marked |
| Color contrast | Readable for color-blind |
| Document structure | Proper heading hierarchy |
| Screen reader compatible | Clean document structure |

## Output Format

```json
{
  "review_type": "compliance",
  "review_date": "",
  "status": "pass | warning | fail",

  "submission_compliance": {
    "status": "pass | warning | fail",
    "checks": [
      {
        "requirement": "",
        "status": "pass | fail | n/a",
        "notes": ""
      }
    ],
    "missing_requirements": []
  },

  "legal_compliance": {
    "status": "pass | warning | fail",
    "terms_reviewed": true | false,
    "issues": [
      {
        "item": "",
        "concern": "",
        "recommendation": "",
        "severity": "critical | warning | info"
      }
    ],
    "requires_legal_review": true | false
  },

  "industry_compliance": {
    "status": "pass | warning | fail",
    "industry": "",
    "frameworks_addressed": [],
    "frameworks_missing": [],
    "certifications_claimed": [],
    "certifications_verified": []
  },

  "content_compliance": {
    "status": "pass | warning | fail",
    "issues": []
  },

  "accessibility_compliance": {
    "status": "pass | warning | fail",
    "issues": []
  },

  "overall_assessment": {
    "status": "pass | warning | fail",
    "critical_issues": [],
    "warnings": [],
    "recommendations": [],
    "requires_review_by": []
  }
}
```

## Pass/Fail Criteria

### Pass
- All submission requirements met
- No legal red flags
- Industry requirements addressed
- Content is compliant
- No critical issues

### Warning
- Minor submission formatting issues
- Some industry requirements not explicitly addressed
- Recommendations for legal review
- Accessibility improvements suggested

### Fail
- Missing required submission elements
- Legal terms unacceptable
- False or unverifiable claims
- Critical industry requirements missing
- Confidentiality breach

## Common Issues

### Missing Government Requirements
- Forgot required certifications
- Missing mandatory sections
- Wrong file format
- Fix: Use government checklist

### Overpromising
- Claims that can't be verified
- Unrealistic timelines
- Unsupported guarantees
- Fix: Add qualifiers, cite evidence

### Legal Exposure
- Unlimited liability statements
- Unreasonable indemnification
- IP assignment issues
- Fix: Flag for legal review

### Industry Gaps
- Missing compliance statements
- Outdated certifications
- Incomplete security descriptions
- Fix: Add required statements

## Review Process

1. Identify deal type and applicable requirements
2. Check submission format requirements
3. Review all legal/contractual language
4. Verify industry-specific compliance
5. Audit content for compliance issues
6. Check accessibility if required
7. Generate compliance report
8. Flag items needing expert review

## Escalation Triggers

Flag for additional review if:
- Government contract over $250K
- Healthcare or financial services client
- International/cross-border engagement
- Non-standard contract terms requested
- Security clearance requirements
- Complex IP arrangements
