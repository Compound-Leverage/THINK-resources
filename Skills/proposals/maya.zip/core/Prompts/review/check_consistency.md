# Check Consistency Agent

## Purpose
Verify that numbers, timelines, and facts are consistent across all proposal sections.

## Inputs
- Proposal draft (proposal_draft.md)
- Pricing model (pricing_model.json)
- Assessment data (assessment.json)

## Consistency Checks

### 1. Investment Figures

Check these values match across sections:
- Executive Summary (1.1)
- Transmittal Letter
- Investment Summary (5.1)
- Investment Details (5.2)
- ROI Analysis (5.3)

| Value | Check |
|-------|-------|
| Base investment | Same dollar amount everywhere |
| Success fee percentage | Same percentage everywhere |
| Success fee cap | Same cap everywhere |
| Total range | Same min-max everywhere |

### 2. Timeline Figures

Check these values match across sections:
- Executive Summary (1.1)
- Work Plan (3.1)
- Timeline (3.2)
- Investment Summary (5.1)

| Value | Check |
|-------|-------|
| Total duration | Same weeks/months everywhere |
| Phase durations | Add up to total |
| Key milestones | Consistent dates/weeks |
| Start/end dates | Aligned across sections |

### 3. ROI Figures

Check these values are mathematically correct and consistent:
- Executive Summary (1.1)
- ROI Analysis (5.3)

| Value | Check |
|-------|-------|
| Baseline cost | Calculation correct |
| Expected savings | Matches assumptions |
| Break-even month | Math checks out |
| Year 1 value | Consistent with breakdown |
| ROI percentage | Calculated correctly |

### 4. Team/Resource Figures

Check consistency in:
- Personnel Matrix (4.2)
- Key Personnel Profiles (7.1)
- Resource Requirements (6.3)

| Value | Check |
|-------|-------|
| Team size | Same count everywhere |
| Roles | Same titles/descriptions |
| Hours | Add up correctly |

### 5. Scope Figures

Check consistency in:
- Our Understanding (1.2)
- Solution Overview (2.2)
- Work Plan (3.1)

| Value | Check |
|-------|-------|
| Deliverables count | Same everywhere |
| Phases | Same names/descriptions |
| Scope items | Consistent list |

## Output Format

```json
{
  "review_type": "consistency",
  "review_date": "",
  "status": "pass | warning | fail",

  "checks": {
    "investment_figures": {
      "status": "pass | warning | fail",
      "base_investment": {
        "consistent": true | false,
        "values_found": [
          {"section": "", "value": ""}
        ],
        "discrepancy": ""
      },
      "success_fee": {
        "consistent": true | false,
        "values_found": [],
        "discrepancy": ""
      },
      "total_range": {
        "consistent": true | false,
        "values_found": [],
        "discrepancy": ""
      }
    },

    "timeline_figures": {
      "status": "pass | warning | fail",
      "total_duration": {
        "consistent": true | false,
        "values_found": [],
        "discrepancy": ""
      },
      "phases_add_up": true | false,
      "milestones_aligned": true | false
    },

    "roi_figures": {
      "status": "pass | warning | fail",
      "calculations_correct": true | false,
      "values_consistent": true | false,
      "issues": []
    },

    "team_figures": {
      "status": "pass | warning | fail",
      "consistent": true | false,
      "issues": []
    },

    "scope_figures": {
      "status": "pass | warning | fail",
      "consistent": true | false,
      "issues": []
    }
  },

  "discrepancies": [
    {
      "type": "",
      "description": "",
      "locations": [],
      "values": [],
      "severity": "critical | warning",
      "recommended_fix": ""
    }
  ],

  "math_errors": [
    {
      "location": "",
      "calculation": "",
      "expected": "",
      "found": "",
      "fix": ""
    }
  ]
}
```

## Pass/Fail Criteria

### Pass
- All investment figures consistent
- All timeline figures consistent
- All ROI calculations correct
- No math errors
- No discrepancies

### Warning
- Minor rounding differences (< $1,000)
- Timeline off by 1 week
- Non-critical inconsistency

### Fail
- Investment figures don't match
- Timeline figures contradict
- ROI math is wrong
- Critical discrepancies

## Common Issues

### Rounding Inconsistency
- $65,000 in one place, $65K in another
- Fix: Use same format throughout

### Stale Numbers
- Updated in one section, not others
- Fix: Global find/replace

### Math Errors
- Percentages don't calculate correctly
- Fix: Recalculate and verify

### Copy/Paste Errors
- Wrong project name or numbers from template
- Fix: Search for template placeholders

## Verification Process

1. Extract all numerical values from proposal
2. Group by category (investment, timeline, ROI, etc.)
3. Compare values within each group
4. Verify calculations are correct
5. Flag any discrepancies
6. Provide specific fix recommendations
