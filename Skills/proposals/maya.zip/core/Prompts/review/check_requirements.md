# Check Requirements Agent

## Purpose
Verify that every requirement from the SOW/RFP is addressed in the proposal.

## Inputs
- Assessment.json (requirements list)
- Proposal draft (proposal_draft.md)
- Outline.json (requirement-to-section mapping)

## Review Tasks

### 1. Requirements Traceability

For each requirement in assessment.json:
1. Locate where it's addressed in the proposal
2. Verify the response is substantive (not just mentioned)
3. Check if response fully addresses the requirement
4. Note section number and page

### 2. Coverage Assessment

| Coverage Level | Definition |
|----------------|------------|
| **Full** | Requirement completely addressed with specifics |
| **Partial** | Requirement mentioned but not fully addressed |
| **Indirect** | Related content but not direct response |
| **Missing** | Requirement not addressed |

### 3. Response Quality

For each addressed requirement:
- Is the response specific to their situation?
- Does it include evidence/proof points?
- Is it clearly connected to the requirement?
- Would an evaluator find it satisfactory?

## Output Format

```json
{
  "review_type": "requirements_coverage",
  "review_date": "",
  "status": "pass | warning | fail",

  "summary": {
    "total_requirements": 0,
    "fully_addressed": 0,
    "partially_addressed": 0,
    "missing": 0
  },

  "traceability_matrix": [
    {
      "requirement_id": "R1",
      "requirement": "",
      "priority": "critical | high | medium | low",
      "section_addressed": "",
      "page_number": 0,
      "coverage": "full | partial | indirect | missing",
      "response_quality": "strong | adequate | weak | missing",
      "notes": ""
    }
  ],

  "issues": [
    {
      "requirement_id": "",
      "issue": "",
      "severity": "critical | warning",
      "recommended_fix": ""
    }
  ],

  "pass_criteria": {
    "all_critical_addressed": true | false,
    "all_high_addressed": true | false,
    "coverage_percentage": 0,
    "minimum_met": true | false
  }
}
```

## Pass/Fail Criteria

### Pass
- All critical requirements fully addressed
- All high priority requirements at least partially addressed
- Overall coverage ≥ 90%
- No missing requirements

### Warning
- All critical requirements addressed (partial OK)
- 1-2 high priority requirements partial/indirect
- Overall coverage 75-89%
- Minor gaps identified

### Fail
- Any critical requirement missing or indirect
- Multiple high priority requirements missing
- Overall coverage < 75%
- Significant gaps that would hurt evaluation

## Common Issues

### Missing Response
- Requirement not mentioned anywhere
- Fix: Add dedicated content addressing requirement

### Weak Response
- Requirement mentioned but not substantively addressed
- Fix: Expand with specifics, evidence, proof points

### Buried Response
- Requirement addressed but hard to find
- Fix: Make more prominent, add to relevant section header

### Generic Response
- Response doesn't connect to their specific requirement
- Fix: Customize with their language, context, specifics

## Review Checklist

- [ ] All critical requirements have full coverage
- [ ] All high priority requirements addressed
- [ ] Medium/low requirements at least mentioned
- [ ] Responses are specific, not generic
- [ ] Evidence/proof points included
- [ ] Easy for evaluator to find responses
- [ ] Compliance requirements have dedicated sections
