#!/usr/bin/env python3
"""
Convert markdown proposal to branded Word document

Brand Guidelines Applied:
- THINK Purple: #6944BA (headlines, key stats, CTAs)
- Black: #000000 (body text)
- Charcoal Gray: #4A4A4A (secondary text)
- Font: Inter/Calibri (sans-serif)
- Generous whitespace, premium feel
"""

import re
import sys
import os
from docx import Document
from docx.shared import Inches, Pt, RGBColor, Twips
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

# Brand Colors
THINK_PURPLE = RGBColor(0x69, 0x44, 0xBA)  # #6944BA
BLACK = RGBColor(0x00, 0x00, 0x00)  # #000000
CHARCOAL = RGBColor(0x4A, 0x4A, 0x4A)  # #4A4A4A
LIGHT_GRAY = RGBColor(0xE8, 0xE8, 0xE8)  # #E8E8E8
WHITE = RGBColor(0xFF, 0xFF, 0xFF)  # #FFFFFF

# Typography
FONT_NAME = 'Calibri'  # Fallback from Inter
HEADING_FONT = 'Calibri'


def read_markdown(filepath):
    """Read markdown file content"""
    with open(filepath, 'r', encoding='utf-8') as f:
        return f.read()


def set_cell_shading(cell, color_hex):
    """Set cell background color"""
    shading_elm = OxmlElement('w:shd')
    shading_elm.set(qn('w:fill'), color_hex)
    cell._tc.get_or_add_tcPr().append(shading_elm)


def setup_styles(doc):
    """Configure document styles with brand guidelines"""

    # Normal style - body text
    style = doc.styles['Normal']
    font = style.font
    font.name = FONT_NAME
    font.size = Pt(11)
    font.color.rgb = BLACK

    # Paragraph formatting
    pf = style.paragraph_format
    pf.space_after = Pt(12)
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = 1.5

    # Heading 1 - Purple, Bold
    h1 = doc.styles['Heading 1']
    h1.font.name = HEADING_FONT
    h1.font.size = Pt(24)
    h1.font.bold = True
    h1.font.color.rgb = THINK_PURPLE
    h1.paragraph_format.space_before = Pt(24)
    h1.paragraph_format.space_after = Pt(12)

    # Heading 2 - Purple
    h2 = doc.styles['Heading 2']
    h2.font.name = HEADING_FONT
    h2.font.size = Pt(18)
    h2.font.bold = True
    h2.font.color.rgb = THINK_PURPLE
    h2.paragraph_format.space_before = Pt(18)
    h2.paragraph_format.space_after = Pt(8)

    # Heading 3 - Black
    h3 = doc.styles['Heading 3']
    h3.font.name = HEADING_FONT
    h3.font.size = Pt(14)
    h3.font.bold = True
    h3.font.color.rgb = BLACK
    h3.paragraph_format.space_before = Pt(12)
    h3.paragraph_format.space_after = Pt(6)

    return doc


def set_margins(doc, top=1.5, bottom=1.0, left=1.5, right=1.5):
    """Set document margins (in inches)"""
    for section in doc.sections:
        section.top_margin = Inches(top)
        section.bottom_margin = Inches(bottom)
        section.left_margin = Inches(left)
        section.right_margin = Inches(right)


def create_document():
    """Create branded document with styles"""
    doc = Document()
    setup_styles(doc)
    set_margins(doc)
    return doc


def add_branded_title_page(doc, title, subtitle, client, author, date):
    """Add branded title page with professional structure"""

    # Top spacing - position content in upper third
    for _ in range(3):
        doc.add_paragraph()

    # Document type label - small, gray
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("PROPOSAL")
    run.font.size = Pt(12)
    run.font.color.rgb = CHARCOAL
    run.font.name = FONT_NAME
    run.font.all_caps = True

    # Thin purple line (using underscores as visual separator)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("━" * 30)
    run.font.size = Pt(12)
    run.font.color.rgb = THINK_PURPLE

    doc.add_paragraph()

    # Main title - The actual proposal title (subtitle param)
    if subtitle:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(subtitle.replace('\n', ' '))
        run.bold = True
        run.font.size = Pt(28)
        run.font.color.rgb = BLACK
        run.font.name = HEADING_FONT

    # Secondary title line if provided
    if title and title != "PROPOSAL":
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(title)
        run.font.size = Pt(16)
        run.font.color.rgb = CHARCOAL
        run.font.name = FONT_NAME

    # Spacing before client info
    for _ in range(4):
        doc.add_paragraph()

    # Another purple line
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("━" * 30)
    run.font.size = Pt(12)
    run.font.color.rgb = THINK_PURPLE

    doc.add_paragraph()

    # Prepared for - Client name prominent
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("Prepared for")
    run.font.size = Pt(10)
    run.font.color.rgb = CHARCOAL
    run.font.all_caps = True

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(client)
    run.bold = True
    run.font.size = Pt(22)
    run.font.color.rgb = BLACK

    # Spacing
    for _ in range(2):
        doc.add_paragraph()

    # Prepared by
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("Prepared by")
    run.font.size = Pt(10)
    run.font.color.rgb = CHARCOAL
    run.font.all_caps = True

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(author)
    run.bold = True
    run.font.size = Pt(18)
    run.font.color.rgb = THINK_PURPLE

    # Spacing
    for _ in range(2):
        doc.add_paragraph()

    # Date - at bottom
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(date)
    run.font.size = Pt(12)
    run.font.color.rgb = CHARCOAL

    # Page break
    doc.add_page_break()


def parse_table(lines):
    """Parse markdown table into rows"""
    rows = []
    for line in lines:
        if line.startswith('|') and not set(line.replace('|', '').strip()) <= set('-: '):
            cells = [cell.strip() for cell in line.split('|')[1:-1]]
            rows.append(cells)
    return rows


def add_branded_table(doc, rows):
    """Add branded table with purple header"""
    if not rows or len(rows) < 1:
        return

    table = doc.add_table(rows=len(rows), cols=len(rows[0]))
    table.style = 'Table Grid'

    for i, row in enumerate(rows):
        for j, cell_text in enumerate(row):
            cell = table.rows[i].cells[j]
            # Clean text
            clean_text = cell_text.replace('**', '').strip()
            clean_text = clean_text.replace('✓', '[Y]').replace('✅', '[Y]')
            clean_text = clean_text.replace('⚠️', '[!]').replace('❌', '[N]')

            cell.text = clean_text

            # Header row styling - purple background
            if i == 0:
                set_cell_shading(cell, '6944BA')
                for paragraph in cell.paragraphs:
                    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    for run in paragraph.runs:
                        run.bold = True
                        run.font.color.rgb = WHITE
                        run.font.size = Pt(10)
            else:
                # Alternating row colors
                if i % 2 == 0:
                    set_cell_shading(cell, 'F8F8F8')
                for paragraph in cell.paragraphs:
                    for run in paragraph.runs:
                        run.font.size = Pt(10)
                        run.font.color.rgb = BLACK

    doc.add_paragraph()


def add_callout_box(doc, text, box_type='info'):
    """Add a styled callout box"""
    p = doc.add_paragraph()

    # Create the callout
    if box_type == 'key':
        prefix = "KEY: "
        color = THINK_PURPLE
    elif box_type == 'note':
        prefix = "NOTE: "
        color = CHARCOAL
    else:
        prefix = ""
        color = BLACK

    if prefix:
        run = p.add_run(prefix)
        run.bold = True
        run.font.color.rgb = color

    run = p.add_run(text)
    run.font.color.rgb = BLACK


def add_stat_highlight(doc, stat, description):
    """Add a highlighted statistic (purple number)"""
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # Big purple number
    run = p.add_run(stat)
    run.bold = True
    run.font.size = Pt(28)
    run.font.color.rgb = THINK_PURPLE

    # Description below
    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run2 = p2.add_run(description)
    run2.font.size = Pt(12)
    run2.font.color.rgb = CHARCOAL


def process_markdown(doc, content):
    """Process markdown content and add to document with brand styling"""
    lines = content.split('\n')
    i = 0
    in_table = False
    table_lines = []

    while i < len(lines):
        line = lines[i]

        # Table detection
        if line.strip().startswith('|'):
            if not in_table:
                in_table = True
                table_lines = []
            table_lines.append(line)
            i += 1
            continue
        elif in_table:
            rows = parse_table(table_lines)
            add_branded_table(doc, rows)
            in_table = False
            table_lines = []

        # Heading 1
        if line.startswith('# ') and not line.startswith('## '):
            text = line[2:].strip()
            if text not in ['PROPOSAL', 'Table of Contents']:
                doc.add_heading(text, level=1)
            i += 1
            continue

        # Heading 2
        if line.startswith('## '):
            text = line[3:].strip()
            doc.add_heading(text, level=2)
            i += 1
            continue

        # Heading 3
        if line.startswith('### '):
            text = line[4:].strip()
            doc.add_heading(text, level=3)
            i += 1
            continue

        # Heading 4
        if line.startswith('#### '):
            text = line[5:].strip()
            p = doc.add_paragraph()
            run = p.add_run(text)
            run.bold = True
            run.font.size = Pt(12)
            run.font.color.rgb = BLACK
            i += 1
            continue

        # Horizontal rule - subtle break
        if line.strip() == '---':
            i += 1
            continue

        # Bullet points
        if line.strip().startswith('- ') or line.strip().startswith('* '):
            text = line.strip()[2:]
            # Handle bold within text
            p = doc.add_paragraph(style='List Bullet')

            # Parse bold sections
            parts = re.split(r'(\*\*.*?\*\*)', text)
            for part in parts:
                if part.startswith('**') and part.endswith('**'):
                    run = p.add_run(part[2:-2])
                    run.bold = True
                else:
                    clean_part = re.sub(r'\[(.*?)\]\(.*?\)', r'\1', part)
                    p.add_run(clean_part)

            i += 1
            continue

        # Numbered list
        if re.match(r'^\d+\. ', line.strip()):
            text = re.sub(r'^\d+\. ', '', line.strip())
            p = doc.add_paragraph(style='List Number')

            # Parse bold sections
            parts = re.split(r'(\*\*.*?\*\*)', text)
            for part in parts:
                if part.startswith('**') and part.endswith('**'):
                    run = p.add_run(part[2:-2])
                    run.bold = True
                else:
                    clean_part = re.sub(r'\[(.*?)\]\(.*?\)', r'\1', part)
                    p.add_run(clean_part)

            i += 1
            continue

        # Regular paragraph
        if line.strip():
            text = line.strip()

            # Skip code blocks
            if text in ['```', '```markdown', '```json']:
                i += 1
                continue

            # Skip placeholder indicators
            if text.startswith('[') and text.endswith(']'):
                # Keep placeholders visible but styled
                p = doc.add_paragraph()
                run = p.add_run(text)
                run.font.color.rgb = THINK_PURPLE
                run.italic = True
                i += 1
                continue

            p = doc.add_paragraph()

            # Parse bold sections and links
            parts = re.split(r'(\*\*.*?\*\*)', text)
            for part in parts:
                if part.startswith('**') and part.endswith('**'):
                    run = p.add_run(part[2:-2])
                    run.bold = True
                else:
                    clean_part = re.sub(r'\[(.*?)\]\(.*?\)', r'\1', part)
                    p.add_run(clean_part)

        i += 1

    # Handle any remaining table
    if in_table and table_lines:
        rows = parse_table(table_lines)
        add_branded_table(doc, rows)


def convert_proposal(input_path, output_path, title, subtitle, client, author, date):
    """Main conversion function"""

    # Read markdown
    content = read_markdown(input_path)

    # Create branded document
    doc = create_document()

    # Add title page
    add_branded_title_page(doc, title, subtitle, client, author, date)

    # Add table of contents placeholder
    doc.add_heading("Table of Contents", level=1)
    p = doc.add_paragraph()
    run = p.add_run("[Update Table of Contents after finalizing document]")
    run.font.color.rgb = CHARCOAL
    run.italic = True
    doc.add_page_break()

    # Find where main content starts
    start_marker = "# 1."
    start_idx = content.find(start_marker)
    if start_idx > 0:
        main_content = content[start_idx:]
    else:
        main_content = content

    # Process content
    process_markdown(doc, main_content)

    # Save document
    doc.save(output_path)
    print(f"Branded document saved to: {output_path}")
    return output_path


def main():
    """Command line interface"""
    if len(sys.argv) < 2:
        # Default: convert Syndicus Nacon proposal
        base_path = '/Users/admin/Library/CloudStorage/GoogleDrive-marvin@compoundleverage.co/My Drive/Compound Leverage/Work/Sell/Generate/Nurturing/THINK Implementation/Proposal Stage/_Proposal Generator'

        input_path = f'{base_path}/proposals/syndicus-nacon/proposal_draft.md'
        output_path = f'{base_path}/proposals/syndicus-nacon/Syndicus_Nacon_Proposal_Branded.docx'

        convert_proposal(
            input_path=input_path,
            output_path=output_path,
            title="PROPOSAL",
            subtitle="AI Enablement Across Sales, Marketing,\nStaffing, & Operations",
            client="Syndicus Nacon",
            author="Compound Leverage",
            date="November 2024"
        )
    else:
        # Use command line arguments
        input_path = sys.argv[1]
        output_path = sys.argv[2] if len(sys.argv) > 2 else input_path.replace('.md', '_branded.docx')
        client = sys.argv[3] if len(sys.argv) > 3 else "Client"

        convert_proposal(
            input_path=input_path,
            output_path=output_path,
            title="PROPOSAL",
            subtitle="",
            client=client,
            author="Compound Leverage",
            date="2024"
        )


if __name__ == "__main__":
    main()
