# [EDIT: Your Company Name] Brand Guidelines

## Core Brand Promise

**Primary Message**: "[EDIT: Your main tagline - e.g., 'Work Less. Do More.']"

**Supporting Claim**: "[EDIT: Your value proposition with numbers - e.g., 'Eliminate 15+ hours of manual work each week']"

**Target Audience**: [EDIT: Describe your ideal customer]

**Brand Aesthetic**: [EDIT: Describe your visual identity - e.g., 'Modern, premium, tech-forward. Clean and intentional.']

---

## Color System

### Primary Colors
- **Primary Brand Color**: [EDIT: #HEXCODE] (signature brand color)
- **Black**: #000000 (primary text, strong hierarchy)
- **White**: #FFFFFF (clean backgrounds, high contrast)

### Secondary Neutrals
- **Charcoal Gray**: #4A4A4A (grounding accent, supporting text)
- **Off-White**: #F8F8F8 (backgrounds, minimal visual noise)
- **Light Gray**: #E8E8E8 (dividers, subtle separation)

### Color Application Rules
- **Primary Color**: Headlines, CTAs, key statistics, urgency elements
- **Black**: Body text, primary navigation, strong calls-to-action
- **Gray/Neutral**: Secondary text, dividers, supporting information
- **Ratio**: 70% neutral, 20% black/dark, 10% primary color

---

## Typography

### Font Stack
- **Headings**: [EDIT: Your heading font - e.g., 'Inter Bold, Montserrat Bold']
- **Body Text**: [EDIT: Your body font - e.g., 'Inter Regular, Open Sans Regular']

### Typography Hierarchy
- **H1 (Main Headline)**: 48-56px, Bold
- **H2 (Section Heading)**: 32-40px, Bold
- **H3 (Subsection)**: 24-28px, Semi-bold
- **Body**: 14-16px, Regular
- **Captions**: 12px, Regular

---

## Messaging & Voice

### Core Messaging Hierarchy
1. **Primary**: "[EDIT: Your main message]"
2. **Supporting**: [EDIT: Your methodology or approach]
3. **Value Proposition**: "[EDIT: Specific quantified benefit]"

### Writing Standards
- Average [EDIT: 15-20] words per sentence maximum
- [EDIT: 6th-8th] grade reading level
- Use "you" language throughout
- Include specific numbers and timeframes
- One idea per paragraph
- Start paragraphs with benefit or hook

### Messaging Rules
- **Benefits before features**: Always lead with transformation, not technology
- **Transformation stories beat explanation**: Show results, not how it works
- **Specificity converts**: Use exact numbers, not vague benefits
- **Problem-first**: Always start with the reader's pain, then the solution
- **Action-oriented**: Benefit-driven CTAs, not feature-driven

### Brand Voice
- [EDIT: List 5-7 voice characteristics - e.g., 'Professional but direct', 'Data-driven with numbers']

---

## Proposal Writing Guidelines

### Document Structure
1. **Problem-First**: Present the client's problem first
2. **Transformation Focus**: Lead with outcomes
3. **Specificity**: Always include numbers, timeframes, measurable results
4. **Single Outcome**: One reader, one message, one outcome per document

### Narrative Style
- Lead with client's pain, not your methodology
- Use flowing paragraphs, not just tables
- Tables for data comparison only
- "You" language throughout
- Short sentences (max 15 words average)
- One idea per paragraph

### Section Approach
| Section | Lead With | Avoid |
|---------|-----------|-------|
| Executive Summary | Client's biggest pain, quantified | Your credentials |
| Understanding | Their specific situation | Generic industry problems |
| Solution | Outcomes they'll achieve | How your methodology works |
| Investment | Value and ROI | Just the price |
| Risk | How you protect them | Exhaustive risk lists |

### Visual Hierarchy
- Lead with transformation headline in primary color
- Use black for body copy and key information
- Leverage whitespace to draw focus
- Break content with section dividers using Light Gray
- Primary color used strategically—not overused

### Layout & Spacing
- **Generous Whitespace**: 1.5-2 inches minimum margins on left/right
- **Line Height**: 1.5-1.8 for body text
- **Paragraph Spacing**: 1.5x line height between paragraphs
- **Breathing Room**: Never crowded. Let content breathe.

---

## Do's & Don'ts for Proposals

### Do
- Lead with transformation and specific outcomes
- Use primary color strategically for maximum impact
- Include specific numbers and timeframes in every headline
- Create high-whitespace, premium layouts
- Write benefit-focused CTAs
- Start content with the problem, then the solution
- Use "you" language throughout
- Keep copy concise
- Use narrative paragraphs to tell the story
- Save tables for data comparison only

### Don't
- [EDIT: List terms/phrases to avoid]
- Use vague benefits instead of specific numbers
- Overuse primary color (more than 10% of design)
- Create cluttered or busy layouts
- Lead with features instead of transformation
- Write longer than 15 words per sentence
- Use tables for everything
- Start with your methodology or credentials
- Use "we" language when "you" works better

---

## Key Principles

1. **Sell the destination, not the airplane**: Focus on transformation, not the technology
2. **Specific beats vague**: Exact numbers convert better than "significant savings"
3. **Problem-first always**: Reader needs to see themselves in the pain before they'll accept the solution
4. **Primary color restraint builds trust**: Strategic use creates recognition without looking desperate
5. **High whitespace = premium feel**: Let designs breathe
6. **One outcome per document**: Competing messages dilute impact
7. **Numbers drive credibility**: Every stat, every metric must be quantified
8. **You language creates connection**: "You're spending..." beats "Companies spend..."
