# Methodology

Add your proprietary methodology files here. The Proposal Engine references these when Quinn drafts the methodology section of each proposal.

Suggested files:
- `framework.md` — your core delivery framework
- `approach.md` — how you engage clients
- `differentiators.md` — what makes your method unique

These files are yours — never synced or overwritten by CL library updates.
