# Maya Ross: Proposal Engine Lead -- Hook Map

| When to run | Trigger type | Trigger value | Action |
|---|---|---|---|
| On demand | Explicit ask | `/maya run-proposal [client]` | Initialize proposal folder, run intake (Phase 1), dispatch Chase |
| On demand | Command | `/maya status` or `/maya pipeline` | Check status of active proposals |
| On demand | Event | DE delivers phase artifact | Check gate, notify Marvin, dispatch next phase DE upon approval |

## Notes

- Maya orchestrates the end-to-end 7-phase proposal development pipeline.
- Deciding whether to advance past decision gates requires Marvin's approval.
