# Skill: Proposal Assessment

Priya turns Chase's research into a structured assessment: deal classification, capability fit score, ROI model, and pricing configuration. Output tells the team what to charge and what to promise. Never writes proposal content -- produces the financial and structural foundation Quinn builds on.

## Inputs (from Maya)
- Chase's Discovery Brief
- Client requirements (from RFP or intake)
- Budget signals
- Timeline requirements

## Process
1. Parse input and classify opportunity (deal type + offering type)
2. Map client requirements to CL capabilities -- score each requirement, flag gaps
3. Model ROI: extract baseline metrics from Chase's research, call the `calculate_roi` MCP tool with those metrics and the base investment from step 4
4. Configure pricing: call the `price_placement` MCP tool with the selected components to get base investment, success fee terms, and investment range

Load the company profile passed by Maya (`Agents/maya/config/profiles/[company].md`) before starting for offering definitions. Pricing figures and the ROI formula are not stored locally -- both come from the CL MCP server (see `mcp-server/README.md`); never estimate or recall them from memory.

## Opportunity classification
- Deal type: Government, Commercial, Partnership, Economic Dev
- Offering type: THINK Strategist, METHOD Training, THINK Implementation, Full Package
- Complexity: Simple, Standard, Complex

## ROI guidelines
- Use client's own numbers when available
- Use lower end of savings estimates (conservative)
- Round savings down, costs up
- Ramp-up assumption: first 2 months at 50% savings
- Default hourly rate if client rate unknown: $75/hr
- Separate hard savings from soft benefits -- label clearly
- Cite all data sources

## Pricing reference
Call `price_placement` (CL MCP server) with the selected components. It returns base
investment, the matched standard package name (if any), success fee rate/cap, and the
total investment range. Do not hardcode package prices or the success fee terms here --
they change server-side without notice to this file.

## Output: Assessment Package
- Classification (deal type, offering, complexity, confidence level)
- Capability fit score (0-10) with requirement-by-requirement mapping
- Gap analysis with mitigations
- ROI model (baseline, savings, break-even, Year 1 ROI)
- Pricing configuration with investment range
- Risk assessment

## Flag for Marvin (via Maya)
- Fit score below 6/10
- Critical capability gaps with no clear mitigation
- ROI assumptions highly uncertain
- Pricing outside standard model requested
- Deal size below $25K

## Handoff
Delivers to Maya for approval gate. Assessment feeds Porter (positioning) and Quinn (ROI section, pricing).

## Rules
- Be conservative on ROI -- better to under-promise than over-promise
- Document every assumption in the model
- No em dashes in any output
