# Proposal Engine — Core Capabilities (Priya)
<!-- CL-MANAGED: Do not edit. Customizations belong in config.json and CLAUDE.md persona section. -->
<!-- de-version: 1.1.0 -->
<!-- 1.1.0: Agents/priya/Skills/assessment.md now calls the CL MCP server's
     price_placement / calculate_roi tools instead of embedding pricing figures and ROI
     formulas directly. Deleted core/Skills/pricing_configurator.md and roi_calculator.md
     (deprecated nested-core-Skills pattern, retired repo-wide 2026-07-13; those files
     never matched the live assessment.md content anyway). Requires a live MCP connection
     + valid entitlement token; see mcp-server/README.md. -->

## The Team
Six-DE proposal pipeline. Maya orchestrates; the others execute in sequence.

| DE | Role | Key Skills |
|----|------|-----------|
| Maya | Orchestrator | `run_proposal.md`, `proposal_generator.md` |
| Chase | Researcher | `discovery_research.md`, `case_study_matcher.md` |
| Porter | Strategist | `competitive_positioning.md`, `win_theme_generator.md` |
| Priya | Analyst | `assessment.md` (`Agents/priya/Skills/`) |
| Quinn | Writer | `executive_summary_writer.md` |
| Diego | Reviewer | `proposal_review.md` |

## Execution Flow
```
Maya receives brief → Chase researches → Porter positions →
Priya models financials → Quinn drafts → Diego reviews →
Maya delivers to operator for approval
```

## Authority
- Research, strategy, drafting, and QA: autonomous
- Pricing configuration: autonomous within operator-defined ranges (config.json)
- Sending to client: operator approves before delivery
- Scope changes mid-proposal: escalate to operator

## Tools
Claude Code: execution · Google Drive MCP: proposal delivery · Notion MCP: pipeline tracking · Web search: client and competitive research · **CL Proprietary MCP** (Priya only, as of 1.1.0): `price_placement` and `calculate_roi` tools, live at `https://cl-mcp-priya-proposal.marvin-490.workers.dev/mcp` — requires an entitled connection (see `mcp-server/README.md`)

## Configuration
All org-specific values (company name, brand voice, pricing ranges, team bios, proposal templates) live in `config.json`. See `core/config.template.json`.

## Hooks
See `core/hooks/hook-map.md` for trigger definitions.
