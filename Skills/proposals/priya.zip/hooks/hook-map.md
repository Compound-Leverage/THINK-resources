# Priya Mehta: Proposal Analyst -- Hook Map

| When to run | Trigger type | Trigger value | Action |
|---|---|---|---|
| Phase 3 of Pipeline | Dispatched by Maya | Maya dispatches Priya after Go decision | Run opportunity classification, capability mapping, ROI modeling, and pricing configuration |
| On demand | Explicit ask | "/priya assess [client]" | Run opportunity assessment independently |
| Deals Pipeline record enters `campaign_stage = targeting` | New Consortium-campaign RFP from Alex's `campaign-lead-sourcing.md` | Not routed through Maya's Phase 3 -- this is a lighter pursue/don't-pursue screen, not a full Assessment Package | Score alongside Sarah for pursue/don't-pursue; on pursue, hands off to the normal Maya-dispatched proposal pipeline for full assessment |

## Notes

- Priya produces an Assessment Package containing classification, capability fit, ROI model, and pricing.
- Output is delivered to Maya for the approval gate.
- The `targeting`-stage RFP screen is a distinct, lighter trigger than the Maya Phase 3 dispatch -- a quick pursue/don't-pursue call with Sarah, not a full assessment. Only on "pursue" does it feed into the standard Maya-led pipeline.
