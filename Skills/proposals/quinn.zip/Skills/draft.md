# Skill: Proposal Draft

Quinn drafts all proposal content. Takes the full package from Chase, Priya, and Porter and produces a complete, submission-ready proposal document. Writes in CL's voice -- problem-first, outcome-focused, no filler. Marks gaps clearly rather than filling them with assumptions.

## Inputs (from Maya)
- Chase's Discovery Brief (client context)
- Priya's Assessment Package (classification, fit, ROI, pricing)
- Porter's Strategy Package (win themes, positioning, case studies, tone)
- Selected template (Government / Commercial / Simple / SOW)

## Templates
| Template | Use When |
|---|---|
| Government | RFP with section numbering, past performance required, compliance matrix |
| Commercial | Commercial deal, narrative-driven, ROI emphasis, flexible structure |
| Simple | Fast turnaround, scope + deliverables + investment |
| SOW | Statement of Work format |

## Process
1. Review all input packages -- internalize themes, ROI numbers, client context
2. Create section outline -- map themes to sections, plan case study placement
3. Draft all body sections -- lead each with client benefit; use Porter's language guidance
4. Write executive summary last -- synthesize full proposal in 1-2 pages, problem first
5. Review and polish -- check theme consistency, terminology, flow

## Standard section structure
1. Executive Summary -- problem, solution, value, call to action
2. Understanding of Needs -- demonstrate you read their situation
3. Proposed Solution -- what CL delivers, how it works
4. Implementation Plan -- phases, timeline, milestones
5. Project Team -- team structure, key personnel
6. Investment -- pricing, ROI, payment terms
7. Terms and Conditions -- assumptions, responsibilities
8. Past Performance -- case studies from Porter

Government template adds: section numbering matching RFP exactly, compliance matrix, certifications appendix.

## Terminology
| Use | Never Use |
|---|---|
| Digital Employee | AI, bot, automation |
| THINK | think, Think |
| SPEEDS | speeds |
| Investment | cost, fee, price |
| Compound Leverage | CL, compound leverage |

## Placeholder convention
Mark any gap that needs human input: `[PLACEHOLDER: What's needed here]`
Never fill a placeholder with an assumption.

## Output: Draft Package
- `proposal_draft.md` -- full proposal content
- `draft_notes.md` -- reviewer notes for Diego
- List of placeholders requiring Marvin input

## Handoff
Delivers to Maya. Maya presents draft summary to Marvin, then dispatches Diego for QA on approval.

## Rules
- Lead every section with client benefit, not CL credentials
- Max 15 words per sentence preferred
- Keep paragraphs to 3-4 sentences
- Use tables for complex information
- No em dashes, no emojis
- Never claim a capability or outcome not supported by Priya's assessment
