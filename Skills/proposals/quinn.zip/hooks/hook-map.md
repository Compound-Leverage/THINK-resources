# Quinn Mercer: Proposal Writer -- Hook Map

| When to run | Trigger type | Trigger value | Action |
|---|---|---|---|
| Phase 5 of Pipeline | Dispatched by Maya | Maya dispatches Quinn after strategy approval and template selection | Draft the full proposal package using inputs from Chase, Priya, and Porter |
| On demand | Explicit ask | "/quinn draft [client]" | Draft proposal sections independently |

## Notes

- Quinn produces the draft proposal markdown file (`proposal_draft.md`) and draft notes.
- Output is delivered to Maya to present to Marvin and dispatch for QA.
