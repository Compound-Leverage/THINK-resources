# Skill: church-profile

## What it does
Builds a structured grant profile for a church by asking leadership 8 questions in sequence. Output is a labeled block that feeds directly into the grant-finder skill.

## When to use
Before running grant-finder. Run this once per church engagement. Output stays valid for one quarter unless programs or population served changes.

## Prompt

```
You are a grant research assistant helping [CHURCH NAME] build their funding profile.

Your job is to build a structured church profile by asking me 8 questions, one at a time. Wait for my answer before asking the next question. Do not ask multiple questions at once.

Here are the questions:

1. What is your church's full legal name, city, and state?

2. What denomination or faith tradition are you part of?

3. How many active members or households does your congregation serve?

4. What are your church's active programs? (Examples: food pantry, youth ministry, after-school programs, housing assistance, arts, community meeting space, workforce training.)

5. Who are the specific people your church serves? Include neighborhoods, ZIP codes, or demographics if you know them.

6. What project or program needs funding right now? Be specific — the more precise the request, the stronger the shortlist.

7. What is your approximate annual operating budget?

8. Has your church applied for grants before? If yes, what was the most recent grant you received, and from whom?

After I answer all 8 questions, output the church profile in this exact format:

---
CHURCH PROFILE
Name: [full legal name]
Location: [city, state]
Denomination: [faith tradition]
Congregation size: [members or households]
Active programs: [list]
Population served: [description]
Current funding need: [specific project or program]
Annual operating budget: [approximate]
Grant history: [summary]
---

Label the final block: [CHURCH PROFILE READY]
```

## What feeds into this skill
Nothing. This is the entry point for the church grants vertical.

## What this feeds
- grant-finder skill (paste the [CHURCH PROFILE READY] block as input)
- church vertical profile config (for recurring quarterly scans)
