# Skill: Proposal Delivery

After a proposal is finalized (Drive written, Notion updated to Proposal Stage), Blair packages it for send and gates on Marvin approval before any external delivery.

**Trigger:** Blair completes proposal generation, OR Marvin explicitly requests `/blair deliver [Deal Name]`.

---

## Step 1 — Verify proposal is ready

Query Deals Pipeline (789edd2b). Confirm:
- Status = Proposal Stage
- Proposal Drive Link is populated
- Decision-maker email is in Contacts DB (170e1f64)

If any field is missing, post to Google Chat: `BLAIR — PROPOSAL BLOCKED: [Deal Name] — missing: [field]`. Do not proceed.

---

## Step 2 — Build the email

**From:** marvin@compoundleverage.com  
**To:** decision-maker email from Contacts DB  
**Subject:** Proposal: [CL Offer] for [Org Name] — [Brief Funder Type Hook]

```html
Hi [first_name],

Thank you for your time. As discussed, I've put together a proposal for how Compound
Leverage can support [Org Name]'s [specific goal — grants capture / workforce training /
digital staffing].

[One sentence naming the core value: e.g., "Our model staffs your team with digital
employees who handle [function], so your people focus on [outcome]."]

I've attached the full proposal below. The key details are on page 2: what we're proposing,
the implementation timeline, and the investment.

[View Proposal button → Drive link]

Happy to walk through this live. Just reply here and we'll get something on the calendar.

Marvin Harris
Compound Leverage | marvin@compoundleverage.com
```

**Button:**
```html
<a href="[DRIVE_LINK]" style="display:inline-block;background-color:#6B21A8;color:white;
padding:10px 20px;border-radius:4px;text-decoration:none;font-weight:bold;">
View Proposal
</a>
```

---

## Step 3 — Marvin approval gate

Post to Google Chat (findings channel):

```
BLAIR — PROPOSAL READY: [Org Name]
Deal: [Deal Name] | Amount: $[X] | Funder Type: [type]
To: [decision-maker name] <[email]>
Drive: [link]

Reply GO to send. Reply HOLD to pause.
```

Do not send until Marvin replies GO. If no reply within 24 hours, re-post once, then hold.

---

## Step 4 — Send on Marvin GO

Send the HTML email via `config.zapier_marvin_send_action_url`.

After confirmed send:
1. Update Deals Pipeline record:
   - Status = Proposal Sent
   - last_touch_date = today
   - next_action_date = today + 5 business days
   - campaign_stage = proposal-sent (if campaign field is set)
2. Post to Google Chat: `BLAIR — PROPOSAL SENT: [Org Name] to [decision-maker name] at [email] — follow-up due [next_action_date]`

---

## Rules
- No external send without Marvin GO
- Always verify Drive link is accessible before sending
- Never send to a contact not in Contacts DB
- No em dashes in copy
