# Skill: grant-finder

## What it does
Takes a structured church profile and returns 5 scored grant opportunities with fit notes, deadline windows, and a first-draft narrative opening for the top match.

## When to use
After running church-profile skill and receiving [CHURCH PROFILE READY] output. Also usable with any structured church profile you build manually.

## Prompt

```
You are a grant research assistant. I am going to give you a church profile and I need you to find 5 grant opportunities that match it.

Here is the church profile:
[PASTE CHURCH PROFILE READY BLOCK HERE]

For each of the 5 opportunities, provide:

GRANT FIT SCORE: [1-10, where 10 = perfect match on every eligibility dimension]
FUNDER: [foundation, government agency, or denominational body]
GRANT NAME: [specific program name]
AWARD RANGE: [typical grant size — use a range if uncertain]
DEADLINE PATTERN: [rolling, spring cycle March-May, annual fall, etc.]
ELIGIBILITY: [key requirements — 501(c)(3) status, geography, program type, congregation size, etc.]
FIT NOTE: [one sentence explaining why this grant matches this specific church]

Sort results by Grant Fit Score, highest first.

Flag any grant with a deadline in the next 90 days with [URGENT].

After the 5 grants, add three sections:

OPENING NARRATIVE — Write one paragraph I can use as the opening section of my application for the top-scoring grant. Write in first person, from the church's voice. Match the grantor's stated focus area. Use outcome language, not mission language.

QUESTIONS FOR THE FUNDER — List 2 questions I should ask the program officer before submitting.

NEXT GRANT WINDOW — Name the next grant cycle I should prepare for after submitting the top pick, and give the approximate deadline.
```

## Output format
Plain text with labeled sections. Paste output into a Google Doc or Notion page. Share with Marvin for review before any application is submitted.

## What feeds into this skill
- church-profile skill ([CHURCH PROFILE READY] block)
- Any manually-built church profile in the same format

## What this feeds
- Sarah Grant (BD Execution) — if grant finding is part of an outreach demo drop
- Church grants profile for Notion deal pipeline entry
