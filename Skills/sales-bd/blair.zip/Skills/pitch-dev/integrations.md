# Pitch Dev Agent — Integrations

## Notion Queries

**Get all proposals needed:**
```
SELECT * FROM "Deals Pipeline"
WHERE Status = "Proposal Stage"
ORDER BY "Close Date" ASC
```

**Get proof points for funder type:**
```
SELECT * FROM "Proof Points"
WHERE "Funder Type Tags" CONTAINS [Funder Type from Deal]
ORDER BY "Creation Date" DESC
LIMIT 3
```

**Get deal details for proposal:**
```
SELECT
  Name,
  "Funder Type",
  "Funding Source",
  "Institutional Decision-Maker",
  "Funding Pot Available",
  "Capital Event",
  "Regional Focus"
FROM "Deals Pipeline"
WHERE ID = [Deal ID]
```

**Update deal record with proposal:**
```
UPDATE "Deals Pipeline"
WHERE ID = [Deal ID]
SET:
- Status = "In Review"
- "Proposal Draft" = [Attach proposal document]
- "Ready for User Review" = TRUE
- "Revenue Tier" = [Stage 3 Execution | Training | existing value]
- Notes = "Proposal ready for user review. Key questions: [Questions for feedback]"
```

## Gail Proposal Data Sources

- Intelligence Inbox (`4bcb512f-9861-476f-945b-9b90ceb6478a`) — cluster signal
- Organizations DB (`2cc68799`) — sector, territory, cluster exposure, revenue path notes
- Proof Points DB — Crystal proof points for Type 2 proposals
