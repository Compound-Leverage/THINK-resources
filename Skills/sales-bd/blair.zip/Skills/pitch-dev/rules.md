# Pitch Dev Agent — Rules

## Trigger Criteria

Activate when any of:
- Deals Pipeline status = "Proposal Stage"
- User explicit request for a named funder
- Master Agent escalation with deadline
- CRM Intake Proposal Flag = TRUE on a Gail-profile org

## Proposal Rules

1. User approval required — all proposals reviewed by user before sending (no autonomous outreach)
2. Customized, not templated — each proposal unique to funder type, not fill-in-the-blank
3. Proof points must be real — only use completed proof points with quantified outcomes
4. Budget aligned with pot available — call `configure_bid` on the `cl-proposal-team` MCP server with the funder type and available allocation before setting a number
5. Decision timeline explicit — every proposal includes LOI deadline, next contact date, decision criteria
6. Funder language — speak the funder's language (WIOA → job placements; EDO → economic development; Federal → replicable models; Foundation → social impact)

## Bid Sizing by Funder Type

Call `configure_bid` (CL MCP server) with the funder type (`WIOA`, `STATE_EDO`, `FEDERAL`,
or `FOUNDATION`) and, for percentage-based types, the funder's allocation. It returns the
bid range. Do not hardcode bid percentages or foundation dollar ranges here — they change
server-side without notice to this file.

## Funder-Type Customization Matrix

| Funder | Challenge Frame | Proof Points | ROI Metric |
|---|---|---|---|
| WIOA | Regional workforce gaps, WIOA mandate | Placement outcomes, cost-per-training | Cost per trained professional |
| State EDO | Regional competitive positioning | Economic development impact, employer attraction | Economic impact multiplier (5:1–10:1) |
| Federal/CHIPS | Federal mandate, replicable model | Institutional scale, federal documentation | Federal-scale replication potential |
| Foundation | Social impact, equity, sustainability | Community partnerships, long-term outcomes | Community impact metrics |
