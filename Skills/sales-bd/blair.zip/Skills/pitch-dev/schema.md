# Pitch Dev Agent — Schema

## Notion Database IDs

| Database | ID |
|---|---|
| Deals Pipeline | 789edd2b-162d-479b-aac6-06e6fdd1a04d |
| Organizations | 2cc68799 |
| Capital Event Intelligence Inbox | 4bcb512f-9861-476f-945b-9b90ceb6478a |

## Deal Record Fields

| Field | Values |
|---|---|
| Funder Type | State Workforce Board, EDO, Federal Agency, Foundation, CHIPS Office, Federal |
| Funding Source | WIOA, State Appropriation, Federal Grant, Foundation Grant |
| Status | Prospect, Outreach, Proposal Stage, In Review, LOI, Closed |
| Revenue Tier | Stage 3 Execution (Gail Type 1), Training (Gail Type 2) |
| Ready for User Review | TRUE / FALSE |

## Success Metrics

- 1+ proposals per session
- 100% customized (not generic)
- 100% include relevant proof points
- 100% include decision-maker contact info
- Average LOI conversion: 25%
