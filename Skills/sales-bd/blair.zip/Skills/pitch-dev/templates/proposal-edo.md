# Proposal Template: Economic Development Organization (EDO)

**Contact format:** Director of Economic Development, Mayor's office

**Challenge Section:**
- Frame around economic development mandate
- Emphasize regional competitive positioning
- Capital investment driver (data centers, quantum, advanced manufacturing)
- Workforce as economic development tool

**Solution Section:**
- Regional leadership positioning
- Community college partnership (sustainability)
- Advanced manufacturer attraction
- Economic impact calculation

**Proof Points to Pull:**
- Regional/institutional scale deployments
- Economic development impact (employer attraction, job fills)
- Community college partnership models
- Regional thought leadership outcomes

**Budget:**
- Call `configure_bid` (funderType: STATE_EDO, allocation: [state appropriation]) on the `cl-proposal-team` MCP server for the bid range
- ROI: Regional economic impact multiplier (5:1 to 10:1), employer attraction metrics

**Timeline:** 6-week deployment, capital event alignment (construction ramp-up)
