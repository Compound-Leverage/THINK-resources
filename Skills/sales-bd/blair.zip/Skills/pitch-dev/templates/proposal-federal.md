# Proposal Template: Federal Agency (CHIPS, DOL, EDA)

**Contact format:** Federal program officer, agency leadership

**Challenge Section:**
- Frame around federal mandate (CHIPS Act, WIOA reauthorization, federal policy)
- Emphasize replicable federal model
- Federal-scale documentation
- Policy impact positioning

**Solution Section:**
- Documented, replicable federal model
- Multi-state expansion potential
- Federal compliance + outcome tracking
- Policy positioning (DOES as federal innovation leader)

**Proof Points to Pull:**
- Institutional-scale rapid deployment
- Federal agency engagement
- Documented replication models
- Federal policy positioning outcomes

**Budget:**
- Call `configure_bid` (funderType: FEDERAL, allocation: [federal allocation]) on the `cl-proposal-team` MCP server for the bid range
- ROI: Federal-scale replication potential (5–10 states), policy impact, grant expansion

**Timeline:** 6-week pilot + federal documentation (Q4 reauthorization impact)
