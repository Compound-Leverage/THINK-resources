# Proposal Template: Foundation

**Contact format:** Program officer, executive director

**Challenge Section:**
- Frame around social impact (community benefit, equity, opportunity)
- Emphasize sustainability + systemic change
- Long-term workforce ecosystem benefit

**Solution Section:**
- Community partnership model
- Institutional capacity building
- Measurable community outcomes
- Sustainability pathway

**Proof Points to Pull:**
- Social impact outcomes
- Community partnership models
- Organizational capacity building
- Long-term sustainability examples

**Budget:**
- Call `configure_bid` (funderType: FOUNDATION) on the `cl-proposal-team` MCP server for the standard range
- ROI: Community impact metrics, participants served, long-term outcomes

**Timeline:** 6-week deployment + sustainability planning
