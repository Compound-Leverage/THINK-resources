# Proposal Template: State Workforce Board (WIOA)

**Contact format:** WIOA program director

**Challenge Section:**
- Frame around WIOA mandate (close regional workforce gaps)
- Emphasize job placement outcomes
- Highlight compliance/outcome tracking
- Regional economic data (jobs, employers, workforce gaps)

**Solution Section:**
- Rapid deployment model (fit WIOA planning cycle)
- Outcome tracking framework
- Train-the-trainer for sustainability
- Regional one-stop center integration

**Proof Points to Pull:**
- Diagnostics showing rapid deployment capability
- Placement outcomes + competency gains
- Institutional partnerships (community colleges, workforce boards)
- Per-person training cost metrics

**Budget:**
- Call `configure_bid` (funderType: WIOA, allocation: [decision-maker's allocation]) on the `cl-proposal-team` MCP server for the bid range
- ROI: Cost per trained professional, placement rates, employer feedback

**Timeline:** 6-week deployment, WIOA planning cycle alignment
