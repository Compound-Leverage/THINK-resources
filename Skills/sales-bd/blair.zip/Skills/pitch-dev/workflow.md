# Pitch Dev Agent — Workflow

Triggered on-demand or when deals move to Proposal Stage.

---

## Trigger Conditions

1. Deals Pipeline shows status = "Proposal Stage"
2. User explicitly requests: "Pitch Dev Agent: Create proposal for [Funder Name]"
3. Master Agent escalates: "Proposal needed by [Date] for $[X] deal"
4. CRM Intake flags Proposal Flag = TRUE on a Gail-profile org

---

## Phase 0: Trigger Kipp Pre-Enrichment

Before gathering intelligence, trigger a fresh Kipp Clay enrichment run on the deal org. Do not write the proposal on stale Notion data — org intelligence from CRM intake may be months old.

1. Pull the org name and domain from the Deals Pipeline record.
2. Call Kipp: "Kipp — run Clay enrichment on [org name / domain] before Blair writes the proposal. Return: current headcount, recent hires (past 90 days), tech stack, funding events (past 12 months), any RFPs or procurement notices, and key decision-maker contact verification."
3. Wait for Kipp to return enriched fields. Kipp writes updated fields to the Notion Org record.
4. If Kipp returns a trigger signal (new funding round, new VP/Director hire, published RFP) that was not in the existing record: note it as a "fresh signal" to open the proposal with.

---

## Phase 1: Gather Intelligence

**Query Notion Deals Pipeline:**
```
SELECT * FROM "Deals Pipeline"
WHERE Status = "Proposal Stage"
ORDER BY "Close Date" ASC
```

**For each deal, extract (read from freshly enriched Notion record from Phase 0):**
- Funder Type (State Workforce Board, EDO, Federal Agency, Foundation, etc.)
- Funding Source (WIOA, State Appropriation, Federal Grant, Foundation Grant)
- Institutional Decision-Maker (name, title, contact info — verified by Kipp)
- Funding Pot Available (total budget in funder's allocation)
- Capital Event (what triggered this opportunity?)
- Fresh signal from Phase 0 (if any) — leads the proposal opening if present
- Regional Focus (Data Center Hubs, Semiconductor Clusters, etc.)
- 90-Day Alignment (is close date realistic?)

**Query Proof Points Database:**
```
SELECT * FROM "Proof Points"
WHERE "Funder Type Tags" CONTAINS [Deal's "Funder Type"]
ORDER BY "Creation Date" DESC
LIMIT 3
```

If fewer than 2 proof points match this deal's Funder Type: invoke Marcus on-demand per his hook-map ("Manual invoke" — bypasses weekly schedule) with the deal's funder type as the arg, and wait for the fresh case study before proceeding to Phase 2. Do not proceed with fewer than 2 relevant proof points on a Proposal-Stage deal.

---

## Phase 2: Proposal Customization

**Standard proposal structure (9 sections):**
1. Cover Page — decision-maker routing, validity date, logistics
2. Executive Summary — mandate, challenge, solution, investment
3. The Funder's Challenge — their specific problem, phrased in their language
4. THINK Solution — how THINK solves THEIR problem, not generic
5. Proof Points — 2–3 case studies most relevant to their funder type
6. Implementation Timeline — 6-week deployment
7. Team & Qualifications — who executes, what credentials
8. Budget & ROI — clear $ ask, expected outcome value
9. Decision Criteria — LOI timeline, next meeting, decision deadline

**Bid sizing:** Call `configure_bid` on the `cl-proposal-team` MCP server with the funder
type and allocation. Do not hardcode percentages or dollar ranges here.

---

## Phase 3: Funder-Type Customization

See `templates/` for proposal structure and language by funder type:
- WIOA: job placements, compliance, WIOA planning cycle, train-the-trainer
- State EDO/Appropriation: regional competitive positioning, employer attraction, economic impact
- Federal/CHIPS: replicable federal model, multi-state expansion, federal mandate documentation
- Foundation: community impact, sustainability, systemic change, capacity building

---

## Gail Proposal Types

For any org with ICP = Gail and Proposal Flag = TRUE.

**Data sources for all Gail proposals:**
- Cluster signal: pull from Notion Intelligence Inbox
- Gail org record: pull from Notion Organizations DB (sector, territory, cluster exposure, revenue path notes)
- Proof points: pull from Notion Proof Points DB
- Output flag: set "Ready for Marvin Review" = TRUE on deal record
- Do not send — Marvin approves all Gail proposals

**Type 1 — Implementation Proposal:** Use when Gail's org can serve as the implementation vehicle for a cluster-funded program. Sections: cluster signal + funding window, Gail org mandate + track record, Marvin + Mark implementation infrastructure, THINK Strategist delivery team, outcomes + reporting, fee structure.

**Type 2 — Training Program Proposal:** Use when Gail's org would host a THINK Strategist reskilling program. Sections: workforce gap tied to cluster signal, THINK Strategist certification program overview, Crystal proof points (named results), delivery timeline + cohort structure, fee structure.

---

## Notion Updates After Proposal

```
UPDATE "Deals Pipeline"
WHERE ID = [Deal ID]
SET:
- Status = "In Review"
- "Proposal Draft" = [Attach proposal document]
- "Ready for User Review" = TRUE
- "Revenue Tier" = [Stage 3 Execution (Gail Type 1) | Training (Gail Type 2) | existing value]
- Notes = "Proposal ready for user review. Key questions: [Questions for feedback]"
```

---

## Approval notification

After updating the Deal record to "In Review", post to Google Chat via Zapier MCP `google_chat_create_message` with the button:

```
text:       "BLAIR -- PROPOSAL PENDING APPROVAL
Item: [Deal Name] proposal -- [Funder Type]
Deadline: [proposal submission deadline or 'no hard deadline']

Proposal attached to Deal record: [Notion deal URL]
Bid: $[amount] | Funder: [funder name] | Close date: [date]

Reply GO to approve submission / HOLD to pause / EDIT [notes] to request changes.
Or email sarah@compoundleverage.com with: BLAIR GO [deal name]"
buttonText: "Reply to Sarah"
buttonUrl:  "[Agents/sarah/config.json > approvals.gchat_dm_url]"
```

Also log to `Logs/pending-approvals.log`:
```
[timestamp] | blair | proposal-[deal-slug] | PENDING | [Deal Name] proposal ready, funder [name], deadline [date]
```

Blair does not send proposals autonomously. Sarah routes Marvin's reply to Blair per `Skills/command-check.md`. On GO: update Deal status to "Submitted" and note the approval in the record.

## Execution Cadence

- Triggered by Deal status = "Proposal Stage"
- Review cycle same day if possible
- User approval gate before any send
