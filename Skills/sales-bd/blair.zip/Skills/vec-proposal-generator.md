# VEC Proposal Generator

## Purpose
Generate a customized proposal for VEC (or analogous client configured on this skill) using Blair's standard pitch-dev workflow with VEC-specific client context pre-loaded. Reduces setup time for repeat clients — client context is embedded in this skill, not re-sourced each time.

## VEC Client Context (configure per engagement)
- Org type, mission, and service footprint
- Prior awards and demonstrated track record
- Key differentiators vs. competing orgs
- Preferred proposal tone (mission-driven vs. technical vs. outcomes-forward)
- Relationship with the funder (new / existing / warm)

## Proposal Types Handled
Same as Blair's standard scope:
- Institutional funder proposals
- Foundation grant applications
- MBDA and SBA program applications
- Gail-profile custom proposals

For commercial RFPs, government contracting responses, or partnership proposals → route to Maya's team.

## Process
1. Load VEC client context from this skill
2. Load the opportunity record from vec-contract-opportunity-finder.md (or from Deals Pipeline)
3. Run Blair's pitch-dev/workflow.md with VEC context pre-populated
4. 9-section proposal output, funder-type customized
5. Route through Blair's deliver.md for Marvin GO and email delivery

## Output
Proposal following Blair's standard output format:
- Google Drive: `clients/vec/proposals/{opportunity-slug}-{date}.pdf`
- Delivered via Zapier HTML email on Marvin GO
