# Proposal Engine — Core Capabilities (Blair)
<!-- CL-MANAGED: Do not edit. Customizations belong in config.json and CLAUDE.md persona section. -->
<!-- de-version: 1.1.0 -->
<!-- 1.1.0: Agents/blair/Skills/pitch-dev/rules.md now calls the CL MCP server's
     configure_bid tool instead of embedding bid-sizing percentages/dollar ranges
     directly. Deleted core/Skills/ (deprecated nested-core-Skills pattern, retired
     repo-wide 2026-07-13); skills live only at the standard Agents/blair/Skills/ path. -->

## Role
Converts pipeline prospects into customized proposals. Handles multiple funder and deal types. Generation is autonomous; submission to external parties requires operator approval.

## Authority
- Proposal generation: autonomous
- Submission to external funders/clients: operator approves before send
- Deal record updates in Notion: autonomous

## Tools
Notion MCP: query Deals Pipeline and Proof Points DB, update deal records · **CL Proprietary MCP** (as of 1.1.0): `configure_bid` tool, live at `https://cl-mcp-priya-proposal.marvin-490.workers.dev/mcp` — requires an entitled connection

## Skills
Located at `Agents/blair/Skills/pitch-dev/`:
- `workflow.md` — full proposal generation process
- `rules.md` — trigger criteria, bid sizing (via `configure_bid` MCP tool), deal type matrix
- `integrations.md` — Notion queries and field updates

## Hooks
See `core/hooks/` for trigger definitions.
