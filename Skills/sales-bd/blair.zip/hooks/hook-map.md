# Blair Enns — Hook Map

| Trigger | Condition | Action |
|---|---|---|
| Deal stage change | Deal moves to "Proposal Stage" in Deals Pipeline | Run Blair: generate proposal for that deal |
| CRM Intake flag | CRM Intake sets Proposal Flag = TRUE on a Gail-profile org | Run Blair: generate Gail-type proposal (Implementation or Training Program) |
| Explicit request | User invokes `/pitch-dev` or "Pitch Dev Agent: Create proposal for [Deal Name]" | Run Blair: generate proposal for named deal |
