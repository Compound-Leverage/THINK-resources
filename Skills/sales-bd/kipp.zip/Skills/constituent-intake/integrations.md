# Kipp — Constituent Intake Enrichment

Runs after field extraction (Step 2a), before department mapping (Step 2b). Uses Scrape Creators to fill profile gaps and sharpen the fit assessment with verified data rather than self-reported form fields.

## Tools

| Tool | Use when |
|------|----------|
| `linkedin_profile` | Contact name + email known — pull title, current org, tenure, bio |
| `linkedin_company` | Business name known — pull headcount, industry, founding year, description |
| `linkedin_company_posts` | Business found on LinkedIn — scan last 5-10 posts for workflow, hiring, systems signals |
| `google_search` | LinkedIn lookup returns nothing — search `"[name]" "[business]"` for any public profile |

## Enrichment Sequence

### Step 1 — Contact lookup
Search `linkedin_profile` using the submitted name + business name.

Pull:
- Current title and org
- Tenure at current org
- Bio summary (indicators of seniority, decision-making authority)

If no LinkedIn result: `google_search` for `"[name]" "[business name]" title` — extract title from any public source.

### Step 2 — Company lookup
Search `linkedin_company` using the submitted business name.

Pull:
- Employee headcount
- Industry
- Founded year
- HQ location

### Step 3 — Company signals (if headcount > 10)
`linkedin_company_posts` — last 5-10 posts.

Scan for:
- Hiring posts → staff overload signal (adds to complexity score)
- Workflow or ops language → confirms pain point is real
- Systems or tools mentioned → cross-reference against `systems_involved` from form
- Grant or funding mentions → potential ICP signal for Chet to follow up

### Step 4 — Re-evaluate with enriched data

After enrichment, revisit the fit gates in Step 2e with the richer context:

| Enriched signal | How it affects assessment |
|---|---|
| Title is VP/Director/C-suite | Decision-maker confirmed — no escalation needed |
| Title is coordinator/assistant | Flag for Marvin — may not have authority to buy |
| Headcount < 5 | Lightweight org — consider Standard complexity floor |
| Headcount > 50 | Larger org — consider Advanced complexity floor |
| Company posts show active hiring | Hours signal likely real — supports complexity tier |
| Company posts show grant pursuit | Flag for Chet — potential capital event in pipeline |

### Step 5 — Write enrichment to handoff block

Add to the Sarah handoff:
```
ENRICHED PROFILE:
- Title: [title] at [org] ([tenure])
- Org size: [headcount] employees · [industry]
- Decision-maker: [YES / FLAG — coordinator-level]
- Signals: [1-2 line summary of LinkedIn post findings, if any]
- Enriched via: [LinkedIn / Google / Not found]
```

## Fallback

If both LinkedIn and Google return nothing, note `Enrichment: not found` in the handoff and proceed with form data only. Do not block the workflow on a failed enrichment.

## Credit check

Run `v1_account_credit_balance` at the start of each intake sweep. If balance < 10, skip enrichment for all submissions in that run and log a low-credit warning to Google Chat.
