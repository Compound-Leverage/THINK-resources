# Constituent Intake — Rules

## What Kipp does NOT do

- No Hunter.io lookup on constituents. This is not a prospecting record — the person came to us.
- No ICP scoring (Crystal/Gail/Mark). Constituents are already engaged.
- No Clay enrichment for constituent intake records.

## Pricing rules

- This is a one-time fee, not a subscription. Setup is baked in. No line items.
- Pricing IS calculated internally by Kipp and included in the Marvin-facing brief.
- Pricing is NOT included in the client-facing spec email Sarah sends. It is confirmed on the intake call.
- Always show the one-time fee as a single dollar amount — never a range, never monthly.
- If complexity tier = Principal: do not calculate. Write "Custom engagement — flag for Marvin."
- If only one department applies at Standard complexity: note this is the floor. The intake call may surface additional departments.

## Department selection constraints

- Select all departments that match. Minimum 1, no maximum.
- If problem spans 3+ departments: flag in the handoff that the client may be a bundle candidate (`calculate_strategist_pricing` applies the full-bundle rate automatically at 3+ departments).
- Do not assign a department speculatively. Only assign if the intake data clearly describes that type of work.

## Fit assessment rules

- All three gates must pass for QUALIFIED.
- One gate fail = FLAG FOR MARVIN. Still invoke Sarah. Include the failed gate clearly in the brief.
- Two or more gates fail = NOT A FIT. Do not invoke Sarah. Create Notion record with Status: Not a Fit. @mention Marvin.
- Never mark a record Not a Fit without stating which gates failed and why.

## Sarah sub-agent rules

- Kipp hands off a structured block. Sarah does not re-analyze the problem.
- If Sarah cannot create the Gmail draft (MCP unavailable): Sarah logs the failure and Kipp marks the record Status: "Sarah Failed — Manual Review."
- No em dashes in any copy.
- The client-facing email must NOT mention pricing, subscription terms, or contract language.
- The Marvin brief MUST include departments, complexity tier, starting price, hours context, and fit verdict.

## Record handling

- Process in order of submission date — oldest first.
- Never reprocess a thread already labeled `intake-processed`.
- If the same email appears twice (duplicate submission): process both threads, note the duplicate in the Notion task.
