# Constituent Intake — Schema

## Gmail Data Source

**Search query:** `from:noreply@formspree.io subject:"New submission from Strategist Program" -label:intake-processed`

**Processed label:** `intake-processed` — applied via `mcp__claude_ai_Gmail__label_message` after Notion write succeeds.

---

## Notion Database

**Deals Pipeline ID:** `789edd2b-162d-479b-aac6-06e6fdd1a04d`

### Fields written on intake

| Field | Type | Value |
|---|---|---|
| Deal (title) | title | "[name] — [business name]" |
| Source | select | Constituent Intake |
| Status | select | Processed / Not a Fit / Sarah Failed — Manual Review |
| Connection Source | rich_text | from form |
| Departments | multi_select | Operations / Fulfillment / Sales / Marketing / Engineering |
| Complexity Tier | select | Standard / Advanced / Expert / Principal |
| Starting Price | rich_text | "$X/month" or "Custom" |
| Submitted Date | date | from email header |

---

## Pricing Reference

### Model: one-time fee, setup baked in

The Strategist Program is a one-time charge. The client self-manages after setup. No ongoing subscription.

Call `calculate_strategist_pricing` (CL MCP server) with the selected departments and
complexity tier. It returns the monthly equivalent and one-time fee. Do not hardcode
department rates, the complexity multiplier, or the bundle threshold here — they change
server-side without notice to this file. Principal complexity is always custom-quoted;
the tool returns a warning instead of a figure, flag for Marvin.

---

## Marvin User ID (for @mention)

`1e84ee83-25c6-4ac3-a3c9-da439bd9a30c`

## Log Path

`Logs/kipp-intake/YYYY-MM-DD.log`
