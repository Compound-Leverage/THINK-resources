# Spec Email Template

**From:** marvin@compoundleverage.com
**To:** [client email]
**CC:** sarah@compoundleverage.com
**Subject:** Here is the team we would build for [Business Name]
**Reply-To:** marvin@compoundleverage.com

---

## HTML Template

```html
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background-color:#F9FAFB;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">

<table width="600" cellpadding="0" cellspacing="0" border="0" align="center"
       style="max-width:600px;width:100%;margin:40px auto;background-color:#ffffff;">

  <!-- HEADER -->
  <tr>
    <td style="padding:32px 40px 24px 40px;border-left:4px solid #6944BA;border-bottom:1px solid #E5E7EB;">
      <p style="margin:0 0 6px 0;font-size:12px;font-weight:600;letter-spacing:0.08em;color:#6944BA;text-transform:uppercase;">Strategist Program Proposal</p>
      <h1 style="margin:0;font-size:24px;font-weight:700;color:#111827;line-height:1.2;">[Business Name]</h1>
      <p style="margin:8px 0 0 0;font-size:14px;color:#6B7280;">Compound Leverage &middot; [Month Year]</p>
    </td>
  </tr>

  <!-- INTRO -->
  <tr>
    <td style="padding:32px 40px 0 40px;">
      <p style="margin:0 0 16px 0;font-size:15px;color:#374151;line-height:1.6;">[First name],</p>
      <p style="margin:0 0 16px 0;font-size:15px;color:#374151;line-height:1.6;">
        My team reviewed your submission. Two of my Digital Employees analyzed your workflow
        and put this proposal together.
      </p>
    </td>
  </tr>

  <!-- DE TEAM LABEL -->
  <tr>
    <td style="padding:24px 40px 12px 40px;">
      <p style="margin:0;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:#6944BA;">The team that reviewed your submission</p>
    </td>
  </tr>

  <!-- DE TEAM TABLE -->
  <tr>
    <td style="padding:0 40px;">
      <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
          <td style="padding:10px 14px;background-color:#F9FAFB;border-bottom:2px solid #E5E7EB;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.06em;color:#111827;">Digital Employee</td>
          <td style="padding:10px 14px;background-color:#F9FAFB;border-bottom:2px solid #E5E7EB;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.06em;color:#111827;">Department</td>
          <td style="padding:10px 14px;background-color:#F9FAFB;border-bottom:2px solid #E5E7EB;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.06em;color:#111827;">What they will own for you</td>
        </tr>
        <!-- Row 1 -->
        <tr>
          <td style="padding:12px 14px;background-color:#ffffff;border-bottom:1px solid #E5E7EB;font-size:14px;"><span style="color:#6944BA;font-weight:600;">[DE Name]</span></td>
          <td style="padding:12px 14px;background-color:#ffffff;border-bottom:1px solid #E5E7EB;font-size:14px;color:#6B7280;">[Department]</td>
          <td style="padding:12px 14px;background-color:#ffffff;border-bottom:1px solid #E5E7EB;font-size:14px;color:#374151;">[Specific tasks for this client]</td>
        </tr>
        <!-- Row 2 -->
        <tr>
          <td style="padding:12px 14px;background-color:#F9FAFB;border-bottom:1px solid #E5E7EB;font-size:14px;"><span style="color:#6944BA;font-weight:600;">[DE Name]</span></td>
          <td style="padding:12px 14px;background-color:#F9FAFB;border-bottom:1px solid #E5E7EB;font-size:14px;color:#6B7280;">[Department]</td>
          <td style="padding:12px 14px;background-color:#F9FAFB;border-bottom:1px solid #E5E7EB;font-size:14px;color:#374151;">[Specific tasks for this client]</td>
        </tr>
      </table>
    </td>
  </tr>

  <!-- SYSTEMS NOTE -->
  <tr>
    <td style="padding:12px 40px 32px 40px;">
      <p style="margin:0;font-size:13px;color:#6B7280;line-height:1.6;">Both DEs work inside the tools you already use. No new software. No migration.</p>
    </td>
  </tr>

  <!-- COST LABEL -->
  <tr>
    <td style="padding:0 40px 12px 40px;">
      <p style="margin:0;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:#6944BA;">Your Investment</p>
    </td>
  </tr>

  <!-- COST TABLE -->
  <tr>
    <td style="padding:0 40px;">
      <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
          <td style="padding:12px 16px;background-color:#F9FAFB;border-bottom:1px solid #E5E7EB;font-size:14px;color:#374151;">Current annual cost ([N] hrs/week)</td>
          <td style="padding:12px 16px;background-color:#F9FAFB;border-bottom:1px solid #E5E7EB;font-size:14px;color:#374151;text-align:right;">$[annual_staff_cost]</td>
        </tr>
        <tr>
          <td style="padding:12px 16px;background-color:#ffffff;border-bottom:1px solid #E5E7EB;font-size:14px;color:#374151;">Strategist Program</td>
          <td style="padding:12px 16px;background-color:#ffffff;border-bottom:1px solid #E5E7EB;font-size:14px;color:#374151;text-align:right;">$[one_time_fee]</td>
        </tr>
        <!-- Omit grant row if no grant applies -->
        <tr>
          <td style="padding:12px 16px;background-color:#F9FAFB;border-bottom:1px solid #E5E7EB;font-size:14px;color:#374151;">Grant — strategist labor</td>
          <td style="padding:12px 16px;background-color:#F9FAFB;border-bottom:1px solid #E5E7EB;font-size:14px;font-weight:600;color:#6944BA;text-align:right;">-$[grant_amount]</td>
        </tr>
        <tr>
          <td style="padding:14px 16px;border-top:2px solid #111827;border-left:3px solid #6944BA;font-size:15px;font-weight:700;color:#111827;">Your cost</td>
          <td style="padding:14px 16px;border-top:2px solid #111827;font-size:18px;font-weight:700;color:#111827;text-align:right;">$[net_cost]</td>
        </tr>
      </table>
    </td>
  </tr>

  <!-- NEXT STEPS LABEL -->
  <tr>
    <td style="padding:32px 40px 12px 40px;">
      <p style="margin:0;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:#6944BA;">How we move forward</p>
    </td>
  </tr>

  <!-- NEXT STEPS TABLE -->
  <tr>
    <td style="padding:0 40px;">
      <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
          <td style="padding:12px 14px;background-color:#F9FAFB;border-bottom:1px solid #E5E7EB;font-size:13px;font-weight:700;color:#6944BA;vertical-align:top;width:28px;">01</td>
          <td style="padding:12px 14px;background-color:#F9FAFB;border-bottom:1px solid #E5E7EB;font-size:14px;color:#374151;vertical-align:top;">Reply <strong style="color:#111827;">Approve</strong> to this email</td>
        </tr>
        <tr>
          <td style="padding:12px 14px;background-color:#ffffff;border-bottom:1px solid #E5E7EB;font-size:13px;font-weight:700;color:#6944BA;vertical-align:top;width:28px;">02</td>
          <td style="padding:12px 14px;background-color:#ffffff;border-bottom:1px solid #E5E7EB;font-size:14px;color:#374151;vertical-align:top;">We send the agreement and first invoice for <strong style="color:#111827;">$[half_upfront]</strong></td>
        </tr>
        <tr>
          <td style="padding:12px 14px;background-color:#F9FAFB;border-bottom:1px solid #E5E7EB;font-size:13px;font-weight:700;color:#6944BA;vertical-align:top;width:28px;">03</td>
          <td style="padding:12px 14px;background-color:#F9FAFB;border-bottom:1px solid #E5E7EB;font-size:14px;color:#374151;vertical-align:top;">Configuration begins — target start <strong style="color:#111827;">[Start Month]</strong></td>
        </tr>
        <tr>
          <td style="padding:12px 14px;background-color:#ffffff;font-size:13px;font-weight:700;color:#6944BA;vertical-align:top;width:28px;">04</td>
          <td style="padding:12px 14px;background-color:#ffffff;font-size:14px;color:#374151;vertical-align:top;">Final invoice for <strong style="color:#111827;">$[half_completion]</strong> due at handoff</td>
        </tr>
      </table>
    </td>
  </tr>

  <!-- APPROVE BUTTON -->
  <tr>
    <td style="padding:32px 40px 40px 40px;">
      <table cellpadding="0" cellspacing="0" border="0">
        <tr>
          <td bgcolor="#6944BA" style="background-color:#6944BA;border-radius:6px;text-align:center;padding:13px 32px;">
            <a href="mailto:marvin@compoundleverage.com?subject=Approve%20-%20[BUSINESS_NAME_ENCODED]&body=I%20approve%20the%20proposal."
               style="display:inline-block;font-size:15px;font-weight:600;color:#ffffff;text-decoration:none;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">
              Reply Approve
            </a>
          </td>
        </tr>
      </table>
      <p style="margin:12px 0 0 0;font-size:12px;color:#9CA3AF;">Or reply to this email with the word Approve and we will take it from there.</p>
    </td>
  </tr>

  <!-- SIGNATURE -->
  <tr>
    <td style="padding:0 40px 40px 40px;border-top:1px solid #E5E7EB;">
      <p style="margin:24px 0 4px 0;font-size:14px;font-weight:600;color:#111827;">Marvin Harris</p>
      <p style="margin:0;font-size:13px;color:#6B7280;">Compound Leverage</p>
    </td>
  </tr>

  <!-- MARVIN BRIEF -->
  <tr>
    <td style="padding:0 40px 40px 40px;border-top:3px dashed #E5E7EB;">
      <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
          <td style="padding:14px 16px;background-color:#F9FAFB;">
            <p style="margin:0 0 10px 0;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;color:#6B7280;">Internal — Delete Before Send</p>
            <p style="margin:0;font-size:12px;color:#6B7280;line-height:1.8;">
              Notion: <a href="[NOTION_RECORD_URL]" style="color:#6944BA;">[Client Name] — Deals Pipeline</a><br>
              Departments: [list] &nbsp;|&nbsp; Complexity: [tier] &nbsp;|&nbsp; One-time: $[fee] &nbsp;|&nbsp; Net: $[net_cost]<br>
              Payment: $[half_upfront] upfront / $[half_completion] at completion<br>
              Queue: [Start Month]<br>
              Grant: $[grant_amount] covers strategist labor — confirmed at intake<br>
              Email flag: [any issues with submitted address]<br>
              Fit: [QUALIFIED / FLAG — reason]
            </p>
          </td>
        </tr>
      </table>
    </td>
  </tr>

</table>

</body>
</html>
```

---

## Variable reference

| Variable | Source |
|---|---|
| [Business Name] | business_name from intake |
| [First name] | first word of name field |
| [Month Year] | current month + year at send time |
| [DE Name] / [Department] / [tasks] | Kipp department matching — tasks specific to this client |
| [N] hrs/week | worker_hours_per_week |
| [annual_staff_cost], [one_time_fee], [grant_amount], [net_cost], [half_upfront], [half_completion] | from `calculate_net_cost` (CL MCP server), called with the one-time fee, client type, and worker hours/week |
| [Start Month] | next available month in configuration queue |
| [BUSINESS_NAME_ENCODED] | URL-encoded business name for mailto subject |
| [NOTION_RECORD_URL] | URL returned when Kipp creates the Notion record |

Omit the grant row if no grant applies.

---

## Gmail-safe rules (per Jenny)

- Table-based layout only. No div, flex, grid, float, position.
- All styles inline. No style block.
- Borders on td only, never tr.
- No box-shadow, text-shadow, background-image, overflow:hidden.
- border-radius safe on td and a only.
- Button: td with background-color wrapping an a with display:inline-block and padding only.
- margin on table: use align="center" attribute for centering.
