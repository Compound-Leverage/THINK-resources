# Constituent Intake — Workflow

**Agent:** Kipp Bodnar (Contact Enrichment and ICP Classifier)
**Sub-agent:** Sarah Grant (BD Execution)
**Trigger:** Daily queue sweep — runs after standard crm-intake pass

---

## When This Runs

Any time a new Formspree notification email has arrived in Marvin's inbox for the strategist intake form that has not yet been processed.

---

## Step 1: Fetch the queue

Use Gmail MCP `mcp__claude_ai_Gmail__search_threads` to search Marvin's inbox.

Search query: `from:noreply@formspree.io subject:"New submission from Strategist Program" -label:intake-processed`

Formspree sends one email per submission with all field values in the body. If no results: log the empty run and stop.

---

## Step 2: For each submission — read, evaluate, price

### 2a. Extract fields

Use `mcp__claude_ai_Gmail__get_thread` on each result. Formspree lists each field as a label-value pair. Extract:

| Field | Form name |
|---|---|
| Name | name |
| Email | email |
| Business name | business_name |
| Connection source | connection_source |
| Problem description | workflow |
| Current process steps | workflow_steps |
| Tools and systems | systems_involved |
| Has current worker | has_current_worker |
| Staff role | staff_role |
| Number of people | worker_headcount |
| Hours per week | worker_hours_per_week |
| Uncovered work | uncovered_work |

---

### 2b. Enrich with Scrape Creators

Run the enrichment sequence in `integrations.md` before department mapping:
1. `linkedin_profile` on the contact — pull title, org, tenure
2. `linkedin_company` on the business — pull headcount, industry
3. `linkedin_company_posts` if headcount > 10 — scan for hiring, workflow, grant signals
4. Re-evaluate fit gates and complexity tier with enriched data
5. Add enriched profile block to the Sarah handoff

Skip enrichment only if credit balance < 10 (checked at sweep start).

---

### 2c. Map to execution departments

Match the problem to one or more departments: Operations (scheduling, intake, email
follow-up, data entry, tracking, CRM), Fulfillment (onboarding, paperwork, reconciliation,
expansion playbooks), Sales (pipeline monitoring, proposal writing, outreach, BD research),
Marketing (newsletter, social, video scripts, content calendar, SEO, distribution), or
Engineering (infrastructure monitoring, integration management). Select all that apply.

For intelligence-primary problems (grant scanning, market monitoring, signal detection),
this is an intelligence-tier case instead — flag it as such for Step 2e, which prices it
by DE count rather than department.

---

### 2d. Score complexity

Assign a complexity tier based on the submission data.

**Scoring inputs:**

| Signal | Low (0) | Medium (1) | High (2) |
|---|---|---|---|
| Hours per week | Under 10 | 10-40 | 40+ |
| People currently on it | 1 | 2-3 | 4+ |
| Systems involved (count) | 1-2 | 3-4 | 5+ |
| Workflow steps / handoffs | 1-2 steps | 3-4 steps | 5+ steps or conditional logic |

**Total score → tier:**

| Score | Tier | Multiplier | Description |
|---|---|---|---|
| 0-2 | Standard | 1.0x | Repeatable tasks, clear inputs, defined outputs |
| 3-5 | Advanced | 1.2x | Multiple data sources, conditional logic, some custom integrations |
| 6-7 | Expert | 1.4x | Complex workflows, API integrations, sector-specific configuration |
| 8 | Principal | Custom | Enterprise-grade, multi-system, compliance-sensitive |

---

### 2e. Calculate one-time fee

The Strategist Program is a one-time charge. Client self-manages after setup.

Call `calculate_strategist_pricing` (CL MCP server) with the selected departments and
complexity tier for a department-based case, or `calculate_intelligence_tier_pricing`
with the DE count and complexity tier for an intelligence-primary case. Show the
returned one-time fee as a single number — setup is baked in, no line items.

If tier = Principal: the tool returns a warning instead of a figure. Write
"Custom — flag for Marvin," do not calculate manually.

---

### 2f. Fit assessment

Three gates. All must pass for QUALIFIED.

| Gate | Pass | Fail |
|---|---|---|
| Tasks are AI-executable | Email, scheduling, research, data entry, doc creation, monitoring | Physical presence required, licensed professional judgment required |
| Digital infrastructure | At least email + one shared system (Sheets, CRM, calendar, Slack) | No digital systems — fully analog |
| Clear pain point | Hours wasted, missed deadlines, explicit bottleneck, staff overload | Vague or exploratory only |

- All pass: **QUALIFIED**
- One fail: **FLAG FOR MARVIN** — include the failed gate in the handoff note
- Two+ fail: **NOT A FIT** — skip Sarah, create Notion record with Status: Not a Fit, @mention Marvin

---

## Step 3: Invoke Sarah as sub-agent

For QUALIFIED and FLAG FOR MARVIN records only.

Pass Sarah this handoff block:

```
INTAKE TYPE: constituent-spec
CLIENT: [name], [business]
EMAIL: [email]
CONNECTION: [connection_source]
PROBLEM: [workflow, verbatim]
WORKFLOW STEPS: [workflow_steps, verbatim]
SYSTEMS: [systems_involved]
DEPARTMENTS: [list of matched departments]
COMPLEXITY: [tier] ([multiplier]x)
STARTING PRICE: $[calculated price]/month
HOURS CONTEXT: [worker_hours_per_week] hours/week currently spent
FIT STATUS: [QUALIFIED or FLAG FOR MARVIN — include flag reason if applicable]
GMAIL ACTION: create_draft to Marvin's Gmail
NOTION ACTION: child page in Deals Pipeline record [ID], title: "Review and send spec to [client name]"
MENTION: 1e84ee83-25c6-4ac3-a3c9-da439bd9a30c
```

Sarah will:
1. Draft the client-facing spec email using `templates/spec-email.md`
   - Names the departments assigned and what each one owns
   - Does NOT mention pricing (pricing is confirmed on the intake call)
   - CTA: book a 30-minute intake session
2. Draft a separate Marvin-facing brief using `templates/marvin-brief.md`
   - Includes full analysis: departments, complexity tier, starting price, fit assessment
   - Includes the flag reason if applicable
3. Create one Gmail draft via `mcp__claude_ai_Gmail__create_draft` that contains both (client email first, Marvin brief below a divider)
4. Create a child page in the Deals Pipeline record: "Review and send spec to [client name]"
5. @mention Marvin in a comment on the record

---

## Step 4: Write to Notion and mark email processed

After Sarah confirms completion:

**4a. Create Notion record** using `notion-create-pages` in Deals Pipeline (`789edd2b`):

| Field | Value |
|---|---|
| Deal (title) | [name] — [business name] |
| Source | Constituent Intake |
| Status | Processed (or Not a Fit) |
| Connection Source | [connection_source] |
| Departments | [list] |
| Complexity Tier | [tier] |
| Starting Price | $[price]/month |
| Submitted Date | [date from email header] |

**4b. Apply Gmail label** using `mcp__claude_ai_Gmail__label_message`:
- Label: `intake-processed`
- This removes the thread from all future queue sweeps.

---

## Step 5: Log the run

Append to `Logs/kipp-intake/YYYY-MM-DD.log`:
```
[timestamp] | kipp | constituent-intake | [N] processed | [N] not-a-fit | [names]
```

Post to Google Chat only on exception:
- Notion write failed
- Sarah sub-agent returned an error
- Queue had entries but zero were processed
