# CE-CRM-Intake — Integrations

## Hunter.io

**Domain search:**
```
GET https://api.hunter.io/v2/domain-search
Params:
  domain:   org website domain (strip https/www)
  api_key:  HUNTER_API_KEY from environment
  limit:    5
```

Seniority priority: Executive Director > President > CEO > Chief [any] > VP [any] > Director [any]

**Email verifier:**
```
GET https://api.hunter.io/v2/email-verifier
Params:
  email:    email from domain search
  api_key:  HUNTER_API_KEY from environment
```
Accept: status = "valid" or "accept_all"
Reject: status = "invalid" → treat as not found

**Email finder (fallback):**
```
GET https://api.hunter.io/v2/email-finder
Params:
  domain:       org website domain
  first_name:   first name from web search
  last_name:    last name from web search
  api_key:      HUNTER_API_KEY from environment
```

**Rate limit:** If HTTP 429, wait 60 seconds, retry once. If retry fails: log error, skip contact creation. Notes: "Hunter.io rate limit hit — retry manually"

---

## Notion Writes

**Contacts DB record:**
```
INSERT INTO "Contacts" (170e1f64):
- Name:                [First + Last from Hunter.io]
- Title:               [Job title from Hunter.io result]
- Organization:        [Link to Organizations DB record]
- Email:               [Verified email from Hunter.io]
- Email Status:        "Verified" | "Unverified — confirm before send" | "Not found"
- ICP Profile:         Crystal | Gail | Mark
- Relationship Status: Not yet reached
- Source:              "Hunter.io"
- Date Enriched:       [Today]
```

**Organizations DB record:**
```
INSERT / UPDATE "Organizations" (2cc68799):
- Name:                    [Org name]
- Website:                 [Domain used for lookup]
- Type:                    [State Workforce Board | EDO | Foundation | Federal Agency | Other]
- ICP Profile:             Crystal | Gail | Mark
- Newsletter Funnel:       Added (Crystal) | Not Added
- Radar Brief:             Ready | Sent | Not Ready
- Proposal Flag:           Yes | No
- Partner Conv Flag:       Yes | No
- Brief Topic:             [text — Gail only]
- Estimated Missed Value:  $[amount — Gail only]
- Success Fee Potential:   High | Medium | Low (Gail only)
- Notes:                   [Engagement fee path + Proposal path + Success fee path]
```

**Deals Pipeline update (Step 2 only):**
```
UPDATE "Deals Pipeline" (789edd2b)
WHERE Status = "Prospect"
SET:
- "Institutional Decision-Maker": [Link to Contacts record]
- Notes: "Contact enriched via Hunter.io — [date]"
```
