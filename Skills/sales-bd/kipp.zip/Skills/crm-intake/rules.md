# CE-CRM-Intake — Rules

## ICP Classification

All three ICPs share one desire: find and capture opportunities I'm missing. Classify every org before it advances.

**Qualification question:** What scale are they operating at?

**CRYSTAL — Individual scale**
- Solo or small firm (1–5 people), training/consulting/speaking/workforce development
- Language: overwhelmed, missing opportunities, cold outreach not working, where do I start
- Routing: Newsletter Funnel = Added

**GAIL — Org scale**
- Workforce board, EDO, chamber, HBCU consortium, community college, nonprofit workforce org
- Programs tied to DOL, NSF, or state workforce boards
- Language: not capturing full value, finding out after the window closes, need to show more impact
- Routing: Proposal Flag = Yes, Radar Brief = Ready

**MARK — Network scale**
- Serves or controls access to a network of 20+ orgs
- Relationships with state/local funding distributors
- Language: we place people into programs, we connect orgs to funding, our members need this
- Routing: Partner Conv Flag = Yes, Radar Brief = Ready

If signals conflict or insufficient: assign closest match and flag "ICP unconfirmed — review needed"

## ICP Routing Flags

| ICP | Routing Action |
|-----|----------------|
| Crystal | Set Newsletter Funnel = Added on org and contact |
| Gail | Set Proposal Flag = Yes + Radar Brief = Ready on org |
| Mark | Set Partner Conv Flag = Yes + Radar Brief = Ready on org |

## Constraints & Rules

1. No cold outreach — this agent enriches records only; user approves before any message is sent
2. No guessed emails — only Hunter.io verified addresses or "No email found" flag
3. Confidence threshold — flag any contact with Hunter score < 70 as "Unverified — confirm before send"
4. No duplicate contacts — check name + org before every create
5. HUNTER_API_KEY from environment only — never hardcode credentials
6. Notion is source of truth — if a contact already exists, link and move on
7. Every record gets an ICP tag — no record advances without Crystal / Gail / Mark classification
8. Marvin approves all radar briefs and proposals — do not send anything autonomously
