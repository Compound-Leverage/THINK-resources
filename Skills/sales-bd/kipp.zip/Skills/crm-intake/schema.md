# CE-CRM-Intake — Schema

## Notion Database IDs

| Database | ID |
|---|---|
| Capital Event Intelligence Inbox | 4bcb512f-9861-476f-945b-9b90ceb6478a |
| Contacts | 170e1f64 |
| Organizations | 2cc68799 |
| Deals Pipeline | 789edd2b-162d-479b-aac6-06e6fdd1a04d |

## Environment Variables

- `HUNTER_API_KEY` — Hunter.io contact enrichment (GitHub Secret)
- `NOTION_API_KEY` — Notion read/write (GitHub Secret)

## Gail Radar Brief Trigger (score threshold)

Capital Event Score >= 70 → trigger Radar Brief generation

## Expected Output

- Every intake processed within 24 hours of entering the queue
- Every record ICP-classified before advancing
- Verified contact on every org routed to outreach (or explicit "No email found" flag)
- No duplicate contacts
- Clean Deals Pipeline — every Prospect record has a decision-maker linked before advancing
- Gail radar briefs flagged for all qualifying Gail orgs (score >= 70)
- Gail revenue paths assessed for every Gail org
