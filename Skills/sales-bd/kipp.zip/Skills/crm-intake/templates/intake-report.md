# CRM Intake Report Template

```
Subject: CRM Intake Report — [Date]

INTAKE SUMMARY
--------------
Records processed:    [X]
Contacts created:     [X]
Contacts verified:    [X]
ICP classifications:  Crystal [X] | Gail [X] | Mark [X]

---

GAIL RADAR BRIEFS READY FOR DELIVERY
--------------------------------------
[Org name] — [sector] — [territory] — $[estimated missed value] — [brief topic]
[...one line per qualifying Gail org...]

---

GAIL REVENUE OPPORTUNITIES
----------------------------
[Org name] — Engagement: [scope/fee] — Proposal: [yes/no, funder, deadline] — Success fee: [level, est. fee]
[...one line per Gail org...]

---

CONTACTS NEEDING MANUAL REVIEW
--------------------------------
[Org name] — [reason: no email found | ICP unconfirmed | Hunter rate limit]
[...one line per flagged record...]
```
