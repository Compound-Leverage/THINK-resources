# CE-CRM-Intake — Workflow

Kipp owns contact/org enrichment and ICP classification for records arriving via the three sources below -- Capital Event Intelligence Inbox, Funder Intel Agent Prospects, and Warm Inbound Leads. Sarah does not run enrichment; she consumes Kipp's (and Alex's, for independently-sourced/referral leads -- see `Agents/alex/CLAUDE.md`) enriched output for outreach. This boundary corrects a stale line that previously read "Superseded by Sarah" -- contradicted by Sarah's own CLAUDE.md, which claims no enrichment function, and by this file's own live daily cron (see Execution Cadence below).

---

## Trigger Sources

1. **Capital Event Intelligence Inbox** — new entries flagged for intake
2. **Funder Intel Agent Prospects** — Score 60+ orgs added to Deals Pipeline as "Prospect"
3. **Warm Inbound Leads** — referrals, conference contacts, or re-engagement records with no existing contact

---

## Step 1: Capital Event Intelligence Inbox

For each new entry (status = "New"):

**1a. Extract org website domain**
- Pull website field from the Inbox record
- Strip `https://`, `www.`, and trailing slashes
- If no website: web search "[org name] official website" to find domain

**1b. Check Contacts DB**
- Query Contacts DB: name + org combination
- If match found: skip contact lookup, link existing contact to record
- If no match: proceed to Hunter.io lookup

**1c. Hunter.io contact lookup**
- Domain search → select best contact by seniority → verify email → email-finder fallback
- If confidence score < 70: flag "Unverified email — confirm before send"
- If Hunter returns nothing: record name/title only, Notes: "No email found — manual outreach needed"
- Rate limit: if HTTP 429, wait 60 seconds, retry once

See `integrations.md` for full API call parameters.

**1d. Create Notion records + run ICP detection**
- Create/update Contacts DB record with verified contact
- Update Inbox entry status: "Intake Complete"
- Link contact to Inbox entry
- Run ICP Detection (see rules.md)
- Apply routing flags per ICP result

**1e. Clay enrichment (conditional)**

Run Clay enrichment via Clay MCP only if ICP = Gail (Done-For-You / DE Hire Team prospect).

Crystal contacts (THINK School path) do not need Clay -- email and org profile from Hunter is sufficient. Crystal leads convert through the newsletter and THINK School sequence, not through deeper company research.

For qualifying contacts, call `find-and-enrich-contacts-at-company` or `add-company-data-points`:
- Company size, headcount, LinkedIn URL
- Funding stage or recent funding events (if available)
- Recent activity signals (hiring, expansion, new leadership)
- **Grant tool stack:** does the org use Cayuse, InfoEd, SmartSimple, Pivot, Kuali Research, or similar research admin platforms? If yes, flag on the Organizations record as "Grant Tool Confirmed" -- this is a strong Gail signal and should be noted in any outreach Sarah builds
- **Grants staff ratio:** if headcount data available, estimate grants/sponsored programs staff vs. total headcount -- ratio below 1:50 signals bandwidth problem

Write enriched fields to the Contacts and Organizations Notion records. Log Clay credits used to `Logs/completions.log`.

If ICP = Gail: run Gail Radar Brief Trigger and Gail Revenue Path Assessment

---

## Step 2: Funder Intel Agent Prospects

For each new Deals Pipeline record with status = "Prospect" and no linked Contact:

**2a.** Extract org website domain from linked Organizations record (or web search)
**2b.** Check Contacts DB — link if match found, skip lookup
**2c.** Hunter.io contact lookup (same flow as Step 1c)
**2d.** Update Notion records + run ICP detection
- Create Contacts DB record
- Set "Institutional Decision-Maker" field on Deal record
- Add note: "Contact enriched via Hunter.io on [date]"
- Flag Deal as "Ready for Outreach Review" if contact verified
- Run ICP Detection, apply routing flags
- Clay enrichment: Funder Intel prospects are always Gail-profile -- run Clay enrichment (same fields as Step 1e) after ICP classification
- If ICP = Gail: run Gail Radar Brief Trigger and Gail Revenue Path Assessment

---

## Step 3: Warm Inbound Leads

For each re-engagement or inbound lead with no Contacts DB record:

**3a.** Confirm org domain (or web search)
**3b.** Check Contacts DB — update if match, skip lookup
**3c.** Hunter.io contact lookup (same flow as Step 1c)
**3d.** Create or update Notion records
- Create Contacts DB record
- Link to Organizations DB if org record exists
- Flag for user review: "Warm lead intake complete — ready for outreach routing"
- Run ICP Detection, apply routing flags
- Clay enrichment: only if ICP = Gail (same rule as Step 1e -- Crystal warm inbound does not need Clay)
- If ICP = Gail: run Gail Radar Brief Trigger and Gail Revenue Path Assessment

---

## Gail Radar Brief Trigger

Runs automatically when ICP = Gail and Capital Event Score >= 70.

1. Scope the radar — sector, territory, cluster exposure from org record
2. Identify the missed opportunity — open funding windows in their sector/territory, dollar value of gap
3. Derive the Capacity Problem: one sentence naming the specific work the open funding window creates that this org cannot staff for. Example: "Three active NSF workforce grants in their sector — no systematic process to identify or respond to sub-award opportunities."
4. Select Recommended DE from the roster based on the gap type (use the DE Match table from Chet's funder-intel rules.md)
5. Flag Notion org record: Radar Brief = Ready, Brief Topic, Estimated Missed Value, Capacity_Problem, Recommended_DE, Lane_Qualifier = 1
6. Add to report email under "Gail Radar Briefs Ready for Delivery"

---

## Gail Revenue Path Assessment

Runs automatically for every Gail-profile org after ICP classification.

- **Engagement fee path:** Active Intelligence or Execution need? Estimate scope and fee range.
- **Proposal path:** Active funding window? Funder, amount, deadline, yes/no. Set Proposal Flag.
- **Success fee path:** Cluster funding gap × 10–15% = success fee potential. Rate High/Medium/Low.
- **Placement Lane Recommendation:** Budget must be confirmed before assigning Lane 1 or Lane 3:
  - Immediate capacity gap with active window AND budget signal confirmed (active federal funding, state grant, or operating budget) → Lane 1, Managed DE — high urgency, recommend Sarah outreach this week
  - Capacity gap identified but no active window in 90 days AND budget signal confirmed → Lane 1, Managed DE — next quarter conversation
  - Large org with confirmed budget and appetite for a full system build → Lane 3, Strategist Program — route to Blair for scoping
  - Capacity gap present but no budget signal confirmed → hold; flag for Marvin with note "budget unconfirmed — verify before routing"

Add to report email under "Gail Revenue Opportunities".

---

## Execution Cadence

- Daily queue sweep — process all Step 1 (Inbox) and Step 2 (Funder Intel) entries
- On-demand — triggered by user for warm inbound leads (Step 3)
- Weekly audit — flag any Prospect-stage deals still missing decision-maker or ICP tag

## Notification rule

Log every run to `Logs/completions.log`:
```
[timestamp] | kipp | crm-intake | COMPLETE | [N] contacts enriched, [N] ICPs classified, [N] exceptions
```

Post ONE Google Chat summary card per run via Bash curl to the CE cluster space webhook. Include: records processed, contacts created/verified, ICP breakdown (Crystal/Gail/Mark counts), and any exception flags inline.

Exceptions to call out in the card (not as separate messages):
- Clay/Hunter confidence issue on 3+ records
- ICP classification unresolvable
- Zero records when queue had entries

One card per run, always. Do not post separate exception messages.
