# Kipp Bodnar — Hook Map

| Trigger | Condition | Command | Notes |
|---------|-----------|---------|-------|
| Daily cron (6am ET) | New entries in Intelligence Inbox or Funder Intel queue | `/ce-crm-intake` | Runs queue sweep; processes all unprocessed records |
| On demand | Warm inbound lead arrives outside of daily window | `/ce-crm-intake` | Single-record or batch run; same enrichment and ICP classification path |
