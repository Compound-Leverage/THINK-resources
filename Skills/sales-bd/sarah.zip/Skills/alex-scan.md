# Skill: Alex Scan

Signal detection and lead enrichment against a parsed client profile. Called by inbound-response (step 4) when a new config arrives. Also invoked for proactive BD research on any profile.

## Input

Parsed profile fields passed by the calling skill:
- `org_name`: client organization name
- `service_lines`: what they offer or seek
- `geography`: target territory
- `icps`: list with `label` and `signal` per ICP
- `scoring`: label, threshold, and scoring factors

## Execution

Run the following searches for each ICP in the profile. Match sources to the ICP's signal type.

### Workforce / Training / Nonprofit signals
1. `site:linkedin.com "[signal_keyword]" "[geography]" [vertical] 2026` -- find practitioners publicly expressing the signal
2. Grants.gov advanced search -- awards in the org's geography and CFDA category (workforce, education, workforce dev)
3. LinkedIn hiring signals -- companies posting for roles matching the service line (training manager, workforce consultant, L&D)
4. WebFetch org websites found in Notion Deals Pipeline (ICP = Gail) for staff directory pages -- surface Crystal-profile individuals

### Real estate / Legal filing signals
1. PACER -- Ch.7 and Ch.13 filings for target county
2. County clerk lis pendens index for target geography
3. Tax delinquency roll (county assessor) for matching property class

### Startup / VC signals
1. Crunchbase recent funding rounds -- filter by vertical and geography matching the ICP signal
2. LinkedIn company pages -- recent headcount growth or new leadership hire as engagement entry point
3. Job postings for AI, ops, or workforce roles at companies in target vertical

### General enrichment (all verticals)

For each candidate lead surface in the step above:

1. Confirm ICP label: size, vertical, geography match
2. Identify decision-maker: title that maps to the service line (training lead, workforce director, co-founder, operations head)
3. Email: Hunter.io domain search. If not findable, leave blank and note LinkedIn URL
4. Flag any urgency: filing age under 14 days, award window closing, recent funding (90 days)

## Output

Structured lead queue -- minimum 5 leads per ICP:

```
- org_name:
  contact_name:
  contact_title:
  email:           # verified or blank
  linkedin_url:    # required if email is blank
  icp_label:       # matches profile ICP label
  signal:          # what triggered this lead
  signal_date:
  score:           # 0-10 per the profile's scoring factors
  score_notes:     # one-line rationale
  urgency_flag:    # leave empty if none; render red in email if set
```

Pass this queue to the calling skill for scoring, HTML email construction, and send.

## Rules
- Minimum 5 qualified leads per ICP. If fewer than 5: note low yield, do not pad with unqualified results.
- No guessed emails -- Hunter.io verified only, otherwise blank
- One decision-maker contact per org (not all staff)
- Urgency flags render red in the HTML output email
