# Skill: Campaign Manager

Reads all active campaign records from Notion, reports who was added, what stage each contact is at, what actions are due today, and surfaces responses. Runs weekdays and on demand.

**Invoke:** `/campaign-status` or `"Campaign Manager: daily check"`  
**Run cadence:** Weekdays 8am ET via GHA (`sarah-campaign-manager.yml`) -- not literal daily, this skill autonomously sends emails and outreach never runs Saturday. On demand any time.  
**Output:** Google Chat card + `output/campaigns/campaign-status-[YYYY-MM-DD].md`

**Send method:** Client-facing (cold/warm outreach to real prospects) -- identity matters, so this is tiered, not Resend-only:
- **Tier 1 -- GWS (primary).** Sends as the real `sarah@compoundleverage.com`. Build with `email.mime.text.MIMEText` + `email.header.Header(subject, "utf-8")`, then `gws gmail users messages send`.
- **Tier 2 -- Zapier (fallback if GWS fails).** Also the real address. `mcp__claude_ai_Zapier__gmail_send_email`.
- **Tier 3 -- Resend (last resort only).** `python3 Scripts/sarah-send-email.py --to <recipient> --cc marvin@compoundleverage.com --subject '<subject>' --html-file '<path>'`. `RESEND_API_KEY` is in the environment. Sends from `sarah@send.compoundleverage.com` -- a lookalike, not her real address, since that's the only domain Resend has verified -- with reply-to set to the real `sarah@compoundleverage.com` so replies still land correctly. Only use this tier when Tier 1 and Tier 2 both fail.

---

## Active Campaigns

Read dynamically, not a fixed list: query Campaign Hub where Status = Active. This always includes the three core campaigns below (Lead Quota Gate and stage definitions still apply specifically to `managed-de-placement`), plus any fan-out campaigns Scott Brinker (Campaign Builder, `Agents/scott/Skills/campaign-builder.md`) created from a Cassie Qualified card -- those appear in the daily sweep automatically, no manual table edit needed here.

Core campaigns (still explicitly named because their quota/ICP rules are hardcoded elsewhere in this skill):

| Campaign ID | Name | ICP | Goal | Lead Quota | Owner |
|---|---|---|---|---|---|
| `managed-de-placement` | Managed DE Placement | Gail | $100K in placements | 180/quarter | Sarah |
| `think-school-crystal` | THINK School | Crystal | 500 paying members | none | Sarah/Lori |
| `strategist-program` | Strategist Program | Gail/Enterprise | 2-3 org engagements | none | Sarah/Blair |

Fan-out campaigns (`[Consortium name] Placement Campaign`, e.g. `ahri-consortium-placement-campaign`) carry no separate quota gate -- they're Lane 1 Managed DE work, so they count toward `managed-de-placement`'s 180/quarter cap like any other Gail org entering that campaign.

---

## Lead Quota Gate (managed-de-placement only)

`managed-de-placement` is the single shared cap on new Gail orgs entering a campaign this quarter — 180 total, not 180 per source. Every path that adds a Gail org to this campaign checks this same number before adding it, rather than each path keeping its own separate cap:

- `ce-crm-intake` (signal-driven orgs from Intelligence Inbox / Deals Pipeline)
- `gail-outreach.md` Phase 2 (Sarah's self-sourced orgs)
- Any other path that would add a Gail org to `managed-de-placement`

**Check:** Query Deals Pipeline (`789edd2b`) for records where `campaign = managed-de-placement` AND `campaign_added_date >= July 1, 2026`. Count = current quarter usage.

**Gate:**
- Current count < 180: org may enter the campaign.
- Current count >= 180: org does not enter the campaign this quarter. Set `ICP Profile = Gail` and `Newsletter Funnel = Added` instead (same as Crystal routing) — do not run Clay/contact enrichment or build outreach for it. Revisit next quarter when the count resets.

Checking this gate before enrichment (not after) is intentional — it avoids spending Clay credits or building demo emails for orgs that will just get shelved to newsletter anyway.

---

## Campaign Stage Definitions

**There is no `campaign_stage` field.** The real Deals Pipeline field is `Stage` (select), with real options `Won, Targeting, Pre-Proposal, Proposal, Verbal, Waiting, Lost, THK Sch Trial` -- confirmed against the live schema 2026-07-05. That's coarser than the granular email-cadence tracking this skill needs, so two fields do two different jobs: `Stage` holds the coarse funnel position (below), and the real `Next Action` (text) + `Last Activity Date` fields carry the granular "which email number, how many days since" detail that used to live in the old `email-1-sent`/`email-2-sent`/`email-3-sent` values.

| Real `Stage` value | Meaning | `Next Action` text carries | Next action |
|---|---|---|---|
| `Targeting` | RFP/mandate opportunity from Alex's `campaign-lead-sourcing.md`, linked to org or contact, awaiting a pursue/don't-pursue call | "Awaiting Priya/Sarah pursue decision" | Held -- do not auto-advance out of `Targeting` the way regular leads auto-advance. Scored by **Priya** (Proposal Analyst, Maya's team) **and Sarah** together. Moves to `Waiting` only on an explicit pursue decision from that pair, not a solo call |
| `Waiting` | Sourced through 3rd outreach touch, or responded with no call booked yet | "Email 1 pending" / "Email 2 due" / "Email 3 due" / "3 touches complete, no response" / "Responded, needs follow-up" -- set explicitly at each transition, this is what replaces the old email-N-sent granularity | See Step 2's due-action table -- cadence math runs off `Last Activity Date`, not a stage value |
| `Pre-Proposal` | Call booked or held, proposal not yet built | "Call prep needed" / "Proposal in progress" | Marvin prepares; Blair pre-builds proposal |
| `Proposal` | Proposal delivered | "Follow-up due [date]" | Watch for decision; follow up in 5 days |
| `Verbal` | Verbal commitment received, contract/agreement pending | "Awaiting signature" | Sage/agreement pipeline picks up |
| `Won` | Deal signed | -- | Lincoln onboarding; Marcus case study |
| `Lost` | Deal declined or dead | Reason logged | Archive; note reason |

**No real equivalent for "paused."** The old `paused` value ("hold per Marvin instruction") has no matching `Stage` option. Until Marvin decides otherwise, represent a hold by leaving `Stage` at its current value and writing the hold instruction into `Next Action` (e.g., "HOLD per Marvin -- do not advance") -- Step 2's due-action check must treat any `Next Action` starting with "HOLD" as a skip, not a stale/overdue flag.

---

## Workflow

### Step 1 — Query Notion

Query Campaign Hub where Status = Active to get the current campaign list -- this is the source of truth for which `campaign` IDs are in scope this run, not a hardcoded list. Includes the three core campaigns plus any live fan-out campaigns from Campaign Builder.

**`campaign` on a Deals Pipeline record stays single-value -- this is contact-level, not org-level.** One human contact, one campaign at a time, so nobody gets worked from two outreach threads. This does NOT mean an org can't appear in multiple campaigns -- an org's `Target Organizations` relation on Campaign Hub can legitimately span more than one campaign (e.g. a member of two overlapping Consortiums). Alex's `campaign-lead-sourcing.md` keeps org-level overlap but skips adding a second Deals Pipeline record if this org already has an active contact under a different campaign.

Query Deals Pipeline (789edd2b) for all records where:
- `campaign` field is set to any ID returned by the Campaign Hub query above
- Status is NOT `won`, `lost`, or `archived`

For each record extract:
- org name, contact name, contact email
- `Campaign` (which campaign)
- `Stage` (real field -- current coarse stage)
- `Next Action` (real field -- carries the granular email-cadence detail, see Stage table above)
- `Last Activity Date` (real field -- when last touched, used for all day-count math below)

Also query Contacts DB (170e1f64) for Crystal ICP contacts where `Campaign` = `think-school-crystal` and `Stage` = `Waiting` (covers what used to be the separate `added`/`email-1-sent`/`email-2-sent` values -- distinguish which by reading `Next Action`).

---

### Step 2 — Calculate Due Actions

**Sarah is not always the one who enters a contact -- four ways in, only one of them is hers (see `Agents/alex/Skills/campaign-lead-sourcing.md`'s Entered section):**
- **Cold/outbound path** -- Sarah enters them herself (Email 1 or scheduling). This is the only path where the actions below are hers to execute.
- **Warm path** -- Marvin enters them directly, or explicitly authorizes Sarah to reference the connection on his behalf. Sarah does not independently start outreach on a Warm-tagged contact.
- **Partner path** -- Inncuvate/Mark Lawrence makes or co-makes first contact, per Marvin's confirmed Lead/Co-lead/Need-a-Prime governance call. Sarah does not enter these either.
- **Inbound** -- the contact engages first, unprompted, regardless of tag. Sarah picks this up as inbound-priority.

For contacts Alex tagged `operator_lead: true` (Marvin/Inncuvate warm-intro path) that are genuinely Sarah's to work (i.e. Marvin authorized her to reference the connection, not a case where he or the partner is running point themselves), they get first-contact-attempt priority before cold-tagged contacts in the same campaign -- same standing priority rule already used elsewhere (55+ threshold vs. 60+ for cold). For Warm/Partner contacts Marvin or Inncuvate are running themselves, Sarah's job is just to track the record once entered, not to initiate it.

For every contact, determine if an action is due today. `Next Action` starting with "HOLD" always skips, checked first, before any row below:

| Condition (`Stage` + `Next Action` text) | Action due |
|---|---|
| `Targeting`, `Next Action` = "Awaiting Priya/Sarah pursue decision", new this run | Flag to Priya and Sarah: RFP needs scoring for pursue/don't-pursue |
| `Targeting`, no pursue decision within 5 days of the scoring flag (`Last Activity Date`) | Escalate to Marvin: RFP stalled awaiting Priya/Sarah call |
| `Waiting`, `Next Action` = "Email 1 pending", pending more than 2 days | Flag to Marvin: queued but not approved |
| `Waiting`, `Next Action` = "Email 1 pending" or already sent, days since `Last Activity Date` >= 5 | Email 2 due — Sarah sends autonomously, update `Next Action` to "Email 2 due" |
| `Waiting`, `Next Action` = "Email 2 due" sent, days since `Last Activity Date` >= 5 | Email 3 due — Sarah sends autonomously, update `Next Action` to "Email 3 due" |
| `Waiting`, `Next Action` = "Email 3 due" sent, days since `Last Activity Date` >= 1 | Flag to Marvin: 3 touches complete, no response, update `Next Action` to "3 touches complete, no response" |
| `Waiting`, `Next Action` = "Responded, needs follow-up", no follow-up in 24h | Urgent flag: Sarah or Marvin must respond today |
| `Pre-Proposal`, `Next Action` = "Call prep needed", call is today or tomorrow | Alert Marvin: call prep needed |
| `Proposal`, days since `Last Activity Date` >= 5 | Follow-up due: Sarah sends one-sentence check-in |

---

### Step 3 — Build Campaign Status Card

For each campaign, compile:

```
[Campaign Name] — [total contacts] total
  Waiting, email 1 pending: [N] (count Stage=Waiting AND Next Action="Email 1 pending")
  Waiting, email 1 sent:    [N] (avg [X] days ago -- count/avg Last Activity Date where Next Action="Email 2 due")
  Waiting, email 2 sent:    [N] (Next Action="Email 3 due")
  Waiting, email 3 sent:    [N] (Next Action="3 touches complete, no response")
  Waiting, responded:       [N] 🟢 (Next Action="Responded, needs follow-up")
  Pre-Proposal:             [N] 📅
  Proposal:                 [N]
  Verbal:                   [N]
  Won:                      [N] ✅
  Lost:                     [N]
  On hold (Next Action = "HOLD..."): [N]
  
  Actions due today:
    - [Contact name] @ [Org] — [action needed]
    - ...
```

---

### Step 4 — Write Output and Notify

Write full status to `output/campaigns/campaign-status-[YYYY-MM-DD].md`.

Post to Google Chat (CE cluster space):

```
📋 Campaign Status — [DATE]

[one section per campaign returned by Step 1's Campaign Hub query, in this order: the three core campaigns first, then fan-out campaigns]

[CAMPAIGN NAME, uppercased]
[N] in pipeline | [N] responded | [N] calls booked | [N] won
⚡ [N] actions due today

[button: Full Report]
```

Fan-out campaigns get the same section format as the three core ones -- no special-casing. If zero actions are due: post the summary card only — no alert tone. If actions are due: include the contact names and what's needed so Marvin can see it without opening the report.

---

## What Sarah Writes to Notion (Campaign Fields)

Every time Sarah adds a new contact or updates a stage, she writes these fields to the Deals Pipeline record:

| Field | Value |
|---|---|
| `Campaign` | Any Active campaign_id from Campaign Hub -- `managed-de-placement`, `think-school-crystal`, `strategist-program`, or a fan-out `campaign_id` from Campaign Builder |
| `Stage` | Current coarse stage, real field (see definitions above) |
| `Next Action` | Granular cadence detail -- which email number, or a HOLD instruction (see definitions above) |
| `Last Activity Date` | Date of most recent touch -- all day-count math in Step 2 runs off this |

Sarah must update `Stage`, `Next Action`, and `Last Activity Date` after every email send, response received, call booked, or proposal sent. These fields are the source of truth for campaign manager.

---

## On-Demand Use

Marvin or any agent can invoke `/campaign-status` at any time to get the current state of all three campaigns. The skill reads live from Notion — output reflects state at time of run, not cached data.

**Useful for:**
- Before Sunday queue build: "What's already in the pipeline before I add more?"
- Before a Gail call: "Where are we across the whole DE placement campaign?"
- End of week: "How many new contacts this week across all campaigns?"
