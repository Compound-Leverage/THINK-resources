# Shared Skill: Command Check

Used by any agent that posts an approval request and needs to detect Marvin's reply before acting. Load this at the start of any run where a prior approval request may be pending.

---

## How replies reach agents

Marvin can reply two ways -- both are read directly by Sarah via Gmail MCP:

1. **Reply in Google Chat** -- Chat messages appear in Gmail under the `CHAT` system label. Sarah searches `in:chat from:marvin` on each inbound run. No relay or Zapier needed.
2. **Email sarah@compoundleverage.com directly** -- Sarah searches `in:inbox is:unread` as normal.

Same search pass catches both channels. Sarah is the command router for all agent approval replies.

---

## Standard command vocabulary

| Command | Meaning |
|---|---|
| `GO` | Approve the recommended action -- proceed as proposed |
| `SEND` | Approve an outbound send specifically (email, proposal delivery) |
| `HOLD` | Do not act -- pause this item until further instruction |
| `EDIT [notes]` | Approve with changes -- notes describe what to change |
| `CANCEL` | Withdraw the request entirely -- remove from queue |

Commands are case-insensitive. A command plus context is always valid: "SEND but change the subject line to X" = SEND with an EDIT instruction.

---

## Standard approval post format

Approval posts go directly to the Marvin-Sarah DM space. Post via Zapier MCP `google_chat_create_message`:

- **webhook_url:** `config.approvals.webhook_url` (the DM space webhook -- posts land directly in the Marvin/Sarah DM thread)
- **buttonText:** `Reply to Sarah`
- **buttonUrl:** `config.approvals.gchat_dm_url` (opens the DM in a browser tab -- useful when replying from a push notification)

Message body:

```
[AGENT NAME] -- [ACTION TYPE] PENDING APPROVAL
Item: [what] | Deadline: [when or "no hard deadline"]

[Full draft or summary -- enough for Marvin to approve without clicking elsewhere]

Reply GO / HOLD / EDIT [notes] in this thread.
Or email sarah@compoundleverage.com with: [AGENT NAME] [command]
```

Marvin replies in the DM thread. Sarah reads via `in:chat from:marvin` on her next inbound run.

---

## How Sarah routes agent command emails

When Sarah reads an `[AGENT COMMAND]` email in her inbound run:

1. Parse the agent name from the subject or body
2. Parse the command (GO / HOLD / SEND / EDIT / CANCEL)
3. Match to the pending item in Notion (check Deals Pipeline, Contacts DB, or the log file for the pending request)
4. Execute or relay:
   - **Sarah Gail outreach:** Sarah executes the send directly
   - **Blair proposal:** Sarah updates the Deal record "Marvin approved" field and posts confirmation to Google Chat
   - **Any other agent:** Sarah posts to Google Chat: "[AGENT NAME] -- Marvin replied [COMMAND] on [item]. [Agent] picks up on next run."

---

## Pending request logging

When an agent posts an approval request, it also writes to `Logs/pending-approvals.log`:

```
[timestamp] | [agent] | [item identifier] | PENDING | [short description]
```

When Sarah resolves a command, she appends:

```
[timestamp] | [agent] | [item identifier] | RESOLVED | [command received] | [action taken]
```

This gives a full audit trail of every approval request and outcome.
