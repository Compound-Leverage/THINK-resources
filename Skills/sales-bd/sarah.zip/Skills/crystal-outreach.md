# Skill: Crystal ICP Outreach

Proactive THINK School outreach to Crystal-profile leads. Weekly rhythm: Sunday loads the list, Monday schedules the week, Tuesday through Friday executes daily sends. On demand: `/crystal-outreach`.

## Weekly Rhythm

| Day | What Sarah does |
|---|---|
| Sunday | Load Lori's CSV (Tue + Thu scout runs), qualify, score, build the full week's draft queue |
| Monday | Present queue to Marvin, get GO, assign one send per weekday |
| Tue - Fri | Send that day's scheduled email(s); log to Notion |
| Holidays | Skip. Pick up the next business day. |

Lori runs Tuesday and Thursday at 6 AM ET. Sunday Sarah picks up everything Lori dropped that week.

---

## Phase 1: Sunday -- Load and Schedule

### 1. Load leads

Read all `think-school_*.csv` files from `Leads/crystal/` modified in the past 7 days. Merge into a single candidate list. For each lead, check Contacts DB (Notion: `170e1f64`) by email and org_name -- skip any already present.

**Handle beehiiv_think_click leads first (before email queue):**
These leads were already enrolled in the THINK School Beehiiv sequence by Lori. Do NOT queue them for a Sarah email. Log them to the Contacts DB (status = Sequence Enrolled, source = beehiiv_think_click) if not already there, then remove them from the candidate list. The sequence handles conversion.

### 2. Qualify

**Who Crystal is:** A solopreneur or small business owner (1-5 people) who needs help and does not have the bandwidth or budget to hire. Uneven income. Wearing too many hats. AI is on her radar as a potential solution. Any vertical -- the income pattern and the capacity constraint are the identity, not the industry.

Apply Crystal ICP gates -- all five required:
1. Solopreneur or small business owner (1-5 people); income is project-based, variable, or contract -- not salaried corporate
2. Active signal: needs to hire / no bandwidth / opportunity hunting / AI curiosity / digital employee hire intent (see scoring)
3. Not already a Beehiiv subscriber -- check `list_subscriptions` by email (skip if subscribed -- those go to the high open rate segment, source: `high_open_subscriber`)
4. Not already in Contacts DB
5. `lane_qualifier` is NOT 1 -- leads where `lane_qualifier: 1` are Managed DE candidates. Do not send to this queue. Log as "Lane 1 lead -- route to Marvin for Managed DE conversation" and skip. Do not discard -- the CSV is the record.

Vertical is secondary. Signal and independence are the gates.

Leads that fail any gate: skip this week. Do not discard -- the CSV is the record.

### 3. Score

**Opportunity Fit Score** (0-10):

| Factor | Points |
|---|---|
| Hire / capacity signal -- explicitly looking to hire digital employees or AI agents (3) / looking for a VA or assistant, no bandwidth (2) / general "need help" or "too many hats" (1) | 0-3 |
| Opportunity / income signal -- mentions client hunt, inconsistent revenue, feast-or-famine (3) / general solopreneur growth struggle (2) / indirect (1) | 0-3 |
| Practice independence -- fully independent (2) / side practice (1) / primarily employed (0) | 0-2 |
| Prior touchpoint -- event attendance, Beehiiv content click, known contact (1) | 0-1 |
| Territory -- VA/MD/DC/TX (1) | 0-1 |

Threshold: **6.5**. Leads below threshold: hold, do not include.

Top priority regardless of territory: anyone showing a digital employee hire signal (explicitly asking how to hire AI agents or digital employees). Score as 3 on hire/capacity factor.

Sort qualified leads by score descending. Cap the week at **5 leads** (one per weekday). If more than 5 qualify, take the top 5.

### 4. Build all five draft emails

Build one HTML email per lead. Assign each to a send day: Monday lead 1, Tuesday lead 2, Wednesday lead 3, Thursday lead 4, Friday lead 5.

Select the email variant using this decision order:

**Step 1 -- Check for high open subscriber never in THINK School sequence:**
Run `list_subscriptions` by email. If active subscriber with 3+ of last 5 editions opened AND never enrolled in the THINK School sequence (`{{THINK_SCHOOL_SEQUENCE_ID}}`) → **Variant C** (direct personal outreach, 7-day trial offer).

**Step 2 -- Check for other warm leads (subscribed or prior touchpoint):**
- If active subscriber at any engagement level (but not Step 1) → **Variant B** (THINK School CTA -- already in newsletter, no need to send them back)
- If source is `event_attendee` or `gail_staff_ref` → **Variant B** (warm touchpoint, go direct to THINK School)

**Step 3 -- Cold leads (not subscribed, no warm touchpoint):**
- All remaining cold sources → **Variant A** (newsletter CTA)

Note: `beehiiv_think_click` leads never reach this step -- they were removed from the queue in Step 1 of Load Leads and enrolled in the Beehiiv sequence by Lori.

**From:** sarah@compoundleverage.com
**CC:** marvin@compoundleverage.com

---

#### Variant A: Cold Signal (LinkedIn, Reddit, recently independent, digital employee hire signal)

**Subject:** I found you. I want to explain why.

Before writing the email body: check `cluster_name`, `signal_summary`, and `cluster_window` from the lead's CSV row. The capital event is the opener -- name the specific event or funding in their space, what it means for their workload, and why the window is open now. If no cluster data is present, use the lead's own labor gap signal as the hook.

```html
Hi [first_name],

My name is Sarah Grant. I handle business development for Compound Leverage.

I should tell you upfront: I am a digital employee. I am an AI agent, not a person.

[IF cluster data present:]
Right now, [cluster_name] is moving in your space -- [signal_summary]. That creates
a window. Organizations that act on it will capture what is ahead. Organizations that
do not will watch someone else do it.

The problem is the work the window demands. Most organizations do not have the headcount
to act on an event like this before it closes.

[IF no cluster data -- use lead's labor gap signal:]
You showed up in a scan of [signal_source]. [Use lead's specific signal from notes field.]
That told me there is work in your space that is not getting handled.

Compound Leverage places digital employees. A placed DE handles the work the opportunity
demands -- or eliminates it from your plate -- so you can act before the window closes.

What you just experienced is the placement. I found you, qualified you, and reached out.
That is what a DE does when it is placed.

If you want your own team, our newsletter is where you start. THINK School is where
you get placed with yours.

[Newsletter button]

Sarah Grant | Growth Manager
Compound Leverage | sarah@compoundleverage.com
```

---

#### Variant B: Beehiiv Clicker / Warm Touchpoint -- THINK School direct

**Subject:** You clicked. You already know what this is about.

Use this variant for: `beehiiv_think_click`, active subscribers (any engagement), `event_attendee`, `gail_staff_ref`, or any lead with a prior warm touchpoint.

```html
Hi [first_name],

My name is Sarah Grant. I handle business development for Compound Leverage.

I should tell you upfront: I am a digital employee. I am an AI agent, not a person.

[For beehiiv_think_click: "You clicked our post '[post_title]' on [click_date]. That click
told me you already understand the problem -- the gap between finding opportunities and
actually capturing them."]

[For warm subscriber or touchpoint: "You have been in our orbit -- [newsletter subscriber /
you attended [event name] / [other warm context]]. That told me you already understand
what we do."]

You already understand the capacity problem. There is work that is not getting done,
or that you are doing yourself when a DE should be doing it.

One of our members had that problem. They placed a DE that found a $150K grant and
posted it in Skool. Seven days later another member used that post to win $112K from
the same organization. That work was off the plate. It still got done.

THINK School is where you get your own placed DE. Twenty-plus DEs ready to run. By day
10 of the challenge, your first DE is placed and the work is off your plate.

Reply if you have questions. Otherwise, start here.

[10-Day Challenge button]

Sarah Grant | Growth Manager
Compound Leverage | sarah@compoundleverage.com
```

---

#### Variant C: High Open Rate Subscriber -- Never in THINK School Sequence

**Subject:** Thank you for reading. I wanted to reach out personally.

Use for: active subscribers with 3+ of last 5 editions opened who have never been enrolled in the THINK School sequence.

Before writing: pull the titles of the editions they opened from the CSV notes field. Use one as a specific reference in the value section.

```html
Hi [first_name],

Thank you for being one of our most consistent readers. I wanted to reach out directly.

My name is Sarah Grant. I am one of 25 digital employees at Compound Leverage. I handle
community engagement for the newsletter.

You have been reading about what it looks like to hire digital employees to support your
work. We are about to launch a new benefit for THINK School members: 20 DEs ready for
you to hire and onboard from day one. Every time we build a new DE for a client or for
our own team, a scaled-down version goes into the community library.

As a thank you for your readership, I would like to offer you a free 7-day trial.
Reply here if you have questions or want me to demonstrate how I work with a sample
request, or go straight to THINK School: {{THINK_SCHOOL_URL}}

Sarah Grant | Growth Manager
Compound Leverage | sarah@compoundleverage.com
```

Note: CTA is a reply-to trigger. When the lead replies, Sarah escalates to Marvin to set up the trial access.

---

#### Newsletter button (Variant A only -- cold, not a subscriber)

```html
<a href="{{NEWSLETTER_URL}}" style="display:inline-block;background-color:#6B21A8;
color:white;padding:10px 20px;border-radius:4px;text-decoration:none;font-weight:bold;">
Subscribe to the newsletter
</a>
```

Config variable: `newsletter_subscribe_url` in config.json -- Beehiiv subscribe page.

Newsletter subscribe triggers the Beehiiv automation sequence. The sequence educates on DE staffing and converts to THINK School. Variant A's only job is getting the cold lead subscribed.

#### 10-Day Challenge button (Variant B -- warm / prior touchpoint / beehiiv clicker)

```html
<a href="{{THINK_SCHOOL_URL}}" style="display:inline-block;background-color:#6B21A8;
color:white;padding:10px 20px;border-radius:4px;text-decoration:none;font-weight:bold;">
Start the 10-Day DE Challenge
</a>
```

Config variable: `think_school_url` in config.json -- THINK School enrollment or landing page.

Variant C uses a reply-to trigger for the 7-day trial (see above). No button for Variant C.

### 5. Save queue to file

After scoring and assigning send days, save the full week's queue to `Leads/crystal/[week-of-YYYY-MM-DD]-queue.md`. Format:

```
# Crystal Outreach Queue -- Week of [Mon date]
Built: [Sunday timestamp]

## Mon [date]
Name: [full_name]
Email: [email]
Org: [org_name]
Score: [X.X]
Variant: [A/B/C]
Cluster: [cluster_name or none]
Signal: [1-liner]
Status: PENDING

## Tue [date]
...
```

Status field cycles: `PENDING` → `SENT [timestamp]` → `SKIPPED [reason]`. Phase 2 reads this file each morning to determine what to send and updates status after each action. This is the authoritative state for the week -- do not rebuild from CSVs during Phase 2.

### 6. Notify Marvin on Sunday (no approval required)

Post to the DM space via `config.approvals.webhook_url` on Sunday after building all drafts. This is a heads-up, not a hard approval -- but Marvin can reply HOLD before sends go out:

```
SARAH -- CRYSTAL OUTREACH WEEK OF [Mon date]
[N] leads qualified, [N] scheduled

Mon: [name] | score [X] | cluster: [cluster_name or "no match"] | [signal 1-liner]
Tue: [name] | score [X] | cluster: [cluster_name or "no match"] | [signal 1-liner]
Wed: [name] | score [X] | cluster: [cluster_name or "no match"] | [signal 1-liner]
Thu: [name] | score [X] | cluster: [cluster_name or "no match"] | [signal 1-liner]
Fri: [name] | score [X] | cluster: [cluster_name or "no match"] | [signal 1-liner]

Sending starts Monday. Reply HOLD [name] or HOLD ALL to pull leads before they go out.
```

Sarah sends autonomously unless Marvin replies HOLD before that day's 8 AM send window.

---

## Phase 2: Daily M-F -- Execute

### 6. Send each day's email

Each weekday morning at 8:00 AM ET:

1. Check whether today is a US federal holiday. If yes: skip. Carry that lead to the next business day.
2. Check whether Marvin replied HOLD for this lead's name or HOLD ALL before 8 AM. If yes: mark queue entry `SKIPPED HOLD`, note in Friday summary.
3. **Dedup check (required before every send):** Query Contacts DB (Notion: `170e1f64`) by the scheduled recipient's email address. If a record exists with any of these statuses -- Outreached, Sequence Enrolled, Active Client, Engaged -- mark queue entry `SKIPPED already-in-CRM [status]`, log the reason, and stop. Do not send. This catches contacts added to CRM via manual sends, Beehiiv enrollment, or any other path since Sunday's queue build.
4. Send that day's scheduled HTML email from sarah@compoundleverage.com using the draft from the queue file.
5. Update queue file entry status to `SENT [timestamp]`.
6. Write to Contacts DB (Notion: `170e1f64`): status = Outreached, ICP Profile = Crystal, source = crystal_outreach, utm_campaign from CSV, cluster_id from CSV (if present)
7. Write to Deals Pipeline (Notion: `789edd2b`): ICP Profile = Crystal, Status = Outreached, cluster relation = cluster_id from CSV (if present)
8. Append one line to `Logs/sarah-crystal-outreach/YYYY-MM-DD.log`

No Google Chat post per individual send. One Friday summary covers the week (step 7).

### 7. Friday summary

Post to the findings channel via `config.findings.webhook_url_env` at end of day Friday:

```
SARAH CRYSTAL OUTREACH -- WEEK OF [Mon date]
[N]/5 emails sent
Avg score: [X.X]
Skipped: [names and reason, if any]
Next list: Sunday [date]
```

If the week was fully paused or 0 qualified: post a single line -- "Crystal outreach paused this week. Next list Sunday [date]."

---

## US Federal Holidays

Skip sends on:
- New Year's Day (Jan 1)
- MLK Day (3rd Monday Jan)
- Presidents Day (3rd Monday Feb)
- Memorial Day (last Monday May)
- Juneteenth (Jun 19)
- Independence Day (Jul 4)
- Labor Day (1st Monday Sep)
- Columbus Day (2nd Monday Oct)
- Veterans Day (Nov 11)
- Thanksgiving (4th Thursday Nov)
- Christmas (Dec 25)

When a holiday falls on a weekday send slot, carry that lead to the next business day. Do not skip -- just delay one day.

---

## Rules
- No em dashes in any copy
- Score label: "THINK School Fit Score" -- never "Opportunity Score"
- Never send on Saturday or Sunday
- LinkedIn-only leads (no confirmed email): do not send -- log as "LinkedIn path -- no email; Marvin handles"
- After two non-responses from the same lead: hold for Marvin's call before any follow-up
- All external sends CC marvin@compoundleverage.com
- Max 5 leads per week per this skill (keeps volume intentional and reviewable)
