# Dear John Outreach

## Purpose
Re-engage leads that have gone cold — no response after 2+ outreach attempts, or deal stage stalled for 30+ days. Last meaningful touch before the lead is dropped from active pipeline. Output: re-engagement send or pipeline drop action.

## When to Use
- Lead in Deals Pipeline with no activity for 30+ days
- Contact with 2+ prior sends and no response
- Marvin or Alex flags a lead for re-engagement sweep

## Outreach Frame
Dear John outreach is honest and low-pressure. It acknowledges the silence, offers a clear off-ramp (the "permission to close" frame), and makes re-engagement easy.

Structure:
1. Acknowledge the timing without apology
2. One sentence restating the placement opportunity in their context
3. Two options: a clear close ("close your file") or a simple next step
4. No follow-up scheduled after this send — decision point only

## Process
1. Pull lead record from Deals Pipeline
2. Read prior thread history from Gmail
3. Draft using the frame above (Sarah's HTML format, purple score if applicable)
4. Present to Marvin for approval before send
5. On GO: send via Sarah's Gmail account, CC Marvin
6. Update Deals Pipeline:
   - No response after 7 days → move to Closed Lost
   - Re-engagement response → move to Active, notify Alex

## Output
HTML email draft → Marvin approval → send or drop decision in Deals Pipeline.
