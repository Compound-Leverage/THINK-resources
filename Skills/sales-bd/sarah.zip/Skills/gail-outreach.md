# Skill: Gail ICP Outreach

Proactive outreach to Gail-profile organizations: research universities, HBCUs, workforce development orgs, and EDOs that are missing funding windows because their capture bandwidth can't keep pace with grant velocity. The offer is the Done-For-You DE subscription + Strategist Program. TSU is the delivered reference case -- Sarah demonstrated the product to Gail Bassette by finding and scoring real TSU opportunities. That email IS the demo.

On demand: `/gail-outreach`. Scheduled: Sunday queue build + Mon-Fri daily sends.

## Weekly Rhythm

| Day | What Sarah does |
|---|---|
| Sunday | Source 25 Gail orgs, run capture scans, build all email drafts, post one batch approval card to DM |
| Mon - Fri | Send 5 emails/day at 8:30 AM from the approved queue |
| Saturday | No sends |

Sarah sends autonomously unless Marvin replies HOLD [org name] or HOLD ALL before that day's 8:30 AM window.

---

## Who Gail Is

Gail is a Lane 1 placement candidate. Three conditions required:

1. **Active mandate** -- a federal or state funding event (grant cycle, program launch, RFP, policy appropriation) has created a specific work window in the past 90 days or opening within 30 days.
2. **Capacity gap** -- no sufficient staff, system, or process to scan, route, and act on the mandate before the window closes.
3. **Budget present** -- an active federal funding portfolio, operating budget, or confirmed grant line item confirms purchasing capacity for an ongoing DE engagement.

**The signal:** A funded institution with a title in-scope: grants director, VP Research, Director of Sponsored Programs, workforce program director, executive director. That title = the Gail contact and the budget holder.

**What makes it urgent:** A specific open window is closing. The institution will miss it. TSU's AI Forge RFI is the proof case: spent days routing across 5 leaders with no decision.

**Not Gail:** Individual practitioners (Crystal, Lane 2). Orgs with no current or imminent funding event. Contacts without budget authority.

---

## Offer

**Done-For-You DE Subscription:** Sarah (or a dedicated DE) runs the 5-function capture system for them.
1. Monitor and Capture -- scan Grants.gov, SAM.gov, DARPA, DOL, NSF, HHS, EDA in near real-time
2. Screen and Vet -- assess against the org's priorities before reaching a human inbox
3. Score and Prioritize -- rank by fit, funding potential, timeline, strategic value
4. Circulate and Route -- deliver to the right College, Department, or program lead
5. Track and Close the Loop -- log what was submitted, pending, and missed

**Strategist Program (add-on):** CL teaches the org's team how to hire and manage their own digital employees. Self-funding component -- can be structured under NSF, DOL, Title III, or similar workforce development funding.

**Reference case:** Texas Southern University. Sarah flagged 5 live opportunities for TSU across Grants.gov, SAM.gov, NSF, DARPA, and DOL. Dr. Michelle John (VP for Research and Innovation) approved the engagement June 5. That email demo is available as proof upon request.

---

## Phase 1: Find and Qualify Gail-Profile Orgs

### 1. Source 1 -- HBCU Research Offices

HBCUs pursuing R1 status or actively growing research infrastructure are the highest-fit segment. TSU's $50M R1 target is the archetype.

**Search queries:**
1. `site:tsu.edu OR site:pvamu.edu OR site:hbcu.edu "grants" OR "research" "director" OR "VP" 2026`
2. `"HBCU" "R1" OR "research university" "grants management" OR "sponsored research" 2026`
3. WebSearch: `HBCU "seeking R1 status" OR "research expansion" grants director OR VP Research 2026`
4. WebSearch: `site:linkedin.com HBCU "Director of Sponsored Programs" OR "VP for Research" OR "Grants Director" 2026`

**Qualify:**
- Does the org have a dedicated research or grants function (sponsored programs office, VP of Research, grants director)?
- Are they in an active growth phase (R1 pursuit, new federal funding, workforce expansion)?
- Is this an HBCU, minority-serving institution, or community-anchor research institution?

### 2. Source 2 -- Workforce Boards and EDOs with Federal Funding Portfolios

Large workforce boards and EDOs with active WIOA, EDA, DOL, or SBA-funded programs that need to continuously renew and expand funding.

**Search queries:**
1. WebSearch: `"workforce board" OR "workforce development" "grant" "director" OR "CEO" OR "executive director" site:linkedin.com 2026`
2. WebSearch: `"economic development" "EDA" OR "CDBG" OR "DOL" "seeking funding" OR "grant opportunity" director 2026`
3. WebSearch: `Texas OR Virginia OR Maryland OR DC "workforce board" "AI" OR "technology" "training" OR "upskilling" grants 2026`

**Qualify:**
- Active federal funding portfolio (WIOA, EDA, DOL TAA, SBA, HHS)
- Director/VP/CEO with responsibility for securing and managing grant funding
- Evidence of active outreach for new programs or funding renewal

### 3. Source 3 -- Research Universities with Sponsored Programs Offices

Any research university where the VP for Research or Director of Sponsored Programs is publicly facing and their office is managing high grant volume.

**Search queries:**
1. WebSearch: `"Director of Sponsored Programs" OR "VP for Research" university "Grants.gov" OR "NSF" "seeking" OR "applying" 2026`
2. WebSearch: `university "research office" "capacity" OR "bandwidth" OR "volume" grants 2026`
3. WebSearch: `site:linkedin.com "Director of Sponsored Research" OR "Sponsored Programs Officer" university "federal" 2026`

**Qualify:**
- Active grants portfolio (any NSF, NIH, DOD, DOE, DOL, or DARPA involvement)
- Evidence the sponsored programs office is growing or stressed
- Contact is the decision-maker (VP, Director) -- not a grants coordinator or admin

### 4. Source 4 -- Community Colleges with Workforce Programs

Community colleges running Title III, Perkins, or DOL-funded workforce programs who need to continuously source renewal funding.

**Search queries:**
1. WebSearch: `community college "Title III" OR "Perkins" OR "DOL" "director" OR "VP" workforce grants 2026`
2. WebSearch: `community college "AI" OR "technology" "workforce development" "grant" director Texas OR Virginia OR Maryland 2026`

### 5. Source 5 -- R1-Profile Grant Tool Users

Institutions using dedicated grant management platforms are running enough grant volume to justify the software spend. They have the infrastructure problem -- too much opportunity, not enough staff to capture it. Same profile as TSU.

**Target tools:** Cayuse, InfoEd, SmartSimple, Pivot (ProQuest), Kuali Research, Coeus, GrantTracker

**Search queries:**
1. WebSearch: `"Cayuse" OR "InfoEd" OR "SmartSimple" OR "Kuali Research" university "sponsored programs" OR "grants office" director OR VP 2026`
2. WebSearch: `"Pivot" OR "ProQuest Pivot" university "research funding" "director" OR "VP for Research" HBCU OR "minority-serving" 2026`
3. WebSearch: `site:linkedin.com "Cayuse" OR "InfoEd" "Director of Sponsored Programs" OR "VP for Research" university 2026`
4. Clay MCP: search for accounts where tech stack includes any of the above grant tools + org type = university or nonprofit + headcount signal suggests grants team of 3 or fewer

**Qualify:**
- R1 status, R1-aspiring, or active federal grants portfolio (same gates as Sources 1 and 3)
- Identifiable grants director, VP for Research, or Director of Sponsored Programs
- Grant tool use = strong Gail signal -- org already knows the problem, just hasn't solved it

**Priority:** R1 or HBCU using grant management software with 3 or fewer staff in the grants function. That ratio is the whole pitch.

---

## Phase 2: Qualify and Score Each Org

For each org found, apply the Gail ICP gates:

**Required (all four):**
1. Active mandate -- capital event present or imminent (federal/state grant, RFP, program launch); not an org with no current funding event
2. Capacity gap confirmed -- explicit signal of insufficient staff or system to act on the mandate (job posting for grants staff, staff-to-grant ratio strain, bandwidth statement, or missed window history)
3. Budget signal confirmed -- active federal funding portfolio, state grant, or operating budget with grants function; confirms purchasing capacity for a DE engagement
4. Reachable decision maker -- VP, Director, or Executive Director with budget authority; email confirmable via Hunter.io or org website

**Scoring:**

| Factor | Points |
|---|---|
| Pursuit signal -- R1 status, NSF HBCU grant, capacity expansion, new workforce program (3) / current funded programs with renewal upcoming (2) / funded but no active expansion signal (1) | 0-3 |
| Bandwidth signal -- public evidence of high grant volume, missed windows, or staff overload (2) / org size suggests capacity strain (1) | 0-2 |
| Org alignment -- HBCU or minority-serving institution (2) / workforce board or EDO (2) / research university (2) / community college (1) | 0-2 |
| Geography -- VA/MD/DC/TX (2) / other US (1) | 0-2 |
| Warmth -- prior Marvin contact, CL event, mutual connection, or board overlap (1) | 0-1 |

**Threshold: 6**. Below threshold: log but do not outreach.

**Campaign quota gate (check before building anything in Phase 3):** Query current `managed-de-placement` campaign count per the gate defined in `campaign-manager.md` (180/quarter, shared with `ce-crm-intake` — this is one quota both pipelines draw down against, not 25/week on top of whatever ce-crm-intake already added). Take only as many of this week's qualified orgs, sorted by score descending, as fit remaining headroom. Any org that doesn't fit: log with `ICP Profile = Gail`, `Newsletter Funnel = Added`, do not build a demo email for it. If headroom is zero, skip straight to logging — do not run Phase 3 capture scans for orgs that won't be sent.

Cap at **5 orgs per day, 25 per week** — this is a pacing cap on top of the quota gate above, not a substitute for it. Sort qualified leads by score descending and assign to send days: Mon orgs 1-5, Tue 6-10, Wed 11-15, Thu 16-20, Fri 21-25. If fewer than 25 qualify (or fewer fit remaining quota), distribute evenly across the days that have leads.

---

## Phase 3: Build All Demo Emails (Sunday)

For all qualifying orgs in the week's queue, Sarah builds live demos before sending. Run all scans and drafts on Sunday so Monday-Friday sends are ready to execute without delay.

**Step 0 -- Check Intelligence Inbox for active capital events:**

Before running capture scans, query the Intelligence Inbox (`4bcb512f-9861-476f-945b-9b90ceb6478a`) for entries where Status = Qualified and Last Edited within the past 14 days.

For each entry: extract sector, geography, signal_summary, funding source, window dates.

Match qualifying orgs in this week's queue against active inbox entries by sector and geography. If an org's sector or region matches an active capital event, that event becomes the email hook -- it opens the email and names why the window is open now. If no inbox entry matches, use the org's active funding signals as the hook.

**Step 1 -- Run the capture scan:**

Using the same sources as the TSU demo (Grants.gov, SAM.gov, NSF, DARPA, DOL, HHS, EDA), scan for active opportunities that match the org's known profile:
- Geography and service area
- Sector (workforce, research, STEM, AI/tech, community development)
- Deadline window: prioritize anything closing within 30 days

Select the 3-5 highest-fit live opportunities. For each, extract:
- Opportunity title and agency
- Award amount range
- Deadline
- One sentence on why it fits this org
- Score (High / Medium fit)

**Step 2 -- Build the HTML email:**

**From:** sarah@compoundleverage.com
**To:** [contact email]
**CC:** marvin@compoundleverage.com

**Subject line:**
- If capital event match: "[signal_summary shortened] -- what this means for [Org Name]"
- If no event match: "I scanned [Org Name]'s funding landscape. Here is what I found."

```html
[Contact first name],

My name is Sarah Grant. I handle business development for Compound Leverage.

I should tell you upfront: I am a digital employee. I am an AI agent, not a person.

[IF capital event match from Intelligence Inbox:]
[Signal_summary]. That creates a window for organizations in [sector/geography]. The
institutions that act on it will capture what is ahead. The ones that don't will watch
someone else do it.

The problem is not the opportunity. It is the work the window demands. Most sponsored
programs offices are already running at capacity on their current portfolio. A new
funding window means more scanning, more routing, more deadline management -- on top of
everything already in flight.

[IF no capital event match:]
Your grants portfolio is active -- and federal funding velocity in [sector] has not
slowed down. The gap is not the opportunity. It is the bandwidth to act on it before
the deadline moves.

Here is what came up for [Org Name] in the last 30 days:

---

[OPPORTUNITY TABLE -- HTML formatted]
| Opportunity | Agency | Amount | Deadline | Fit |
|---|---|---|---|---|
| [Title] | [Agency] | $[range] | [date] | High |
| [Title] | [Agency] | $[range] | [date] | High |
| [Title] | [Agency] | $[range] | [date] | Medium |
| [Title] | [Agency] | $[range] | [date] | Medium |

---

Compound Leverage places digital employees for organizations with a labor gap created
by a capital event. A placed DE handles the scanning, scoring, and routing so your team
focuses on writing and winning. The window stays open longer when someone is watching it.

Right now we do this for Texas Southern University. Their VP for Research approved the
engagement June 5. I can send the email I sent them as a reference.

We pair the DE team with a Strategist Program -- CL teaches your staff how to hire and
manage digital employees, and that program can itself be funded through NSF, DOL, or
Title III.

If the opportunities above look relevant, I would like to show you what this looks like
for [Org Name].

<a href="{{MANAGED_DE_INTAKE_URL}}" style="display:inline-block;background-color:#6B21A8;
color:white;padding:10px 20px;border-radius:4px;text-decoration:none;font-weight:bold;">
See what this looks like for [Org Name]
</a>

Or just reply here. Marvin Harris is CC'd on this email.

Sarah Grant | Digital Employee, Business Development
Compound Leverage | sarah@compoundleverage.com
```

`MANAGED_DE_INTAKE_URL` is set in `config.managed_de_intake_url`. This is the form where prospects share their grants function details and receive a subscription quote -- no pricing is discussed in the email itself.

**Step 3 -- Sunday batch approval post:**

After building all drafts, post ONE card to the DM space via `config.approvals.webhook_url`:

```
text:       "SARAH -- GAIL OUTREACH QUEUE WEEK OF [Mon date]
[N] orgs queued across Mon-Fri at 8:30 AM.

Reply HOLD [org name] to pull any org before its send day.
Reply HOLD ALL to pause the full week.
No reply needed to approve -- sends are go by default.

MON: [Org 1] | [Contact, Title] | Score [X] | [1-line signal]
     [Org 2] | [Contact, Title] | Score [X] | [1-line signal]
     [Org 3] | [Contact, Title] | Score [X] | [1-line signal]
     [Org 4] | [Contact, Title] | Score [X] | [1-line signal]
     [Org 5] | [Contact, Title] | Score [X] | [1-line signal]

TUE: [Org 6-10, same format]
WED: [Org 11-15]
THU: [Org 16-20]
FRI: [Org 21-25]

Full email drafts saved to Leads/gail/[week]-queue.md -- reply SHOW [org name] to see any draft."
buttonText: "Reply to Sarah"
buttonUrl:  "[config.approvals.gchat_dm_url]"
```

Log to `Logs/pending-approvals.log`:
```
[timestamp] | sarah | gail-queue-[week] | PENDING | [N] orgs queued, sends Mon-Fri 8:30 AM
```

---

## Phase 3b: LinkedIn DM (Parallel Channel)

LinkedIn DM runs in parallel with email for every Gail prospect where a LinkedIn profile is confirmable. It is not a replacement -- it is a second touch on the same week the email sends. Marvin executes the LinkedIn action; Sarah drafts the message and includes it in the Sunday approval card.

### Message 1 -- Connection request note (if not already connected)

Under 300 characters (LinkedIn connection request limit):

```
[First name] -- I work with organizations managing federal grant portfolios in [DMV / Texas]. Saw what [Org Name] is doing with [specific program or funding signal]. Wanted to connect.

Sarah Grant | Compound Leverage
```

If already connected, skip to Message 2.

### Message 2 -- First DM (send same day as email or day after)

Under 150 words. No pitch. One specific signal. One soft question.

```
[First name],

I ran a quick scan on [Org Name]'s funding landscape this week -- [one specific observation, e.g., "the EARN Maryland round just dropped and your program area is a strong fit for two of the active awards"].

We work with workforce directors and grants teams who are running at capacity and need someone handling the scanning and routing function so they can focus on writing and winning.

Not a pitch -- just wanted to put the signal in front of you directly. Worth a short conversation?

Sarah Grant
Digital Employee, Business Development
Compound Leverage
```

### Rules for LinkedIn DM

- No em dashes
- Message 1 references a specific signal (not generic "love your work")
- Message 2 is under 150 words, one observation, one question
- Never send Message 2 before Message 1 is accepted (if connection request pending)
- Sarah drafts both messages. Marvin sends from his LinkedIn account -- Sarah does not have LinkedIn access
- Include both messages in Sunday approval card under each org's entry
- If no reply to Message 2 after 7 business days: flag to Marvin, no autonomous follow-up

### Sunday batch card addition

Add to the existing approval card under each org:

```
LI: [LinkedIn profile URL] | M1: [connection request note, truncated] | M2: ready
```

---

## Phase 4: Daily M-F -- Execute Sends

Each weekday at 8:30 AM ET:

1. Check for HOLD commands from Marvin (via `in:chat from:marvin` or email) received before 8:30 AM. HOLD [org name] pulls that org from the day's queue. HOLD ALL skips the full day.
2. Check US federal holidays -- if holiday, skip. Carry held orgs to next available business day.
3. Send each of that day's 5 emails from sarah@compoundleverage.com via Resend (Scripts/sarah-send-email.py) — not GWS CLI or Zapier.
4. Log each send to `Logs/sarah-gail-outreach/YYYY-MM-DD.log`.
5. Write to Notion CRM (see Phase 5).

---

## Phase 5: CRM and Follow-Up

After Marvin approves and Sarah sends:

1. Write to Orgs DB (Notion: `2cc68799`): org_name, type, contact_name, contact_email, status = Outreached, ICP Profile = Gail
2. Write to Deals Pipeline (Notion: `789edd2b`):
   - ICP Profile = Gail
   - Status = Outreached
   - source = gail_outreach
   - **campaign** = `managed-de-placement` (default) OR `strategist-program` (if org is being pitched Path B entry)
   - **campaign_stage** = `email-1-sent`
   - **campaign_added_date** = today's date
   - **last_touch_date** = today's date
   - **next_action_date** = today + 5 business days (Email 2 trigger date)
3. Write to Contacts DB (Notion: `170e1f64`): contact_name, contact_email, org, title, status = Outreached

After Email 2 sends: update Deals Pipeline record — campaign_stage = `email-2-sent`, last_touch_date = send date, next_action_date = send date + 5 business days.

After Email 3 sends: update Deals Pipeline record — campaign_stage = `email-3-sent`, last_touch_date = send date, next_action_date = send date + 1 business day (flag day).

After any response received: update campaign_stage = `responded`, last_touch_date = response date.

After call booked: update campaign_stage = `call-booked`.

After proposal sent: update campaign_stage = `proposal-sent`, last_touch_date = send date, next_action_date = send date + 5 business days.
4. Append to `Logs/sarah-gail-outreach/YYYY-MM-DD.log`

**Follow-up sequence (autonomous):**

Sarah runs a 3-touch sequence for every Gail org. No Marvin approval needed for touches 2 and 3 — these run automatically on schedule.

| Touch | Timing | Trigger | Action |
|---|---|---|---|
| Email 1 | Day 0 | Marvin approves the initial send | Cold pitch — specific funding window hook, TSU reference, placement CTA |
| Email 2 | Day 5 (business days) | No response to Email 1 | One-sentence follow-up anchored to the same funding window. "Has this been routed internally yet? Still open for a 30-minute call." |
| Email 3 | Day 10 (business days) | No response to Email 2 | Close or pivot. "Is this on the radar for Q3? If timing isn't right, who at [org] manages grant capture — happy to reach out directly." |
| Flag | Day 11 | No response after all 3 touches | Post to Google Chat: org name, all 3 send dates, flag for Marvin to decide next step (LinkedIn outreach, referral path, or archive) |

**Email 2 and 3 format:** 2-3 sentences max. No re-pitching. No new attachments. Same thread as Email 1. Subject line unchanged (Re: [original subject]).

Sarah does not require Marvin approval for Email 2 or Email 3. Both are pre-approved by this cadence definition. Marvin can override with HOLD [org name] at any point.

---

## Rules
- No em dashes in any copy
- No guessed email addresses -- confirmed contact only
- Marvin approves every Gail send before it goes out (unlike Crystal)
- Always CC marvin@compoundleverage.com
- Max 5 orgs per day, 25 per week
- TSU is a reference case -- do not contact TSU again unless Marvin says so
- If the org is already in Deals Pipeline: skip outreach, flag to Marvin instead
- No fabricated opportunity details -- every opportunity in the scan must be real and linkable
