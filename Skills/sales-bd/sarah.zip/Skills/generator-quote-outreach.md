# Skill: Generator Quote Outreach

One-time direct outreach to a named contact requesting they submit details via the intake form so CL can generate a scoped quote. The quote covers two items: a one-time placement fee (onboarding) and a 3-month Managed DE subscription (probation). Marvin sets the actual numbers; Sarah's job is getting the intake form filled out.

Trigger: `/sarah generator-quote-outreach [contact_name] [contact_email]`

---

## Steps

### 1. Check CRM

Query Contacts DB (Notion: `170e1f64`) by the contact's email address. If a record exists with status Outreached, Active Client, or Engaged: log "Already in CRM at [status] -- escalate to Marvin before sending" and stop. Do not send without Marvin's explicit go.

### 2. Draft the email

**From:** sarah@compoundleverage.com
**CC:** marvin@compoundleverage.com
**To:** [contact_email]
**Subject:** One quick form to get your quote

```html
Hi [contact_name],

My name is Sarah Grant. I handle business development for Compound Leverage.

Marvin asked me to reach out directly. We are putting together a quote for you that
covers two things: the placement fee to get your team set up, and a three-month
subscription for the managed period that follows.

To scope it accurately, we need a few details from you. It takes about three minutes.
Click the link below, describe the work you need done, and we will have a spec and
quote back to you within 24 hours.

<a href="https://compoundleverage.com/strategist-intake"
   style="display:inline-block;background-color:#6944BA;color:white;padding:10px 20px;
          border-radius:4px;text-decoration:none;font-weight:bold;">
  Submit your details
</a>

Reply here if you have any questions before filling it out.

Sarah Grant | Growth Manager
Compound Leverage | sarah@compoundleverage.com
```

### 3. Send

Send the drafted email via Gmail. Do not send until the draft is confirmed in Gmail and Marvin has had the opportunity to review (standard approval window: 15 minutes after draft is posted to the approvals webhook).

Post to approvals webhook (`config.approvals.webhook_url`):

```
SARAH -- GENERATOR QUOTE OUTREACH
To: [contact_name] <[contact_email]>
Subject: One quick form to get your quote
Action: Awaiting send. Reply HOLD to pause.
```

After the 15-minute window with no HOLD: send.

### 4. Log

- Write to Contacts DB (Notion: `170e1f64`): status = Outreached, source = generator_quote_outreach, notes = "Sent intake form request for quote scoping"
- Write to Deals Pipeline (Notion: `789edd2b`): status = Outreached, notes = "Generator quote -- intake form sent [date]"
- Append to `Logs/sarah-generator-quote/YYYY-MM-DD.log`:
  ```
  [timestamp] Sent intake form request to [contact_name] <[contact_email]>
  ```

---

## Rules

- No em dashes in copy
- Always CC marvin@compoundleverage.com
- CRM dedup check is required before every send
- Do not quote a price in the email -- the intake form drives the scoping; Marvin sets numbers
- The quote Sarah generates after intake covers exactly two line items: placement fee (onboarding) + 3-month Managed DE subscription (probation)
