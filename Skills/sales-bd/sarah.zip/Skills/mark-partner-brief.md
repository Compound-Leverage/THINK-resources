# Mark Partner Brief

Weekly partner brief to Mark Lawrence (mark@inncuvate.com) from Sarah Grant (sarah@compoundleverage.com).

## Schedule

Runs every Monday. If today matches a US federal holiday, log SKIPPED to `Logs/completions.log` and stop.

## Fixed Addresses

From: `sarah@compoundleverage.com`
To: `mark@inncuvate.com`
These are hardcoded. Do not substitute any other address.

## Data Sources

- **Joint Pipeline:** Deals Pipeline (Notion `1c6eba1b7fad4b4abfcbeb41b729c586`) -- filter to Partner = Inncuvate
- **Proposal Status:** Intelligence Inbox (Notion `4bcb512f-9861-476f-945b-9b90ceb6478a`) -- filter to records where Status IN (Qualified, Reviewed, Active) and Notes/Description/Title contain "Inncuvate" OR "PGCC" OR "PJM", and Policy Level = Federal or Agency/Organization contains MBDA or SBA
- **Capital Event Signals:** Intelligence Inbox -- Status = Qualified, added in last 7 days, relevant to MD, DC, VA, TX and sectors: workforce development, semiconductor, AI, federal infrastructure

## Pipeline Section Rules

The pipeline section shows deal status and opportunities only. It is scoped strictly to partner-relevant data.

**Include:**
- Deal name
- Stage
- CL amount (or funding pot if CL amount not set)
- Last activity date
- Next action and who owns it
- Stall flag if no activity in 7+ days (state the business reason: no response, contact info missing, scope not confirmed, etc.)

**Never include:**
- Payment status, payment amounts, or whether a deal is paid or unpaid
- Invoice information
- Internal billing or collections state of any kind

Payment data does not belong in a partner brief. Notion payment fields are manually maintained and not real-time. If payment tracking is ever needed it must come from a live payment processor (Stripe, Bill.com, etc.) and belongs in an internal CL report, not in external partner communication.

## Brief Structure

### One Thing
Single highest-leverage action Mark needs to take this week. Must be specific: a named deal, deadline, or decision. If a deadline falls within 7 days, that is the One Thing.

### Joint Pipeline
- Active deals: stage, CL amount, next action, owner
- Stalled deals: days since last activity, business reason for stall (no contact info, no response, scope not confirmed -- never payment state)

### Proposal Status
- Each active proposal: status, deadline, next action, who owns it
- Call out explicitly if a response or decision is needed from Mark

### Capital Event Signals
- 2-3 signals relevant to Inncuvate's territory and sector
- One paragraph each: what the signal is, why it matters, whether a joint CL/Inncuvate response makes sense

### Opportunities for Your Review
New opportunities CL has identified where Inncuvate has a plausible role and a pursuit decision is needed. For each opportunity, include:
- What the opportunity is (funder, program, amount, geography)
- Why Inncuvate fits (territory, sector, network, delivery role)
- Recommended CL/Inncuvate play in one sentence
- A clear ask: "Reply NO GO or NEED MORE INFO"

Mark replies to the email with his verdict per opportunity. Sarah logs the response in the Intelligence Inbox (Notes field) and updates the record Status:
- **NO GO:** Status set to "Not Qualified", Notes updated with Mark's decision and date
- **NEED MORE INFO:** Status remains "Qualified", Notes updated flagging what information Mark needs before he can decide; Sarah follows up to source the missing info

Sourcing logic: pull from Intelligence Inbox where Status = Qualified AND the record has not previously been presented to Mark (no "Presented to Mark" note or tag). Limit to 3 opportunities per brief. Prioritize by Intent Signal Score descending, then by application deadline proximity.

### What Sarah Is Handling
- 2 bullets of active partner work Mark does not need to touch

## Email Format

- HTML email, accent color `#6944BA`
- No em dashes anywhere
- Peer-to-peer tone, not report-style
- Subject: `[Day, Month Date] | Partner Brief | [One Thing in 6 words or fewer]`

External partner (Mark Lawrence, Inncuvate) -- identity matters, so this is tiered, not Resend-only:
- **Tier 1 -- GWS (primary).** Sends as the real `sarah@compoundleverage.com`. Build with `email.mime.text.MIMEText` + `email.header.Header(subject, "utf-8")`, then `gws gmail users messages send`.
- **Tier 2 -- Zapier (fallback if GWS fails).** Also the real address. `mcp__claude_ai_Zapier__gmail_send_email`.
- **Tier 3 -- Resend (last resort only).** `Scripts/sarah-send-email.py` -- sends from `sarah@send.compoundleverage.com`, a lookalike, only when Tier 1 and Tier 2 both fail.

Gmail MCP connector is read-only regardless of tier -- do not attempt sends through it.

## Completion Log

Append to `Logs/completions.log`:
```
[ISO timestamp] | sarah | mark-partner-brief | COMPLETE | [send method] | [One Thing summary]
```

Commit log entry to staging branch.
