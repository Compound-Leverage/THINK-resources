# Morning Brief — HTML Format

Subject: `Daily Brief — [Weekday, Month Day]`

## Structure

```html
<!-- HEADER -->
Dark bar: Agent name + " · Daily Brief" + date, date styled as a separate element with explicit left margin/padding (e.g. `margin-left: 16px` or its own table cell) so it never touches "Daily Brief" directly. A past run rendered this as "Daily BriefThursday, July 9, 2026" with no gap at all -- verify there's visible whitespace between the title and the date before sending.

<!-- SECTION 1: TOP 3 ACTION ITEMS -->
Purple left-border cards, one per action item.
Each card: urgency score chip (color-coded) + source label + one-line summary + context note. Put explicit spacing (e.g. `margin-right` on the chip, or a literal space if inline text) between the score chip and the source label -- a past run rendered these touching, e.g. "PRIORITY 20[DEALS PIPELINE]". Verify there's a visible gap before sending.

Score chips:
- 9–10: red (#D93025)
- 7–8: orange (#E8710A)
- 5–6: yellow (#F9AB00)

Source labels: [Email — Inncuvate] [Email — Nonprofit] [Email — Info] [Deals Pipeline] [OKR — Revenue/Product/Audience]

<!-- SECTION 2: OKR PULSE -->
Header line: "OKR Pulse — as of [Run Log date]" (always show the date, this data is only as fresh as the last M/W/F orchestrator run), with one Portfolio status chip (CRITICAL/etc., red-scale) next to it -- this is the only status word the Run Log actually provides, don't invent others.
Three compact columns, one per Objective (Revenue | Product | Audience). Each column: Objective name as a small header, then its three KRs as `Name: X/total` lines using the real KR names from `Docs/okr-definitions-q3-2026.md` (per workflow.md Step 4's mapping) -- e.g. "Accounts Added: 22/180", "MRR: DATA GAP", "Placements: 14/30" for Revenue. Plain text, no score chip, no color scale forced onto it. Never render a bare "KR1"/"KR2"/"KR3" label -- always the real name. No blended ratio number anywhere in this section.
Below the three columns, one line per Objective translating the Activated column into plain language: "Revenue — full signal pipeline activated (Alex, Julian, Lori)."
Any Exceptions NOT already promoted into Top 3 Action Items: listed here as a short bulleted line each.
If the run log is unavailable: single line "OKR Pulse — run log unavailable" instead of the section.

<!-- SECTION 3: EMAIL TRIAGE -->
One subsection per Gmail account, in order: business → nonprofit → info.
Nonprofit subsection header has a [Nonprofit] chip in purple.

Each email row:
- Sender name + org
- Subject line (truncated at 60 chars)
- One-line summary of what they need
- [Nonprofit] chip if from nonprofit account

<!-- SECTION 4: DEAL PULSE -->
Table: Deal Name | Stage | Close Date | Last Activity | Score
Color-code close date: red if <7 days, yellow if 7–14 days, green if >14 days
Only show deals with a score ≥ 6 or close date within 14 days.
If no qualifying deals: omit section entirely.

<!-- SECTION 5: ON DECK -->
Collapsed-style list (no cards) — just names of items scoring 5–7.
Label: "On Deck — no action needed today"
If none: omit section.

<!-- FOOTER -->
Light gray: "Sarah Grant · Compound Leverage" + timestamp of brief generation
```

## Tone Rules
- Every line is a decision or fact — no filler
- Nonprofit items always labeled — Mark needs to context-switch mentally
- Scores shown numerically — Mark can disagree and override priority mentally
- No pleasantries, no signoff — this is a dashboard, not a letter
