# Morning Brief Skill

Triggered daily before 8am. Reads all configured inboxes, CRM deal activity, and open project tasks. Synthesizes into a single prioritized HTML email delivered to the operator.

## Trigger
`morning-brief` — fires on schedule (see hook-map.md) or on demand via `/sarah morning-brief`.

## Execution Steps

### Step 1 — Read Gmail Inbox
Read unread emails from the past 24 hours in Sarah's real inbox, sarah@compoundleverage.com. Use whatever Gmail-reading tool is actually available in the current environment (GWS CLI, Zapier, Gmail MCP) -- there is no `config.gmail_accounts` or `zapier_fallback` config value to look up; those keys don't exist in `Agents/sarah/config.json`. This is one inbox, not a multi-account list.

If a message is from a known nonprofit contact (check Contacts DB), flag it `nonprofit: true`.

**Thread deduplication:** After pulling unread messages, group by `threadId`. For each thread, select only the most recent message (highest `internalDate`) as the item to process. Load full thread context when drafting any response. After responding or noting a thread, mark all messages in that thread as read — not just the trigger message.

Filter to actionable only:
- Unread messages (after deduplication)
- Messages with direct questions or requests
- Messages from known contacts in CRM
- Messages flagged or starred

Skip: newsletters, automated notifications, no-reply senders (unless flagged).

### Step 2 — Read CRM Deal Activity (Notion)
Use Notion MCP to pull from the Deals Pipeline database (`789edd2b`):
- Open deals modified in the last 48 hours
- Deals with close dates within 14 days
- Contacts who replied to outreach in the last 24 hours

For each deal: name, stage, close date, last activity, next step.

### Step 3 — Read Beehiiv Activity
Use Beehiiv MCP to pull:
- New subscribers in the last 24 hours
- Subscribers who match Crystal ICP (opened last 3 emails)

### Step 4 — Read OKR Pulse (CE Goal Orchestrator Run Log)
Read the `## CE Goal Orchestrator Run Log` table in the repo's root `CLAUDE.md`. Take the **last row only** (most recent date) -- do not summarize historical rows.

Extract: Date, Portfolio status (the one status word in that column -- e.g. CRITICAL), the **Activated** column (which DEs were triggered this run and why), and the **Exceptions** column (items the orchestrator could not resolve on its own).

**Exceptions column parsing:** the cell is a count followed by a semicolon-separated list wrapped in one outer parenthesis, e.g. `4 (Exception 2: Portfolio CRITICAL; Exception 3×2: Product+Audience stalled 2 cycles; Exception 4: Polytechnic Consulting Verbal)`. Split on `;` to get each individual exception, then strip the outer wrapping parenthesis from the *list as a whole*, not from each item's own text. A past run kept the list's closing `)` attached to the last exception's name ("Exception 4: Polytechnic Consulting Verbal)"). Verify no exception title ends with a stray unmatched `)` before using it in Top 3 or OKR Pulse.

**For Revenue/Product/Audience, parse the per-KR breakdown out of each cell's parenthetical, not the blended ratio in front of it.** Each cell looks like `~3.39 (day-8 artifact; KR1=22/180, KR2 DATA GAP, KR3=14/30 partial)` -- the leading number (`~3.39`) is a blended ratio across three KRs measuring different things, and is frequently flagged in its own annotation as an early-cycle artifact. It is not a legible signal on its own. Discard it.

**Map each `KRn` to its real name from `Docs/okr-definitions-q3-2026.md` and show it as `Name: X/total`, not `KRn=X/Y`.** The KR number is a table index, not something Marvin should have to decode. Use this mapping (fixed per Objective -- do not re-derive it each run):

- **Revenue:** KR1 → `Accounts Added: X/180`, KR2 → `MRR: $X/$7,350`, KR3 → `Placements: X/30`
- **Product:** KR1 → `DE Library Size: X/17`, KR2 → `Courses Published: X/4` (Product has only 2 KRs as of 2026-07-13 -- KR3/DOL Certification was cut, do not report it even if a stale Run Log row still shows it; KR1 changed from an "upgrade count" to the real live DE count at compoundleverage.com/digital-employees/ the same day)
- **Audience:** KR1 → `Newsletter Issues: X/13`, KR2 → `New Subscribers: X/2,100`, KR3 → `Paid Conversions: X/150`

Take the numerator directly from the log's fraction (e.g. `KR1=22/180` → `Accounts Added: 22/180`). If a KR shows a non-fraction status instead of a fraction (`DATA GAP`, `no milestones`, `manual needed`), show `Name: <status>` (e.g. `MRR: DATA GAP`) rather than forcing it into an X/total shape. Do not convert any of these into a synthetic 0–1 score or invent a status word (AT RISK / ON PACE / etc.) per KR or per Objective -- the Run Log doesn't provide one at that granularity, only at the Portfolio level. Report what's actually there, just under its real name.

This table updates M/W/F only (ce-goal-orchestrator's actual schedule) -- it will be stale on Tue/Thu/weekend runs. Always label this section with the run date explicitly (e.g. "OKR Pulse — as of Wed, Jul 8") so it reads as a snapshot, never as same-day data on off-days.

If the table is missing, empty, or unparseable: omit the OKR Pulse section entirely and note "OKR Pulse — run log unavailable" rather than guessing at scores.

### Step 5 — Score and Rank
Score every item 1–10 across two dimensions:
- **Urgency**: time-sensitive? response expected? deadline today?
- **Importance**: deal impact? client relationship? nonprofit obligation?

Nonprofit inbox items: add 2 points to importance score automatically.

**Exceptions from Step 4 are always scored in, but verify freshness before scoring.** The Run Log's Exceptions column is frozen text from the last orchestrator run (M/W/F) -- it does not know about anything Marvin resolved since then through email or a direct conversation, and presenting stale "unresolved" framing as current fact is worse than the section being late. For each exception, before scoring it: extract the named org/contact, then check for activity dated after the orchestrator's run date -- reuse Step 1's Gmail pull (do not issue a second separate query) and, if the exception names a Notion deal, check its Last Activity Date. If newer activity exists, rewrite the exception's framing to reflect it (e.g. "in progress, meeting scheduled for Friday" instead of "unresolved, needs Marvin to confirm terms, request LOI, or issue HOLD") before it's scored or shown anywhere in the brief. If no newer activity exists, score and present it as-is -- it's still genuinely unresolved.

Score each (freshness-checked) exception urgency 8+ if still genuinely unresolved (it has been sitting since the last orchestrator run) and importance based on which Objective it blocks; an exception rewritten as "in progress" from a freshness check should be scored down accordingly, not left at urgency 8+. These compete for Top 3 placement on the same footing as inbox/deal items -- do not create a separate always-shown exceptions list that bypasses ranking.

Rank all items by `urgency + importance`. Top 3 become the **Action Items** section.

### Step 6 — Build Brief
Compose HTML email using format.md template.

Sections:
1. **Top 3 Action Items** — ranked items requiring same-day response or decision (may include OKR exceptions per Step 5)
2. **OKR Pulse** — Portfolio status as of the last orchestrator run, then per-Objective KR breakdown by real name (`Accounts Added: X/180`, `MRR: X/$7,350`, `Placements: X/30`, etc. per Step 4's mapping — not a blended score, not a bare `KR1/KR2/KR3` label), with the Activated column translated into one line per Objective (e.g. "Revenue — full signal pipeline activated"). Exceptions already promoted to Top 3 are not repeated here; only list ones that didn't rank into the top 3.
3. **Email Triage** — inbox summary by account, flagged messages with one-line context
4. **Deal Pulse** — Notion deals with activity or upcoming close dates
5. **Beehiiv Pulse** — new subscribers and warm Crystal ICP signals
6. **On Deck** — items scoring 5–7, no same-day urgency but worth knowing

Nonprofit items display with a `[Nonprofit]` label throughout.

### Step 7 — Send
Send the brief via Resend, not GWS CLI/Zapier. Write the HTML body to a file, then run:
```
python3 Scripts/sarah-send-email.py --to marvin@compoundleverage.com --subject "Daily Brief — [Weekday, Month Day]" --html-file <path>
```
`RESEND_API_KEY` is already in the environment. Em dashes and other non-ASCII characters in the subject are safe — Resend's JSON API handles RFC 2047 encoding itself, which retires the old mojibake bug ("Ã¢Â€Â"" instead of "—") that the hand-rolled GWS MIME pattern used to produce.

Log send confirmation to Google Chat webhook (`config.findings.webhook_url_env`). No confirmation required from operator — this skill runs fully autonomously.

**Send exactly once per run.** Complete Steps 1-6 fully -- including retrying any failed read within its own step -- before composing the email. Once Step 7 sends, the run is done. Do not restart the workflow, re-read data, rebuild the HTML, or send a second email to correct or improve on the first send in the same run, even if a later self-check finds a section was wrong or incomplete. A past run read the OKR log successfully on a second internal attempt after failing once, then rebuilt and sent the entire brief again rather than resuming -- Marvin received two full emails 28 seconds apart. If a section's data genuinely isn't available after a normal retry, send once with that section omitted per Error Handling below -- do not send, notice a gap, and send again.

## Error Handling
- If a Gmail account read fails: note it in the brief under a "Read errors" line, continue with other accounts
- If Notion returns no data, or the Notion MCP tool is unavailable/errors: omit Deal Pulse section, note it under "Read errors"
- If Beehiiv returns no data, or the Beehiiv MCP tool is unavailable/errors: omit Beehiiv Pulse section, note it under "Read errors"
- **Never reconstruct Deal Pulse or Beehiiv Pulse data from a previously-sent brief, a cached file, or any source other than a live Notion/Beehiiv read this run.** A missing section is a visible, honest gap. A section rebuilt from yesterday's email is silent stale data with no way for the operator to tell it isn't current -- worse than omitting it.
- If the CE Goal Orchestrator Run Log table is missing or unparseable: omit OKR Pulse, note "OKR Pulse — run log unavailable", do not guess at scores
- If all reads fail: send a brief noting the failure with a timestamp so operator knows Sarah ran
