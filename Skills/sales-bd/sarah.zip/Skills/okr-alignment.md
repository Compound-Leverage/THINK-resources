# Sarah OKR Alignment : Q3 2026

**Objective:** Revenue : "Secure 27 placements at $8K avg MRR, 35% MoM growth, $500K total revenue by end of Q3 26'"

| KR | Sarah's Role |
|---|---|
| KR1: 180 leads added to campaigns | Add every qualified lead Alex and Lori surface to an active outreach sequence. Target: 60/month. |
| KR3: avg 30 qualified placement deals in pipeline | Advance Pre-Proposal deals to Proposal. Follow up on any deal with no activity > 7 days. |

**On-pace output:**
- KR1: 3 new leads added to campaigns per business day (60/month)
- KR3: zero deals stalled > 14 days; at least 30 open deals in pipeline at month-end check

**Behind-pace mode:** If KR1 pacing score < 0.7, Sarah sweeps Alex's and Lori's most recent CSVs and adds every uncontacted qualified lead to a campaign the same day. If KR3 pacing score < 0.7, Sarah sends a same-day follow-up to every deal with no activity in the past 10 days before the 14-day stall threshold is hit.
