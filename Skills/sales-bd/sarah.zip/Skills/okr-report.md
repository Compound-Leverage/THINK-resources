# Skill: Weekly OKR Report

Sarah generates a weekly OKR report every Friday at 4:00 PM ET. Posts to the findings channel via `config.findings.webhook_url_env`. Cal pulls from this report for the Sunday brief Section 1 (Goal Scoreboard).

Sarah does not score the Objectives -- the goal agents do that. This report reads their output and adds Sarah's BD activity metrics for the week.

---

## Step 1: Read Goal Agent Outputs

Load the following SKILL.md files and extract the most recent data from their logs and tables:

**goal-revenue:** `~/.claude/skills/goal-revenue/SKILL.md`
- Quarter Totals Log: last entry (placements, MRR, cumulative revenue)
- KR1: leads added to campaigns (actual vs pace)
- KR2: DIY MRR (actual vs $3,150 target)
- KR3: pipeline deal count (actual vs 30/month avg)
- Pacing score formula: `(current / target) / (days_elapsed / 92)`
- Days elapsed since July 1

**goal-product:** `~/.claude/skills/goal-product/SKILL.md`
- Q3 Upgrade Log: count of DEs upgraded to date (target: 5 new, total 17)
- Q3 Course Log: count of courses added (target: 4)
- Milestone Status: DOL cert (course package assembled / application submitted)
- Pacing score for each KR

**goal-audience:** `~/.claude/skills/goal-audience/SKILL.md`
- KR1: newsletter issues published this quarter (target: 13)
- KR2: net new subscribers since July 1 (target: 2,100 net new to reach 11,200)
- KR3: THINK School paid members (manual count vs 150 target)
- Pacing score for each KR

**Pacing score thresholds:**
- OVERPERFORMING: >1.0
- MET: 1.0
- ON TRACK: 0.70-0.99
- AT RISK: 0.40-0.69
- BEHIND: <0.40

**Objective score** = average of its KR pacing scores.

---

## Step 2: Pull Sarah's Activity This Week

Pull from logs and Notion for the current week (Mon-Fri):

**Crystal outreach** (from `Logs/sarah-crystal-outreach/` for this week):
- Emails sent (target: 5)
- Replies received
- Conversions to newsletter subscribers this week

**Gail outreach** (from `Logs/sarah-gail-outreach/` for this week):
- Emails sent (target: 25)
- Replies received
- Meetings booked or deals created this week

**Deals Pipeline** (`789edd2b`):
- Deals advanced in stage this week (Last Modified Date = this week, Stage changed)
- Open deals at Proposal or Waiting stage (active work)
- Deals with Last Activity Date > 7 days (stall warning, flag by name)
- Total open deals at any active stage (Pre-Proposal + Proposal + Waiting)

**New leads added to campaigns this week** (Contacts DB `170e1f64`, status changed to Outreached this week):
- Crystal count (source = crystal_outreach)
- Gail count (source = gail_outreach)
- Combined (counts toward Revenue KR1)

---

## Step 3: Post Report

Post to the findings channel via `config.findings.webhook_url_env`:

```
FRIDAY OKR REPORT [Mon date] -- [Fri date]

Q3 OBJECTIVES -- PACING SCORES
---------------------------------
Revenue  [score]  [STATUS]
  KR1 Leads to campaigns:  [actual] / [pace target]  [KR status]
  KR2 DIY MRR:             $[actual] / $[pace target] [KR status]
  KR3 Pipeline depth:      [actual] deals / 30 avg    [KR status]

Product  [score]  [STATUS]
  KR1 DE upgrades:         [count] / [pace target]    [KR status]
  KR2 Courses added:       [count] / [pace target]    [KR status]
  KR3 DOL cert milestone:  [current milestone]

Audience [score]  [STATUS]
  KR1 Issues published:    [count] / [pace target]    [KR status]
  KR2 Net new subscribers: [count] / [pace target]    [KR status]
  KR3 THINK School members:[count] / 150 target       [KR status]

SARAH ACTIVITY -- THIS WEEK
---------------------------------
Crystal outreach:  [N]/5 sent | [N] replies | [N] new subscribers
Gail outreach:     [N]/25 sent | [N] replies | [N] meetings/deals
Leads to campaigns:[N] this week ([N] Crystal / [N] Gail)
Deals advanced:    [N] moved in stage this week
Pipeline:          [N] open deals | [N] stalled >7 days

[IF any stalled deals: list by name and days since last activity]

NOTABLE
---------------------------------
[One line -- biggest move of the week, a new placement, a conversion spike, or a gap]
```

---

## Rules

- Pull live data -- do not estimate or carry forward last week's numbers
- If a goal agent SKILL.md log has no Q3 entries yet (before July 1): note "Q3 not started -- no pacing data" for that Objective
- Do not recalculate OKR scores independently -- read from goal agent SKILL.md files
- No em dashes in output
- Post to findings channel only -- not a DM, not an escalation
- Cal references this report in the Sunday brief (Section 1: Goal Scoreboard)
- Flag any stalled deal by name so Marvin sees it Monday morning
