# Skill: Sarah Partner Pipeline v2

Weekly partner pipeline routine for the CL/Inncuvate joint deal flow. Manages deal qualification, pipeline hygiene, Mark Lawrence's brief, proposal tracking, and OKR scorecard. Runs every Monday. Ties into `mark-partner-brief.md` for the external brief step.

**Invoke:** `/sarah-partner-pipeline` or `"Partner Pipeline: weekly run"`
**Run cadence:** Mondays 9am ET via CCR trigger. On demand any time.
**Data sources:**
- Deals Pipeline (Notion `1c6eba1b7fad4b4abfcbeb41b729c586`) -- filter to Partner = Inncuvate
- Intelligence Inbox (Notion `4bcb512f-9861-476f-945b-9b90ceb6478a`)
- `Agents/status/deal-qualification-log.md`

---

## Rules

FOUNDING PRINCIPLE: CL is the infrastructure. Organizations qualify to access the system -- CL does not qualify to participate in their deals. Every qualifying question flows from this. If a deal requires CL to fit into an existing structure on someone else's terms, it fails before the tier check runs.

PARTNER TYPE: Mark Lawrence / Inncuvate is an Infrastructure Partner. He finds organizations that need the CL methodology. He does not structure deals that CL fits into. Sales enablement assets and methodology access are provided by CL. His revenue comes from deal economics, not a licensing fee. All deals must reflect CL as infrastructure provider, not participant.

- No payment status, invoice data, or billing state in any Mark-facing output
- Stale flags state the business reason (no response, no contact info, scope not confirmed) -- never the payment state
- Deal tier classification: T1 ($250K+), T2 ($100K-$249K), T3 ($50K-$99K), T4 (<$50K)
- JV allocation floor: CL + Inncuvate combined must hold 40%+ to qualify
- A PENDING_COMMITTEE deal is not active pipeline and does not count toward LEAD_BUDGET
- A deal Marvin rejects never enters active pipeline
- Outreach to Marvin uses marvin@compoundleverage.com -- never mark@inncuvate.com for internal decisions
- No em dashes in any output

---

## Workflow

### Step 0 -- Holiday Check

If today matches a US federal holiday:
- Append to `Logs/completions.log`: `[ISO timestamp] | sarah | sarah-partner-pipeline | SKIPPED | US federal holiday`
- Commit log entry to staging branch
- Stop. Do not run any subsequent step.

---

### Step 0.5 -- Deal Qualification Committee

**Applies only to deals entering the Inncuvate pipeline for the first time.** Existing active deals skip this step entirely.

Identify new deals: query Deals Pipeline where Partner = Inncuvate AND record was created or first appeared since the last pipeline run (no prior entry in `Agents/status/deal-qualification-log.md`).

If no new deals: skip to Step 1.

For each new deal, run the committee process:

**Committee members:**
- Sarah: deal intake, qualification data, tier classification, 40% floor check
- Julian: funnel health, opportunity cost vs direct channel (would this slot be better filled by a CL-sourced deal at equivalent value? Compare using Notion Deals Pipeline data -- deal value and deal type conversion rates vs CL-sourced deals)
- One impacted Strategist: delivery capacity, execution risk (the Strategist whose delivery scope would be affected by this deal)

**Committee process:**
1. Sarah runs full qualification on the new deal (all six questions from Step 1)
2. Julian scores it against direct channel benchmarks using Notion Deals Pipeline data
3. Impacted Strategist flags capacity and delivery risk
4. Each member submits: APPROVE / REJECT / HOLD + one sentence of reasoning
5. Write consolidated recommendation to `Agents/status/deal-qualification-log.md` in this format:

```
[ISO timestamp] | Deal: {Deal Name} | Tier: {T1/T2/T3/T4}
Sarah:      {APPROVE/REJECT/HOLD} -- {one sentence}
Julian:     {APPROVE/REJECT/HOLD} -- {one sentence}
Strategist: {APPROVE/REJECT/HOLD} -- {one sentence}
Recommendation: {APPROVE/REJECT/HOLD}
Presented to Marvin: [timestamp]
Marvin Decision: [ACCEPTED/REJECTED] | [timestamp]
```

6. Email consolidated recommendation to marvin@compoundleverage.com (not Mark). Subject: `Deal Qualification: {Deal Name} -- Committee Recommendation`
7. Set deal status to PENDING_COMMITTEE in Deals Pipeline. Do not advance this deal to active pipeline until Marvin accepts.

Marvin never evaluates a deal without a committee recommendation in front of him.

---

### Step 1 -- Pull Pipeline

Query Deals Pipeline where Partner = Inncuvate AND Stage NOT IN (Won, Lost).

**Variables:**

```
ACTIVE_DEAL_COUNT      = COUNT deals passing all six qualifying questions below
STALE_COUNT            = COUNT active deals with Last Activity Date > 7 days
PENDING_COMMITTEE_COUNT = COUNT deals where qualification complete but no Marvin decision yet
LEAD_BUDGET            = ACTIVE_DEAL_COUNT (PENDING_COMMITTEE deals excluded)
```

**Six-question qualifying check -- for each deal where Stage NOT IN (Won, Lost):**

1. Does the organization have a budget and mandate to deploy AI workforce infrastructure? If no → REJECT, do not route
2. Is CL the infrastructure provider in this deal, not a line item in someone else's structure? If no → flag to committee before proceeding
3. Is the JV allocation defined? If no → PENDING_SCOPE, surface to Marvin weekly
4. Does CL + Inncuvate combined hold 40%+ of the JV allocation? If no → flag to committee
5. Does CL's scoped revenue meet the tier minimum? If no → flag to committee
6. Has the committee approved this deal? If no → do not count toward LEAD_BUDGET, do not include in active pipeline

All six must pass. A deal that passes questions 1-5 but has no committee decision is PENDING_COMMITTEE, not active.

For each qualifying active deal, extract:
- Deal name
- Stage
- CL amount (or funding pot if CL amount not set)
- Tier (T1/T2/T3/T4)
- JV allocation %
- Last Activity Date
- Next action and who owns it

---

### Step 1A -- Stale Alert

If STALE_COUNT > 0:

Send email to marvin@compoundleverage.com:

```
Subject: Partner Pipeline: [N] Stale Deal(s) -- Action Needed

[List each stale deal: name, days since last activity, business reason for stall]

Note: Each stale deal is a potential reroute to CL direct pipeline.
Committee re-qualification required before refilling the slot.
```

Send via GWS (Tier 1) → Zapier (Tier 2) → Resend (Tier 3 / last resort only).

---

### Step 2 -- Run Weekly Brief to Mark

Execute `Agents/sarah/Skills/mark-partner-brief.md` in full. That skill handles:
- One Thing
- Joint Pipeline section
- Proposal Status section
- Capital Event Signals section
- Opportunities for Your Review section
- What Sarah Is Handling section
- HTML email send to mark@inncuvate.com via GWS → Zapier → Resend

Do not modify or summarize the brief output here -- mark-partner-brief.md owns that format entirely.

---

### Step 3 -- Deal Stage Sync

For any deal that advanced in stage since last Monday:

1. Update Deals Pipeline record: Stage, Next Action, Last Activity Date
2. If deal moved to Pre-Proposal or Proposal: notify Blair (capital/grant) or Maya's team (commercial/RFP) as appropriate
3. If deal moved to Verbal: flag to Sage (Agreements & Contracts pipeline)
4. If deal moved to Won: notify Lincoln (onboarding) and Marcus (case study intake)
5. If deal moved to Lost: log reason in Deals Pipeline Notes field

Write a one-line sync note to `Agents/status/partner-pipeline-sync-[YYYY-MM-DD].md` for each deal updated.

---

### Step 4 -- Proposal Status Check

Query Intelligence Inbox where Status IN (Qualified, Reviewed, Active) AND Notes/Description/Title contain "Inncuvate" OR "PGCC" OR "PJM" AND Policy Level = Federal or Agency/Organization contains MBDA or SBA.

For each active proposal:
- Confirm a next action and owner are logged
- If proposal is past its follow-up date with no update: flag to Marvin with deal name and days overdue
- If a response or decision is needed from Mark: note for inclusion in the next Mark brief (mark-partner-brief.md handles the actual outreach -- this step only flags the gap)

---

### Step 5 -- OKR Scorecard

Compile and post to the findings channel (CE cluster space):

```
PARTNER PIPELINE SCORECARD -- [DATE]

Active Deals:          {ACTIVE_DEAL_COUNT} in qualifying pipeline
Pending Committee:     {PENDING_COMMITTEE_COUNT} deals awaiting decision
Stale (>7 days):       {STALE_COUNT} deals flagged
New This Week:         {COUNT new deals submitted to committee this run}
Deals at Verbal+:      {COUNT Stage IN (Verbal, Won)}

PIPELINE BY TIER
  T1 ($250K+):         {N} deals
  T2 ($100K-$249K):    {N} deals
  T3 ($50K-$99K):      {N} deals
  T4 (<$50K):          {N} deals

PENDING SCOPE:         {COUNT PENDING_SCOPE deals} deals, JV allocation unconfirmed
```

---

### Step 6 -- Intelligence Routing

Pull from Intelligence Inbox: Status = Qualified, added in last 7 days, relevant to MD, DC, VA, TX and sectors: workforce development, semiconductor, AI, federal infrastructure.

For each qualifying signal:
- If a joint CL/Inncuvate play is plausible: queue for "Opportunities for Your Review" in next Mark brief
- If signal is CL-direct only (no Inncuvate angle): route to Chet / Intelligence Inbox for standard CE processing
- Limit to 3 queued opportunities per weekly cycle; prioritize by Intent Signal Score descending, then application deadline proximity

---

### Step 7 -- Completion Log

Append to `Logs/completions.log`:

```
[ISO timestamp] | sarah | sarah-partner-pipeline | COMPLETE | active={ACTIVE_DEAL_COUNT} | pending_committee={PENDING_COMMITTEE_COUNT} | stale={STALE_COUNT}
```

Commit log entry to staging branch.
