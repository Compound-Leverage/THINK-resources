# Anomaly Detection

Monitors Nova's own behavior for volume spikes and unusual patterns that indicate abuse, a bug, or a compromised input. Nova watches herself.

## Baselines

Baselines are calculated from the rolling 14-day average stored in the audit log. On first deployment, defaults apply until 14 days of data are collected.

| Metric | Default baseline | Alert threshold |
|--------|-----------------|-----------------|
| Emails sent per run | 3 | > 2x baseline |
| Unique recipients per day | 5 | > 3x baseline |
| Emails to same recipient in 24h | 2 | > 4 |
| Agent invocations per day | 8 | > 3x baseline |
| Tasks processed per hour | 5 | > 3x baseline |
| Outbound email size | 50KB | > 500KB single email |

## Checks

### Check A — Volume Spike (per run)
Before completing any run where Nova has sent emails or triggered agents, compare the run's activity against baseline.

```python
if emails_sent_this_run > (baseline_emails_per_run * 2):
    halt_and_alert("Volume spike: sent {emails_sent_this_run} emails this run (baseline: {baseline})")
```

On spike:
1. Complete the current send if already in flight (don't cut mid-send)
2. Halt all further sends for the remainder of this run
3. Alert operator via Google Chat immediately
4. Log full run activity to audit log with spike flag

### Check B — Repeat Contact
Before sending any email, check if Nova has contacted the same address in the last 24 hours.

```python
if contact_count_last_24h(recipient) >= 4:
    block_send(recipient)
    log(f"[ANOMALY] Repeat contact blocked: {recipient} — {count} emails in 24h")
```

Does not alert operator unless count exceeds 6 (indicates a loop, not just active outreach).

### Check C — Payload Size
Before sending any email, check the total size of the message body + attachments.

```python
if payload_size_bytes > 500_000:  # 500KB
    block_send()
    alert_operator(f"[ANOMALY] Outbound payload blocked: {payload_size_bytes / 1000:.0f}KB exceeds limit")
```

Catches accidental data dumps — e.g., a skill that accidentally includes a full CRM export in the body.

### Check D — Off-Hours Surge
Scheduled tasks run at defined times. If Nova detects inbound task volume more than 3x baseline between 10pm and 6am local time (operator timezone from config), flag for review.

```python
if is_off_hours() and tasks_this_hour > (baseline_tasks_per_hour * 3):
    pause_task_queue()
    alert_operator("[ANOMALY] Off-hours surge detected — task queue paused until you confirm")
```

Operator replies RESUME to restart the queue.

## Alerts

All anomaly alerts post to the operator's Google Chat with:
```
[ANOMALY DETECTED] [check type]
Metric: [what triggered]
Observed: [value]
Baseline: [value]
Action taken: [halted / blocked / paused]
Run ID: [task_id]
```

## Baseline Updates
After each clean run (no anomalies), the 14-day rolling average updates automatically. Anomalous runs are excluded from baseline calculation — a spike doesn't permanently raise the bar.

## Config
```json
"security": {
  "anomaly_detection": {
    "enabled": true,
    "baseline_window_days": 14,
    "volume_spike_multiplier": 2,
    "repeat_contact_limit_24h": 4,
    "max_payload_kb": 500,
    "off_hours_start": "22:00",
    "off_hours_end": "06:00",
    "operator_timezone": "America/New_York"
  }
}
```
