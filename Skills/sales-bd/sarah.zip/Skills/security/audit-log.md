# Audit Log

Every action Nova takes is recorded in a structured, append-only log. Two destinations: a dedicated Google Chat thread (operator-visible) and a local run log file (CL-accessible). Neither is ever deleted or overwritten.

## What Gets Logged

Every entry. No exceptions. Silent runs generate a single heartbeat entry.

| Event category | Examples |
|----------------|---------|
| Security events | Allowlist rejection, injection detected, scope violation, rate limit hit, outbound blocked |
| Confirmation gate | Gate triggered, GO received, CANCEL received, timeout expired |
| Circuit breaker | Chain halted, depth reached, operator-resumed |
| Anomaly detection | Volume spike, repeat contact block, payload block, off-hours surge |
| Task routing | Task received, agent invoked, result relayed, task completed |
| Email sends | Recipient, subject, send method (Resend), success/failure |
| Schedule events | Workflow triggered, run started, run completed, workflow skipped |
| Agent results | Agent name, task ID, completion status, output summary (not full content) |
| Errors | Any exception, failed API call, fallback triggered |

## Log Entry Format

```
[YYYY-MM-DD HH:MM:SS UTC] [LEVEL] [CATEGORY] [TASK_ID]
Sender: [email or "scheduled"]
Action: [what Nova did or attempted]
Agent: [agent invoked, if any]
Result: [completed / blocked / halted / failed / pending]
Detail: [one-line context — no PII beyond email address, no message body content]
```

Example entries:
```
[2026-06-23 12:03:44 UTC] INFO TASK_ROUTE task_20260623_001
Sender: mlawrence@inncuvate.com
Action: Task directive received — proposal run for Optivate
Agent: maya (via blair)
Result: pending_confirmation
Detail: Confirmation gate triggered — GO pending

[2026-06-23 12:05:12 UTC] INFO CONFIRMATION task_20260623_001
Sender: mlawrence@inncuvate.com
Action: GO received
Agent: —
Result: queued
Detail: Proposal run approved — routing to Maya

[2026-06-23 12:31:05 UTC] INFO TASK_COMPLETE task_20260623_001
Sender: mlawrence@inncuvate.com
Action: Proposal delivered to mlawrence@inncuvate.com
Agent: maya
Result: completed
Detail: 6-agent proposal run complete — delivered via Nova

[2026-06-23 07:01:00 UTC] WARN SECURITY task_system
Sender: unknown@external.com
Action: Inbound message from non-allowlisted sender
Agent: —
Result: bounced
Detail: Standard bounce reply sent — no system details disclosed
```

## Log Destinations

### 1. Google Chat Audit Thread
A dedicated Space or thread named **Nova — Audit Log** (separate from Nova — Operations).
- WARN and ERROR level events post immediately
- INFO events batched and posted once per day at end of morning brief run
- Never post full message body content — summaries only

### 2. Local Run Log File
Written to `Logs/nova-audit/YYYY-MM-DD.log` in the repo.
- All events at all levels
- Appended, never overwritten
- Retained 90 days by default (configurable)
- CL can pull these for client audits or incident investigation

## What the Audit Log Does NOT Contain
- Full email body content (summaries only)
- API keys, tokens, or webhook URLs
- HubSpot contact records or deal financials
- Asana task content beyond task name

The audit log is an action record, not a data store.

## Anomaly Correlation
The anomaly detector (`anomaly-detection.md`) reads the audit log to calculate baselines. The log is the single source of truth for what Nova has done. No separate stats table needed.

## Config
```json
"security": {
  "audit_log": {
    "local_retention_days": 90,
    "google_chat_thread": "Nova — Audit Log",
    "batch_info_events": true,
    "batch_post_time": "morning_brief_end"
  }
}
```
