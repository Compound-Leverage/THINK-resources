# Agent Chain Circuit Breaker

Prevents runaway multi-agent task chains triggered by crafted or mistaken inputs.

## The Risk
Nova routes a task to Chet → Chet's output triggers Alex → Alex's output triggers Maya → Maya triggers Quinn and Diego. A single email could spawn 6+ agent runs. A malicious or malformed input could exploit this to burn API credits, produce garbage output, or loop indefinitely.

## Rules

### Max Chain Depth: 3
No task chain may exceed 3 agent hops from Nova.

```
Nova → Agent A                    depth 1 ✓
Nova → Agent A → Agent B          depth 2 ✓
Nova → Agent A → Agent B → C      depth 3 ✓ (maximum)
Nova → A → B → C → D              depth 4 ✗ HALT
```

**Maya's internal team (Porter, Chase, Priya, Quinn, Diego) counts as ONE hop**, not 5. Maya orchestrates them internally. The chain is: Nova → Blair → Maya (depth 3 — valid).

### Max Concurrent Agent Runs: 3 per task
A single task directive may not spawn more than 3 parallel agent runs at the same time. Sequential runs within the depth limit are fine.

### No Circular Routing
An agent may not route back to Nova with a new task directive. Agents return results to Nova — they do not generate new outbound tasks. Nova relays the result to the operator and stops.

## Implementation

Nova tracks chain depth as a counter passed with each sub-agent invocation:

```
task_context = {
  "original_sender": "mlawrence@inncuvate.com",
  "chain_depth": 0,
  "chain_log": ["nova"],
  "task_id": "task_20260623_001"
}
```

Each agent invocation increments `chain_depth` and appends to `chain_log`.

Before routing to any agent, check:
```python
if task_context["chain_depth"] >= 3:
    # HALT — do not route further
    notify_operator(
        f"Task {task_context['task_id']} hit chain depth limit. "
        f"Chain: {' → '.join(task_context['chain_log'])}. "
        f"Operator action required to continue."
    )
    return
```

## On Halt
1. Stop all further routing immediately
2. Post to Google Chat:
   ```
   [CIRCUIT BREAKER] Task halted — chain depth limit reached
   Task: [task summary]
   Chain: Nova → [agent] → [agent] → [agent]
   Action needed: reply with instructions to continue or cancel
   ```
3. Reply to operator with what was completed so far and what remains
4. Wait for explicit operator instruction before proceeding

## Logging
Every chain logged to audit log with task ID, depth reached, agents invoked, and final status (completed / halted / operator-continued).
