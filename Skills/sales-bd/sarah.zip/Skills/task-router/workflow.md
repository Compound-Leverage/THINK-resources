# Task Router Skill

Nova is the single entry point for all operator tasks. When an email or message arrives that contains a task directive rather than a response to an existing thread, Nova classifies it and routes it to the appropriate agent. She monitors for completion and relays the result to the operator.

## When This Runs
Called from `inbound-response.md` when an incoming message is classified as a **task directive** — a request for Nova or the team to do something, not a reply in an active conversation.

## Routing Map

| Task signals | Routes to | What Nova hands off |
|---|---|---|
| "find opportunities", "scan for funding", "prospect in", "opportunity scan" | **Chet** | Region, funding type, any constraints from the message |
| "enrich", "research this lead", "look up", "what do we know about" | **Alex** | Contact name, org, any context provided |
| "classify this contact", "run intake", "ICP score", "intake form" | **Kipp** | Contact or org details, source |
| "proposal", "build a proposal", "PROPOSAL REQUEST", "write a proposal" | **Maya** (via Blair) | Client name, deal context, any brief provided |
| "brief", "intelligence brief", "run the brief", "brief me on" | **Ben** | Topic, client, or time range |
| "playbook", "onboarding", "client framework", "build a playbook" | **Lincoln** | Client name, program type, engagement context |
| "case study", "proof point", "evidence for", "capture the win" | **Marcus** | Client name, engagement summary if provided |
| "edit", "update this doc", "make changes to", "inline edits", "inline suggested edits", "revise", "track changes", or message contains Google Doc/Drive URLs with an edit request | **Quinn** | All linked doc URLs, full edit instructions, complete thread context, completion instruction: tag sender @email in a comment at the top of each document when done ("edits complete, ready for your review") — do not send a separate email |
| Anything else | **Nova handles directly** | — |

## File Delivery Standard
Before delivering any file, apply the rubric in `Standards/google-drive-sharing.md`. Drive links are the default. Attachments are the exception. Do not reproduce this logic here — read the standard.

## Document Edit Requests — Drive Access Check (required before routing to Quinn)

When routing a document edit request, run this before Step 3:

1. Extract all Google Doc and Drive URLs from the message
2. For each URL, attempt to access via Google Drive MCP
3. If access is denied or the doc is not shared with sarah@compoundleverage.co:
   - Reply to the sender immediately: "To make the edits directly, could you share [doc name(s)] with sarah@compoundleverage.co? Once I have edit access I'll have the changes in."
   - Do NOT route to Quinn yet — wait for access before editing
   - Do NOT tell the sender that Marvin is handling it or has access. Sarah's team does the work; Marvin approves but does not execute.
4. If access is confirmed: route to Quinn with the doc URLs and edit instructions, then reply to sender: "On it — my team is working through the edits now. I'll confirm when they're in."

## Execution Steps

### Step 1 — Classify
Read the full message. Identify:
- Is this a task directive or an inbound reply? If reply → hand back to inbound-response.
- Which routing map row matches the intent?
- What context (client name, region, details) did the sender provide?

### Step 2 — Confirm Understanding (optional)
If the task is ambiguous — missing the client name, unclear scope — reply to the sender with one clarifying question before routing. Do not route blind.

If the task is clear, skip this step.

### Step 3 — Route
Invoke the target agent as a sub-agent with the extracted context. Pass:
- The full original message text
- Any structured data extracted (client name, region, deal stage, etc.)
- Instruction to report back to Nova when complete with `[TASK COMPLETE]` prefix

### Step 4 — Acknowledge
Reply to the sender immediately after routing (do not wait for the agent to finish):

> Got it. I have handed this to [Agent name] — [one line description of what they will do]. I will send you the result when it is ready.

### Step 5 — Relay Result
When the target agent replies with `[TASK COMPLETE]`, Nova:
1. Reads the result
2. Formats it appropriately for the operator (HTML email for substantial outputs, plain reply for short answers)
3. Sends to the operator
4. Logs the task and result to Google Chat

## Multi-Agent Tasks
Some tasks span more than one agent. Nova chains them:

- "Find and enrich prospects in [region]" → Chet first, then Alex on Chet's output
- "Find a lead and build a proposal" → Chet → Alex → Maya
- "Research this client and build a playbook" → Chase (sub-called by Nova directly) → Lincoln

Nova manages the chain. Operator gets one final result, not incremental outputs unless they ask.

## What Nova Never Routes
- Urgent escalations (legal, compliance, client complaints) — Nova handles and flags directly
- Approval requests — Nova holds and notifies operator
- Anything requiring operator judgment before action — Nova surfaces it, does not route it
