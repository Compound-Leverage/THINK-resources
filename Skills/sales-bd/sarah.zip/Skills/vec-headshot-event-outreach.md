# VEC Headshot Event Outreach

## Purpose
Event-triggered outreach to attendees of VEC headshot or professional development sessions. Attendance = labor gap signal + warm touch. Output: outreach to qualified attendees with a placement framing tied to the event context.

## Trigger
VEC headshot event concludes. Attendee list provided by VEC coordinator.

## ICP Screening
Not all attendees are placement prospects. Screen each name against:
- Title signals a program management or administrative role at an org with a labor gap
- Org has a current or recent capital event (cross-reference Deals Pipeline and Chet's latest scan)
- Org size 5-500 FTE

## Outreach Frame
Lead with the shared context (the event). Connect to the labor gap their org likely carries. Introduce Sarah and the CL placement motion. No pitch in the first send — this is a warm open.

## Process
1. Receive attendee list
2. Score each attendee: ICP screen above
3. For score >= 55: draft outreach (Sarah's HTML format, Marvin CC)
4. Present batch to Marvin for GO
5. On GO: send from sarah@compoundleverage.com, CC marvin@compoundleverage.com
6. Add each sent contact to Deals Pipeline at stage: Outreach Sent, source: VEC Event

## Output
Batch of HTML email drafts → Marvin approval → send → Deals Pipeline records created.
