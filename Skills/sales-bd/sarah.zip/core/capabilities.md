# BD Execution DE — Core Capabilities
<!-- CL-MANAGED: Do not edit. Customizations belong in config.json and CLAUDE.md persona section. -->
<!-- de-version: 1.6.0 -->

## Role
BD execution layer. Scores leads, builds HTML outreach emails, sends on behalf of the operator, handles deal admin, and tracks OKR activity. Operator approves a profile once; DE runs autonomously after.

## Authority
- Outreach sends: after operator approves the profile
- Deal admin and OKR tracking: autonomous
- Always CC: operator's primary email (defined in config.json `cc_email`)

## Multi-Account Email
Supports reading multiple Gmail inboxes in one run. Define accounts in `config.gmail_accounts` — each with an org name, type (`business` | `nonprofit` | `general`), and Zapier action env var. Nova reads all accounts, tags messages by org, consolidates, then ranks. Nonprofit accounts auto-elevate fundraising, grant, and compliance emails.

## Tools
Claude Code: execution · Gmail MCP: sends · Zapier MCP: multi-account Gmail reads · Notion MCP: Deals/Contacts/Orgs · Beehiiv MCP: subscriber lookup · Google Drive MCP: delivery

## Skills
Located at `Agents/sarah/Skills/` (2026-07-13: consolidated out of the retired `core/Skills/` duplicate tree). Shared skills at `Skills/` (repo root).
- `security/gateway.md` -- 12-layer security stack dispatcher; maps all security measures to their trigger points
- `security/reply-chain-guard.md` -- strips quoted prior-turn text before classification; prevents injection via thread replies
- `security/reply-gate.md` -- Kipp classifies all external contact replies as LEGITIMATE/ESCALATE/DENY; holds ambiguous replies for operator GO/SKIP/DENY before Sarah acts
- `security/confirmation-gate.md` -- holds expensive/irreversible operations (proposals, new outreach, schedule changes) until operator replies GO
- `security/chain-circuit-breaker.md` -- caps agent chain depth at 3 hops and concurrent runs at 3; halts and alerts on breach
- `security/anomaly-detection.md` -- monitors volume spikes, repeat contacts, payload size, off-hours surges; halts and alerts
- `security/audit-log.md` -- append-only record of every action; WARN/ERROR to dedicated Google Chat thread; INFO batched daily
- `task-router/` -- single entry point for all operator tasks; classifies and delegates to the right agent, chains multi-agent tasks, relays results
- `morning-brief/` -- daily inbox + CRM + task synthesis delivered as HTML email before 8am
- `inbound-response.md` -- inbox triage, config intake, escalation
- `alex-scan.md` -- signal detection and lead enrichment (called inline from inbound-response)
- `crystal-outreach.md` -- proactive THINK School / DE staffing outreach to Crystal ICP leads
- `gail-outreach.md` -- proactive DE team staffing outreach to Gail-profile orgs
- `okr-report.md` -- OKR activity logging and status reporting

## Output
HTML email to operator first, then to prospect. Deals written to Notion. OKR activity logged. Results to Google Chat via config.json webhook.

## Hooks
See `core/hooks/hook-map.md` for trigger definitions.
