# Sarah Grant -- Hook Map

| When to run | Trigger type | Trigger value | Action |
|---|---|---|---|
| Sunday 10:00 PM ET | CCR schedule | After Joe + intel pipeline | Run `/crystal-outreach` -- Phase 1: load Crystal queue for the week |
| Sunday 10:15 PM ET | CCR schedule | After Crystal load | Run `/gail-outreach` -- Phase 1-3: source 25 Gail orgs, build demos, post batch approval |
| Daily 7:00 AM ET (operator-configured) | Cron | `0 12 * * 1-5` UTC | Run `morning-brief` -- read all inboxes, HubSpot deals, Asana tasks, deliver HTML brief |
| Weekdays 8:00 AM ET | Cron | `0 12 * * 1-5` UTC | Run `campaign-manager` -- read active campaign records from Notion, report actions due, send email/outreach updates |
| Mon-Fri 8:00 AM ET | Cron | `0 8 * * 1-5` | Run `/crystal-outreach-send` -- Phase 2: send Crystal email |
| Mon-Fri 8:30 AM ET | Cron | `30 8 * * 1-5` | Run `/gail-outreach-send` -- Phase 4: send Gail emails (5/day) |
| Every 4 hrs, 7am-11pm ET | CCR schedule | `0 7,11,15,19,23 * * *` | Run `/sarah-inbound-response` -- inbox triage, reply handling, escalation |
| Monday 9:00 AM ET | CCR schedule | After Crystal + Gail sends | Run `/sarah` -- pipeline health + ICP routing |
| Friday 4:00 PM ET | Cron | `0 16 * * 5` | Run `./run-sarah.sh okr-report` -- weekly OKR report to findings channel |
| On demand | Explicit ask | "Sarah: run [skill name]" | Run named skill |

## Notes

- Crystal Sunday load gates Crystal Mon-Fri sends. If Sunday load does not run, no Crystal emails send that week.
- Gail Sunday queue build gates Gail Mon-Fri sends. If Sunday build does not run, Gail sends skip that week.
- Saturday sends are blocked -- newsletter sends Saturdays, no outreach that day.
- Monday 9AM pipeline health runs after both 8AM and 8:30AM sends complete.
- Friday OKR report pulls live data from Beehiiv, Notion, and weekly send logs. Cal references it in the Sunday brief.
- All sends from sarah@compoundleverage.com via Resend (Scripts/sarah-send-email.py) — not GWS CLI or Zapier.
- Gail outreach sends autonomously unless Marvin replies HOLD [org name] or HOLD ALL before 8:30 AM.
